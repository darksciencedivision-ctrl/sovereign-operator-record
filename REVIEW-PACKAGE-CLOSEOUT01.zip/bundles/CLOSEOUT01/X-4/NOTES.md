# X-4 — Developer-machine identifiers in distributed bytes (N-18 / S-16)

Builder seat: `claude-code (opus-5)` · commit `9110390` · UTC 2026-08-29T18:42:14Z
**Status: PARTIAL.** Steps 1, 2 and 4 landed. Step 3 is PARKED — see `PARKED-X-4-STEP-3.md`.

## Step 1 — fail-before (`fail-before.txt`)

Against the sealed `rebase_adapters.py`, setting an adapter's interpreter to a neutral placeholder
and running the rebase leaves it **unrewritten**:

```
FAIL: test_placeholder_interpreter_is_rewritten_unconditionally
AssertionError: 'C:/sovereign-workspace/python-312-resolved-at-install/python.exe'
             != 'C:\Users\Sslaw\AppData\Local\Temp\tmpdjxeenym\python.exe'
 : distillery.json: placeholder interpreter was not rewritten
```

The trap the audit described is real: sanitising the config without first changing the rewrite
would have produced an install pointing at an interpreter that does not exist — and it would have
done so **silently**, with the rebase exiting 0.

## Step 2 — unconditional at the interpreter pointers

`_mapped()` line 54 was `if normalized_value == OLD_PYTHON: return python_312` — a match against a
hardcoded constant which, at line 13, *was itself the developer's username*. Interpreter pointers
are now set from `install.json`'s `python_312` unconditionally; `OLD_PYTHON` is deleted, and
`_mapped()` loses its now-unused `python_312` parameter.

### Deviation from the directive text, and why

The directive says to apply this to "the enumerated interpreter pointers (`/launch/argv/0`)",
reasoning that *"argv[0] is the interpreter by definition"*. That is **false for one of the three
adapters** carrying `/launch/argv/0`. `llamacpp.json`'s `argv[0]` is:

```
…/llama.cpp/current/llama-server.exe
```

— a native server binary. A blanket rule on the pointer string would have overwritten llama.cpp's
server path with `python.exe`. The rule is therefore declared **per adapter**:

```python
INTERPRETER_POINTERS = {
    "distillery.json":  ("/launch/argv/0",),
    "tokencenter.json": ("/launch/argv/0",),
}
```

`test_llamacpp_argv0_is_not_treated_as_an_interpreter` pins that boundary so a future seat cannot
"simplify" it back into a blanket rule.

## Step 3 — PARKED

Full dossier in `PARKED-X-4-STEP-3.md`. In one line: `adapter.py` resolves only `${root}` and
requires `argv[0]` to be an absolute existing `.exe`, and **every** Python on this host lives under
`C:\Users\Sslaw\` (`py -0p` output recorded in the dossier; all four machine-neutral locations
checked and absent). A username-free placeholder and a working dev worktree are not jointly
satisfiable here. The only workaround — running the rebase in the dev worktree — writes **tracked**
files and would reopen the N-16 defect that CONVERGE-01 closed at `65bd58f`.

Left exposed, stated plainly: `shell/config/install.json`, `shell/modules/distillery.json` and
`shell/modules/tokencenter.json` still ship the developer's username in an interpreter path. A
hygiene and privacy defect in distributed bytes. **Not** a functional install defect —
`install.ps1:94` resolves the destination interpreter dynamically and, since step 2, the rebase
now applies it unconditionally.

## Step 4 — llamacpp: NEUTRALISED

Its three `D:/Product Software/Production Workspace/…` paths came from a machine that no longer
exists, and R2 §3 records that the llama.cpp runtime and models ship in **no** archive — so those
paths were dead on every machine, including this one. Replaced with
`C:/sovereign-workspace/optional-runtimes/llama.cpp`, and the `description` field now says
plainly that the paths are a placeholder rather than a location.

Behaviour is unchanged by construction: one non-existent path replaced by another. Verified by
compiling every adapter through `shell/src/adapter.py`:

```
llamacpp     compile OK   argv0=C:/sovereign-workspace/optional-runtimes/llama.cpp/current/llama-server.exe
distillery   compile OK        tokencenter compile OK        debate compile OK
sovereign    compile OK        sow         compile OK
```

The file's **missing trailing newline** — unique among the six adapters — is preserved
byte-exactly; a format guard asserted the round-trip before writing.

The test fixture `test_rebase_adapters.py:14` also carried the real developer interpreter path.
Since the rebase no longer matches that value, the fixture no longer needs a real one; neutralised
to `C:/source-machine/Python312/python.exe`.

## Step 5 — pass-after, against the criterion that is actually satisfiable

The directive's criterion 5 — *"no tracked file that enters `git archive` contains the developer
username or `Product Software`"* — is **refuted as written**; W-6(iv) has the measurement and the
reasoning. The true population is 107 files for the username and 264 for `Product Software`,
overwhelmingly historical evidence captures that R2 §4 permanently prohibits rewriting and R2 §8
requires be preserved exactly.

Measured against the satisfiable criterion:

```
rebase adapter tests      : 5 -> 7, all pass
shell suite               : 166/166, S-5 restoration applied to all 13 rewritten paths,
                            each hash-verified against HEAD, porcelain clean afterwards
adapters compiling        : 6/6
'Product Software' in shell/modules/llamacpp.json : none
developer username in rebase_adapters.py          : none (OLD_PYTHON deleted)
developer username in test_rebase_adapters.py     : none (fixture neutralised)
```

Net effect on distributed bytes: the username is gone from **2** of the 4 files N-18 named, and
`Product Software` is gone from the 1 file it named. Two config files and `install.json` retain it,
parked with a dossier and three costed options for the operator.

## Step 6 — C4 proxy cycle

Required, because `rebase_adapters.py` is install tooling and its behaviour at install time
changed. Re-run in Phase Y; evidence under `bundles/CLOSEOUT01/Y/`.

## Side finding

Satisfying S-5 after the shell-suite run surfaced **N-19**: `shell/BUILD-MANIFEST.txt` is stale at
the seal — 19 of 67 recorded hashes wrong, 8 tracked files omitted — from before the CONVERGE-01
run. Reported separately; not fixed, not in scope.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
