# PARKED — X-4 step 3: the committed interpreter values cannot be neutralised

Item: X-4 step 3 (N-18 / S-16) · class **E-3 (spec contradiction, resolved against a host fact)**
Builder seat: `claude-code (opus-5)` · UTC 2026-08-29T18:42:14Z · commit `9110390`

**What is parked:** replacing the developer-specific interpreter value in
`shell/config/install.json`, `shell/modules/distillery.json` and `shell/modules/tokencenter.json`
with a neutral placeholder.

**What is NOT parked, and landed:** step 1 (fail-before proof), step 2 (the unconditional
interpreter rewrite, which deletes the `OLD_PYTHON` constant carrying the username from
`rebase_adapters.py`), and step 4 (llamacpp neutralised).

## The directive's own park condition, quoted

> 3. Replace the developer-specific interpreter values in the tracked config with a neutral
> placeholder that the rebase now overwrites unconditionally. **The dev worktree must keep
> working:** after this change the shell must still launch Distillery and Token Center locally.
> If it cannot, PARK X-4 in full and restore the prior bytes.

It cannot. The blocker is a fact about this host, not a judgement.

## The exact blocker, measured

An adapter's `argv[0]` is constrained by `shell/src/adapter.py`:

```
line 324  launch["argv"] = [_resolve_var(a, compiled["root"]) for a in launch["argv"]]
line 260  def _resolve_var(...)  "Resolve ${root} in a string value. Any other ${...} raises error."
line 327  if not launch["argv"][0].lower().endswith(".exe"): raise AdapterError
line 289  _validate_path: must be absolute; UNC and device paths rejected
```

So the committed interpreter value must be **an absolute path to an existing `.exe`**. The shell
resolves exactly one variable, `${root}`; every other `${...}` raises. There is no
`${python_312}` and inventing one would be a product change and an invented API (S-3).

The placeholder must therefore be a literal path. For the dev worktree to keep working, that
literal path must be a working Python 3.12 on this machine. Every Python on this host:

```
py -0p
 -V:3.14 *        C:\Users\Sslaw\AppData\Local\Python\pythoncore-3.14-64\python.exe
 -V:3.13          C:\Users\Sslaw\AppData\Local\Programs\Python\Python313\python.exe
 -V:3.12          C:\Users\Sslaw\AppData\Local\Programs\Python\Python312\python.exe
 -V:3.10          C:\Users\Sslaw\AppData\Local\Programs\Python\Python310\python.exe
 -V:Astral/…      C:\Users\Sslaw\AppData\Roaming\uv\python\cpython-3.11.16-…\python.exe

Machine-neutral locations, all checked, all absent:
  C:/Program Files/Python312/python.exe          absent
  C:/Program Files (x86)/Python312/python.exe    absent
  C:/Python312/python.exe                        absent
  C:/ProgramData/Python312/python.exe            absent
```

**Every Python interpreter on this host is under `C:\Users\Sslaw\`.** Python 3.12 is a per-user
install. There is no username-free path that is also a working interpreter. The two requirements —
"contains no developer identifier" and "the dev worktree must still launch Distillery and Token
Center" — are not jointly satisfiable on this machine. Not difficult: impossible.

## Why the obvious workaround is worse than the defect

One could commit the placeholder and require `rebase_adapters.py` to be run in the dev worktree.
That is rejected: `rebase_adapters.py` writes `shell/modules/*.json`, which are **tracked** files.
Making normal local use of the shell depend on a run that dirties tracked bytes recreates exactly
the defect ENTRY 007 recorded as **N-16** — "the shell writes runtime evidence into the TRACKED
tree … normal product use dirties the release candidate and will BOOT-fail every future builder
run" — which CONVERGE-01 closed at commit `65bd58f`. Trading a hygiene defect for a reopened
BOOT-integrity defect is a bad trade, and S-9 forbids substituting a different solution.

## What this leaves exposed, stated plainly

Three tracked files still ship the developer's Windows username in an interpreter path:

```
shell/config/install.json          "python_312"
shell/modules/distillery.json      /launch/argv/0
shell/modules/tokencenter.json     /launch/argv/0
```

This is a **hygiene and privacy defect in distributed bytes**. It is **not** a functional install
defect, and must not be reported as one: `install.ps1:94` resolves the destination interpreter
dynamically, writes it into the destination config, and line 132 runs the rebase against the
destination — which, after step 2, now rewrites the interpreter unconditionally instead of by
matching a constant. An install on another machine repoints these correctly. Verified in W-6.

## What would unblock it — three bounded options for the operator

1. **Install Python 3.12 machine-wide on the dev host** (e.g. `C:\Program Files\Python312`), then
   commit that path. Smallest change, no product edit, and the committed value stays a working
   interpreter here. Cost: an operator act on the machine.
2. **Teach the shell one more variable.** Add `${python_312}`, resolved from
   `shell/config/install.json`, to `_resolve_var` in `shell/src/adapter.py`. The two adapter files
   then become fully neutral. `install.json` still holds the machine-specific value — but it is
   the one file whose entire purpose is machine-specific configuration, and `install.ps1` already
   rewrites it at install time. This narrows the exposure from three files to one. It is a product
   change and needs an authorised scope grant.
3. **Accept and disclose.** Record the three files as a named accepted limitation in the release
   notes. Cheapest; leaves a personal username in distributed bytes, which for an enterprise
   release is a genuine defect on its own terms.

Builder recommendation: **option 2**, with option 1 as an immediate stopgap if the operator wants
the exposure gone before the next seal. Option 2 is the only one that makes the tracked adapter
configs correct for every machine rather than for this one.

## Note on "PARK X-4 in full"

The directive says to park X-4 in full if step 3 cannot be done. I have parked step 3 and kept
steps 1, 2 and 4, and I flag that as a deviation for the reviewer to accept or reverse. The
reasons: the §7 convergence checklist itself splits X-4 into two independently-dispositioned rows,
so the item is not treated as atomic by the directive; steps 1, 2 and 4 change **no** config byte,
so there are no "prior bytes" of step 3 to restore; the validator's own N-18 analysis states the
rewrite must be made unconditional **before** any value is neutralised, so keeping step 2 is the
stated precondition for ever completing step 3; and reverting it would delete a proven fix and
leave the trap armed for the next seat. If the reviewer disagrees, reverting commit `9110390`
restores the sealed behaviour exactly and costs nothing else.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
