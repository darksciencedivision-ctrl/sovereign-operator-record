# X-3 — Exclude backup snapshots from release archives (A-3 / OD-26)

Builder seat: `claude-code (opus-5)` · commit `6daed6d` · UTC 2026-08-29T18:34:30Z

## What was shipping

Thirteen backup-suffixed files, 326,410 bytes, inside both candidate archives — including two
contradicting SBOMs and two contradicting release manifests, with no rule for a consumer or
scanner to decide which is authoritative:

```
7 × .pre-CONVERGE01   RELEASE-MANIFEST.json, SBOM.json (270,607 B), THIRD-PARTY-NOTICES.md,
                      VERSION.json, and the debate/distillery/sow INSTALL-PROVENANCE.json
5 × .pre-rebase       the shell adapter backups (debate, distillery, sovereign, sow, tokencenter)
1 × .pre-add08        evidence/cpm1/baseline/host-hardware.pre-add08.json
```

Preserving prior records is right; shipping them is not. All 13 stay tracked and stay in history.

## Step 2 — nothing reads them, verified before excluding

- **`rebase_adapters.py:151-153`** — `backup = modules_dir / f"{name}.pre-rebase"`, then
  `if not backup.exists(): shutil.copyfile(source, backup)`. It **writes** a backup and tests only
  for its *existence*; it never reads a backup's contents. An install that arrives without them
  simply recreates them — and from the installed pre-rebase state, which is a more accurate
  baseline than the source machine's.
- **`verify_install.ps1:12-22`** — builds its expected path set from the **install-time**
  `install-manifest.json`, not from any committed list. Build and verify therefore stay consistent
  with each other whatever the archive contains.
- **`evidence/cpm1/tools/wave_add08.py:38`** — writes `host-hardware.pre-add08.json`. A historical
  evidence tool; it does not read it back.

## Directive-text correction, recorded not silently patched

The directive specifies `export-ignore` for `*.pre-CONVERGE01`, `*.pre-rebase` and **`*.pre-add08`**.

**`*.pre-add08` matches nothing.** The only file is
`evidence/cpm1/baseline/host-hardware.pre-add08.json`, where `.pre-add08` is an **infix**, not the
terminal suffix. Applying the directive literally would have excluded 12 of 13 files and reported
the item closed. Both forms are listed — the one that matches today, and the suffix form for any
future file that does end in `.pre-add08`. Proven by `git check-attr`:

```
evidence/cpm1/baseline/host-hardware.pre-add08.json: export-ignore: set
```

W-5 caught this; it is exactly the class of thing Phase W exists to catch.

## RELEASE-MANIFEST.json still enumerates these files — deliberately

Seven appear in `batch_files` **with hashes**, three as `superseded_provenance_paths`, one in
`superseded_manifests`. That is correct and unchanged: the manifest validates **tracked** bytes,
the files remain tracked, and R2 §8 makes the manifest — never glob behaviour — the authority for
what is historical. `export-ignore` changes archive membership only. The release-manifest gate
reports `PASS (0 problems)` after this commit.

## Pass-after (`pass-after.txt`)

```
backup-suffixed entries in git archive HEAD : 0    (required 0)
still tracked per git ls-files              : 13   (required 13)
archive file entries                        : 3510 -> 3497   (-13, exactly the backups)
```

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
