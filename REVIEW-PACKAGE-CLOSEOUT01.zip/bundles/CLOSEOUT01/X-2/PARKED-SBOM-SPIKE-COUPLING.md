# PARKED — SBOM still declares components for code that no longer ships

Item: X-2 side effect · class **E-3 (spec contradiction)** · raised by builder `claude-code (opus-5)`
UTC: 2026-08-29T18:33:03Z · commits `3d298c4`, `a3fed64`

## The exact blocker

X-2 removed `modules/sow/tools/spike_compositor` from `git archive`. The spike's
`package-lock.json` is still an enumerated input to the release-identity generator:

```
tools/release/generate_release_identity.py:29
    NODE_LOCKS = (
        ("sovereign-ui",         "modules/sovereign/ui/ui_shell/package-lock.json"),
        ("sow-desktop",          "modules/sow/apps/desktop/package-lock.json"),
        ("sow-spike-nonproduct", "modules/sow/tools/spike_compositor/package-lock.json"),   <-- here
    )
tools/release/generate_release_identity.py:38
    NATIVE_ROOTS includes "modules/sow/tools/spike_compositor/node_modules"
```

Phase Z step 2 regenerates release identity, so `SBOM.json` and `THIRD-PARTY-NOTICES.md` will be
rebuilt from that list. The result: **the shipped SBOM declares components — including
`electron 31.7.7` and `extract-zip 2.0.1` — for source that is no longer in the shipped archive.**

Current counts of the coupling in tracked bytes: `SBOM.json` 118 references,
`THIRD-PARTY-NOTICES.md` 74 references, both carrying the `sovereign:source-lock` property value
`modules/sow/tools/spike_compositor/package-lock.json`.

## Why this is parked and not fixed

- X-2's authorised steps are: read the existing `.gitattributes` files, create the root one, prove
  no product dependency, verify archive contents. Editing the release-identity generator is not
  among them, and **S-7** confines me to the fewest bytes that satisfy the item.
- Changing `NODE_LOCKS` changes what the release **declares about itself**. That is release-identity
  content, which R2 §7 and §9 place with the operator and reviewer, not the builder. **S-9**: park,
  do not substitute a different solution.
- It is not a functional break. Nothing fails: the generator runs in the worktree, where the lock
  is still present and still tracked. Only an archive **consumer** running the generator would hit
  a missing file, and such a consumer already cannot run it (the module `.venv` directories it reads
  are gitignored and absent from any archive).

## Direction of the error

**Over-declaration, not under-declaration.** The SBOM lists more than ships. That is the safer of
the two failure directions — a scanner sees a component that is absent rather than missing one that
is present — but it is still wrong for an enterprise SBOM, and it is the same class of defect as
A-3: a distributed document that disagrees with the distribution it describes.

Note the entry is already labelled: the lock is registered under the name
`sow-spike-nonproduct`, and each component records
`sovereign:source-lock = modules/sow/tools/spike_compositor/package-lock.json`. A reader can
mechanically identify which components came from the spike. Nothing is hidden.

## Builder recommendation (a recommendation only — it authorises nothing)

Drop the `sow-spike-nonproduct` entry from `NODE_LOCKS` and the matching
`modules/sow/tools/spike_compositor/node_modules` entry from `NATIVE_ROOTS`, then regenerate. That
makes the SBOM describe exactly what ships and removes the last trace of the two high-severity pins
from distributed bytes. It is a three-line change with a coupled test update.

Against it: the CONVERGE-01 release notes list "spike Electron/extract-zip nonproduct" as an
accepted limitation, and some reviewers prefer a component to remain visible in the SBOM once it
has been named in notes. That is a judgement about disclosure, not about correctness, and it
belongs to the reviewer and operator.

## What would unblock it

An operator ruling, or a reviewer instruction, choosing one of:

1. **Remove** the spike from `NODE_LOCKS` / `NATIVE_ROOTS` so the SBOM matches the archive.
   (Builder's recommendation.)
2. **Keep** it and record in the release notes that the SBOM deliberately over-declares the
   excluded non-product spike, naming `electron 31.7.7` and `extract-zip 2.0.1` as declared-but-not-shipped.

Either is a small, bounded change. What a builder may not do is pick one on the operator's behalf.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
