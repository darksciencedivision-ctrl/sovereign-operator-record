# X-2 — Exclude the non-product spike compositor from release archives (A-2 / OD-25)

Builder seat: `claude-code (opus-5)` · commits `3d298c4` then `a3fed64` · UTC 2026-08-29T18:33:03Z

## Why this was not already closed

`C2/PARKED-DOSSIERS.md` wrote its own closure condition for
`C2-RISK-SPIKE-ELECTRON-LOCK-HELD-NONPRODUCT`: exclusion from release artifacts must be verified
by archive contents, *"or the risk remains release-blocking."* Phase W measured that condition as
**false** at `32f191e`. The spike shipped in both candidate ZIPs, from two tracked roots, and both
`package-lock.json` copies resolve `electron 31.7.7` and `extract-zip 2.0.1` — the two
high-severity findings.

## Step 1 — how a root `.gitattributes` interacts with the two existing ones

Read before writing anything:

```
modules/sow/.gitattributes           * text=auto eol=lf
                                     *.png binary
                                     *.zip binary
                                     docs/canonical/** -text
modules/distillery/.gitattributes    * text=auto eol=lf
                                     *.bundle binary
```

Neither sets `export-ignore`. Git resolves attributes **per attribute**, not per file: a deeper
`.gitattributes` wins only for the attributes it actually sets. The new root file sets *only*
`export-ignore` and no `text`/`eol`/`diff` attribute at all, so normalisation in those two
subtrees is untouched. Verified rather than assumed:

```
git check-attr export-ignore -- modules/sow/tools/spike_compositor/package-lock.json   set
                                evidence/cpm1/before-b/.../spike_compositor/main.js    set
                                modules/sow/apps/desktop/main.js                       unspecified
git check-attr text eol      -- modules/sow/apps/desktop/main.js        text: auto, eol: lf
                                modules/distillery/README.md            text: auto, eol: lf
```

## Step 3 — dependency proof

Every tracked reference to `spike_compositor` from outside the two spike roots was enumerated and
classified. The only three in **live product code** are prose comments stating that the spike is
*not* the real component:

```
modules/sow/apps/desktop/main.js:5        "This is NOT the throwaway Phase-1 spike
                                           (tools/spike_compositor). It is the real workspace"
modules/sow/terminal/compositor/tiling.js:6  "`tools/spike_compositor/lib/layout.js` only sketched"
modules/sow/tools/live/enumerate_pane_picker.py:8  "like `tools/spike_compositor` … it is NOT part of"
```

No import. No runtime path use. Everything else is generated documents (`SBOM.json`,
`THIRD-PARTY-NOTICES.md`), historical evidence manifests, and docs.

One **functional** reference exists in release tooling, and it is reported rather than changed:
`generate_release_identity.py` reads the spike lock as a `NODE_LOCKS` entry. See
`PARKED-SBOM-SPIKE-COUPLING.md` — the regenerated SBOM will declare components for source that no
longer ships. Over-declaration, not under-declaration; parked for an operator ruling because
changing what a release declares about itself is not a builder's call.

## The two commits, and why there are two

The first attempt used only the `dir/**` form. Measuring the resulting archive found **2 surviving
members** — the two `spike_compositor` directory entries themselves, size 0. `dir/**` matches a
directory's *contents*, not the directory entry. Both forms are now present:

```
modules/sow/tools/spike_compositor                          export-ignore
modules/sow/tools/spike_compositor/**                       export-ignore
evidence/cpm1/before-b/modules/sow/tools/spike_compositor    export-ignore
evidence/cpm1/before-b/modules/sow/tools/spike_compositor/** export-ignore
```

The fix is a second commit rather than an amend of `3d298c4`, so the incomplete first attempt
stays visible in history (S-10 forbids rewriting any existing commit). Had I measured only
`git ls-files` and not the archive itself, I would have reported this item closed while two
entries still shipped.

## Pass-after (`pass-after-archive.txt`)

```
spike_compositor entries in git archive HEAD : 0        (required 0)
modules/sow/tools/spike_compositor           : 28 files still tracked
evidence/.../spike_compositor                : 28 files still tracked
SOW desktop suite                            : 1104 tests, 1104 pass, 0 fail
SOW terminal suite                           :  225 tests,  225 pass, 0 fail
```

Archive file entries 3565 → 3510: **+1** (`.gitattributes`, new) **−56** (spike files). No
unexplained delta.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
