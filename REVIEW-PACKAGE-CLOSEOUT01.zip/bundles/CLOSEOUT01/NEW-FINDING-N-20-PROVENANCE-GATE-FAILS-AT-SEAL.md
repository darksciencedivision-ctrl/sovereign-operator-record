# NEW FINDING · N-20 — `provenance_cross_hash_check` FAILS at the seal commit

Raised by: builder seat `claude-code (opus-5)` · CLOSEOUT-01 Phase Y · UTC 2026-08-29T18:47:58Z
Severity (builder assessment): **HIGH** — a release gate is RED at the commit proposed for seal
Status: **found, measured, NOT fixed** — out of X-1..X-5 scope. Requires an operator ruling.
Not in the validator audit. **S-12 disposition: traces to a named pre-existing cause at `32f191e`;
no part of it is attributable to this loop.**

## The finding

```
provenance_cross_hash_check: FAIL
  debate       UNKNOWN  hash matches no registered identity (expected 1087827b…)
  distillery   UNKNOWN  hash matches no registered identity (expected 8448d68a…)
  sovereign    OK       hash equals the module's own registered source hash
  sow          UNKNOWN  hash matches no registered identity (expected 3ef75c33…)
  tokencenter  PENDING  registry entry carries no source_sha256 yet
exit 1
```

Three of five modules fail. The gate compares each module's
`modules/<m>/INSTALL-PROVENANCE.json.source_sha256` against
`tools/release/module_source_registry.json`.

## Root cause, pinned exactly — and it is worse than a stale registry

Phase Z's dry-run regeneration exposed the real mechanism. `generate_module_provenance.py`
digests a module by `git ls-files -- modules/<m>`, excluding only the record file itself
(`content_digest`, lines 105–125). The seal commit `32f191e` **added a new tracked file inside
three of the module directories it was digesting**:

```
modules/debate/INSTALL-PROVENANCE.json.pre-CONVERGE01
modules/distillery/INSTALL-PROVENANCE.json.pre-CONVERGE01
modules/sow/INSTALL-PROVENANCE.json.pre-CONVERGE01
```

At generation time those backups existed but were **untracked**, so `git ls-files` did not list
them and the digest covered N files. The instant the commit landed they became **tracked**, so the
same generator over the same commit now covers N+1 files and returns a different digest.
`sovereign` got no backup, and `sovereign` is the one module whose gate verdict is still OK.

Proven by recomputation at HEAD:

```
debate      55 files                      2135f7d8…  (neither)
            54 files, .pre-CONVERGE01 excluded  03d055d6…  == the record committed at the seal
            registry expects              1087827b…
distillery 206 files                      1efcf7c0…  (neither)
           205 files, .pre-CONVERGE01 excluded  c082cab7…  == the record committed at the seal
            registry expects              8448d68a…
sow        957 files                      d2dd119e…  (neither)
           956 files, .pre-CONVERGE01 excluded  bf4aa033…  == the record committed at the seal
            registry expects              3ef75c33…
```

So there are **two** independent divergences, not one:

1. **The registry is stale** against the records — what the gate reports.
2. **The records cannot reproduce themselves.** Re-running the generator at the exact commit the
   record describes yields a different `source_sha256` than the record carries. The record's own
   `content_file_count` says 54 where the commit contains 55.

Layer 2 is the more serious one. It defeats R2 §9(9) — *"a successor can reproduce the release
from recorded refs, artifacts, and procedures"* — for three of five modules. A provenance record
that a successor cannot reproduce from the commit it names is not provenance.

And the mechanism is A-1's, exactly: **a record placed inside the set it describes.** A-1 put the
archive's hash in a file that enters the archive. This puts a backup of the provenance record in
the directory the provenance record digests.

## The original framing (retained — the registry staleness is real too)

```
module       registry says     record at a45fb98   record at 32f191e (SEAL)   verdict at seal
debate       1087827b…         1087827b…           03d055d6…                  UNKNOWN (FAIL)
distillery   8448d68a…         8448d68a…           c082cab7…                  UNKNOWN (FAIL)
sow          3ef75c33…         3ef75c33…           bf4aa033…                  UNKNOWN (FAIL)
sovereign    150e518e…         150e518e…           150e518e…                  OK
```

Commit `32f191e` — "C6: regenerate provenance, identity, and release manifest", the seal itself —
regenerated three `INSTALL-PROVENANCE.json` records and changed their `source_sha256`. It did
**not** regenerate `tools/release/module_source_registry.json`, whose last modification is
`a945d99`, two commits earlier. Verified: the registry is byte-identical at `32f191e` and at HEAD.

At `a45fb98`, the commit before the seal, all four hashes agreed and the gate passed. **The seal
commit broke its own provenance gate.**

This is A-1's mechanism exactly — regenerate one side of a coupled pair and not the other — and it
is now the third instance found in this candidate:

| # | where | status |
|---|---|---|
| A-1 | `RELEASE-MANIFEST.json` vs the release artifacts | fixed in X-1 |
| N-19 | `shell/BUILD-MANIFEST.txt` vs the `shell/` tree | reported, out of scope |
| **N-20** | provenance records vs `module_source_registry.json` | **this finding** |

## Why the audit did not catch it

The validator audit's §1 records `check_governance_bom` PASS and `check_model_consistency` PASS
(T-10). It does not list `provenance_cross_hash_check` among the gates it ran. The CONVERGE-01
builder's own C5 log **does** contain a passing run of this gate
(`bundles/CONVERGE01/C5/provenance-cross-hash.log`, debate `record_source_sha256` `1087827b…`,
verdict OK) — but that log was captured at 16:17Z, and the C6 regeneration that broke it ran at
16:20–16:21Z. The passing evidence predates the bytes it is cited for.

That is precisely what R2 §5 forbids: *"The complete deterministic suite re-runs after the last
product/dependency/configuration byte change; no stale result may be cited for bytes created after
that test."* The C5 gate logs are stale against the seal.

## Why I did not fix it

Fixing it means choosing which side is authoritative, and that choice **declares the source
identity of three modules**:

- **Regenerate the registry** to the new record hashes — asserts that the C6 records are correct
  and the registry was stale.
- **Revert the three records** to their `a45fb98` values — asserts the C6 regeneration was wrong.

Those are opposite claims about provenance. R2 §8 makes provenance and source identity an
operator/reviewer matter; R2 §4 puts C-2/C-3 provenance repair in Batch 2 scope, which this
directive does not open. Neither option is in X-1..X-5, and **S-9** forbids substituting my own
solution. A builder that picks one is authoring an acceptance.

I also cannot tell you which is right without evidence I do not have: the gate only reports
disagreement, and determining which hash truly describes each module's source requires
re-deriving each module's content identity from the frozen baselines — Batch-2 work.

## What the operator needs to decide

1. Which side is authoritative — the C6-regenerated records, or the registry.
2. Whether `32f191e` remains a valid seal basis given that a release gate is red at it. Note the
   CLOSEOUT-01 seal will be a **new** commit, so this can be corrected before sealing — but only
   under an authorisation that covers provenance bytes.
3. `tokencenter` is separately PENDING — its registry entry has carried no `source_sha256` since
   before this run. That is a pre-existing open item, not a regression.

## Builder recommendation (authorises nothing)

Re-run `generate_module_provenance.py` and the registry together, as one coupled act, under a
scope grant that names them — then make the pairing mechanical so it cannot drift again, the way
X-1 made the manifest's hash sections mechanically inescapable. A regeneration step that updates
one of two coupled provenance authorities is the defect; a gate that is only run before the last
regeneration is what let it ship.

Until ruled, CLOSEOUT-01 carries this gate as **RED, pre-existing, disclosed** — not as a pass,
and not as something this loop caused.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
