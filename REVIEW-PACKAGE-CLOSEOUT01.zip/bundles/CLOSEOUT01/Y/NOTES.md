# PHASE Y — deterministic program at final bytes

Builder seat: `claude-code (opus-5)` · UTC 2026-08-29T18:47Z–19:05Z
Bytes under test: `be8dcb0` (last product/tooling commit of Phase X), porcelain clean throughout.
Measured results only. No adjectives, no historical counts.

## Suites

| suite | command | expected | **measured** |
|---|---|---|---|
| SOW desktop | `node --test test/*.test.js` | 1104 | **1104 tests, 1104 pass, 0 fail** |
| SOW terminal | `node --test test/*.test.js` | 225 | **225 tests, 225 pass, 0 fail** |
| Token Center | `py -3.12 -B -m unittest discover -s tests` | 32 | **32 tests, OK** |
| shell | `py -3.12 -B -m unittest discover -s shell/tests` | 166 | **166 tests, OK** |
| tools/release | `py -3.12 -B -m unittest discover -s . -p 'test_*.py'` | 72 + additions | **84 tests, OK** |

`tools/release` new total **84**, from 72 at `32f191e`: **+9** from X-1
(`test_release_manifest_check.py` 7 → 16), **+2** from X-4 (`test_rebase_adapters.py` 5 → 7),
**+1** from X-5 (`test_generate_release_identity.py` 1 → 2).

**S-5 applied after the shell suite:** 13 tracked paths were rewritten by the run (12 under
`evidence/`, plus `shell/BUILD-MANIFEST.txt`). Each was restored from HEAD and **hash-verified**
by comparing `git hash-object` against `git rev-parse HEAD:<path>` — all 13 VERIFIED. Porcelain
empty afterwards. Log: `../X-4/s5-restoration.txt` and repeated at final bytes.

## Gates

| gate | invocation | verdict |
|---|---|---|
| package boundary | `--root . --allowlist tools/release/fixture_allowlist.json`, inside a clean `git archive HEAD` extract | **PASS** — 3497 scanned, 0 violations, 0 credential hits, 1982 quarantined-historical, 5 allowlisted |
| release manifest | `--root .` | **PASS (0 problems)** |
| governance BOM | `--root .` | **PASS** |
| model consistency | `--root .` | **PASS** |
| innerHTML sink audit | `--file modules/sow/apps/desktop/renderer/renderer.js --ledger tools/release/innerhtml_audit.json` | **PASS** — 39 templates, 112 interpolations (ESCAPED 73, ESCAPED-BY-CONSTRUCTION 17, STATIC 9, COMPOSITE 9, GUARANTEED 3, GUARANTEED-INTEGER 1) |
| provenance cross-hash | `--root . --registry tools/release/module_source_registry.json` | **FAIL — pre-existing at the seal. See N-20.** |

Two gates were first run with wrong arguments and produced meaningless output (`provenance` with no
`--registry`; `innerhtml` against the wrong file, reporting `templates_in_scope=0`). Both were
re-run against the arguments their own sources and ledger define, rather than accepting a
convenient number. The innerHTML target came from the ledger's own `scope_file` field.

### provenance_cross_hash_check — RED, and not mine (S-12)

```
debate       UNKNOWN  hash matches no registered identity (expected 1087827b…)
distillery   UNKNOWN  hash matches no registered identity (expected 8448d68a…)
sow          UNKNOWN  hash matches no registered identity (expected 3ef75c33…)
sovereign    OK
tokencenter  PENDING  registry entry carries no source_sha256 yet
```

Traced to a named cause: the seal commit `32f191e` itself regenerated three
`INSTALL-PROVENANCE.json` records without regenerating
`tools/release/module_source_registry.json` (last touched `a945d99`, two commits earlier). At
`a45fb98` all four agreed. None of this gate's inputs was modified by CLOSEOUT-01 — verified with
`git diff --name-only 32f191e..HEAD`. Full analysis and the operator decision required:
`../NEW-FINDING-N-20-PROVENANCE-GATE-FAILS-AT-SEAL.md`.

**S-12 satisfied:** the only failing gate traces to a pre-existing baseline cause, and no failure
is attributable to work done in this loop.

## Archive delta — accounted item by item, zero unexplained

```
W-8 baseline (32f191e) file entries : 3565
final (be8dcb0)        file entries : 3497
delta                               : -68

REMOVED
  -56   X-2  spike_compositor excluded (28 files × 2 tracked roots)
  -13   X-3  backup snapshots excluded (7 .pre-CONVERGE01, 5 .pre-rebase, 1 .pre-add08)
ADDED
   +1   X-2  .gitattributes (new root attributes file)

reconciliation: 3565 +1 -69 = 3497  (measured 3497)  -> BALANCED
UNEXPLAINED entries: 0
```

## C4 proxy install cycle — re-run, because X-4 landed

Required by §5: X-4 changed `rebase_adapters.py`, which is install tooling, so the prior cycle's
evidence no longer binds.

Built into a **Y-scoped scratch output directory**, deliberately not into `release-artifacts/`:
Phase Z cuts the real artifacts after the seal commit, and pre-populating that directory before the
seal would recreate the very ordering defect X-1 exists to fix.

| step | result |
|---|---|
| 1 `build_release.ps1 -OutputDir <scratch>` | exit 0 — `build-release.log`. Emitted the new **v2** build manifest with nested per-sidecar hashes. source `bc51ab4a…`/29,740,074 B, install `717ae7f4…`/29,908,008 B |
| 2 `install.ps1 -Dest "…\install test area" -TargetDir "…\install test area\shortcut targets" -Artifact <install.zip>` | exit 0 — `install.log`, **24,402 created paths recorded** |
| 3 `verify_install.ps1 -Dest` | exit 0 — `verify-install.log`, **21,633 file hashes and exact path set verified**; sovereign / debate / SOW desktop imports OK |
| 4 boot `Start-Shell.ps1 -Port 5199 -NoBrowser` from the install root | **HTTP 200**, 3,727 bytes, `<title>Sovereign Workspace Shell</title>`; `Modules loaded: ['debate','distillery','llamacpp','sovereign','sow','tokencenter']` — all six, including the neutralised llamacpp |
| 5 clean stop | listener pid 33616 stopped; **port 5199 free**; **no process running from the install test area** |
| 6 post-boot exact-set | exit 0 — 21,633 hashes and exact path set verified again after the boot |
| 7 `uninstall.ps1 -Dest` | exit 0 — `{"claim":"removed exactly the recorded paths","removed_recorded_paths":24402,"remaining_recorded_paths":0}` |
| 8 destination and test area | destination emptied, then the test-area directory removed. **No `Sovereign Workspace.lnk` on the real Desktop or Start Menu** (checked directly) |

Worktree porcelain: **empty** before and after the entire cycle.

### The one exception in the shell log, explained rather than waved past

```
Exception occurred during processing of request from ('127.0.0.1', 64685)
  … http/server.py line 404, in handle_one_request
    self.raw_requestline = self.rfile.readline(65537)
ConnectionResetError: [WinError 10054] An existing connection was forcibly closed by the remote host
```

This is **my own probe client**, not the product. `Invoke-WebRequest` completed its request, got
200, and closed its keep-alive socket; `http.server`'s per-connection thread was blocked reading
the next request line and surfaced the reset. It is attributable to the measurement method, on the
port my probe used, and not to any shipped byte. R2 §5 bars *unexplained* warnings from
unconditional acceptance; this one is explained and reproducible on demand.

### Two measured behaviour changes from X-4, disclosed

1. **`SKIPPED-WITH-RECORD llamacpp` no longer appears in the install log** (count: 0; it was 1).
   After X-4 neutralised llamacpp's paths, they match neither `OLD_ROOT` nor `source_modules_root`,
   so `_mapped` returns them unchanged, no change is recorded, and the optional-skip record never
   fires. The installed `llamacpp.json` correctly keeps its placeholder — the runtime is not there
   to point at — but the install log is now **silent** about llamacpp where it used to say
   explicitly that an optional adapter had been skipped. That is a real reduction in
   observability, and the reviewer should weigh it against the removal of three foreign paths from
   distributed bytes.
2. **No `/launch/argv/0` rewrite appears in the log.** Expected on this host and not a failure:
   `install.ps1:94` resolved the destination interpreter to the same path already in the committed
   config, because the source and destination machine are the same. `new == old`, so no change is
   recorded. The unconditional rewrite is proven by test
   (`test_placeholder_interpreter_is_rewritten_unconditionally`), which is the only way to
   demonstrate it without a second machine.

### Limitation, restated because it matters

This cycle proves install/verify/boot/uninstall **mechanics and layout only**. It does **not**
prove clean-room independence: this host already has Python 3.12, node and Ollama, and the venv
and `npm ci` steps drew from public registries. A true clean-room VM install remains a residual
operator/reviewer item. Nothing here should be read as evidence of it.

## Parked in Phase Y (E-6)

Model- and service-dependent legs for Debate, SOVEREIGN and Distillery are parked as **E-6**. No
model was loaded, no provider was called, no billed operation ran. Coverage not run is not claimed.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
