# X-5 — Record the release-identity commit convention (A-4)

Builder seat: `claude-code (opus-5)` · commit `be8dcb0` · UTC 2026-08-29T18:46Z

## The contradiction being closed

`VERSION.json.source_commit` was `a45fb98…` (the C4 commit) while the seal was `32f191e…` and
`release-build-manifest.json` recorded `32f191e…`. Two identity documents disagreed, and the
CONVERGE-01 R2 instruction that produced the disagreement — *"Fill VERSION.json's `source_commit`"*
with the final commit — was **unsatisfiable**. The validator accepted authorship of that defect;
the prior builder parked it correctly rather than fabricating a value.

Phase W proved the impossibility empirically rather than restating it. In a throwaway repository
with author and committer dates pinned so file content was the only variable:

```
attempt 1: commit introducing the file = dcf09c7a5d186fa3940b12d3f389c85879733fe9
attempt 2: wrote that hash into the file, commit is now = c3c64c49db733e2c4157bf8c233cd05f8f31e822
RESULT: NOT a fixed point. Writing the hash changed the hash.

commit object:  tree 4740b93f…
tree contents:  100644 blob d3363a06…  V.json
```

The commit hash is taken over the tree; the tree contains the file's blob. A fixed point would
require a deliberate SHA-1 preimage.

## What changed

**`VERSION.json`** gains two fields:

```json
"source_commit_definition": "last product/tooling commit; NOT the seal commit. A tracked file
                             cannot carry the hash of the commit that introduces it.",
"seal_commit_record": "release-artifacts/release-build-manifest.json"
```

The first states the rule inside the file, so a reader who has only this document cannot mistake
`source_commit` for the seal. The second names the file that does hold the seal commit.

**`generate_release_identity.py`** emits both from one `SEAL_COMMIT_RECORD` constant. This matters:
`VERSION.json` is a generated file, so hand-adding fields to it risks drift the moment Phase Z
regenerates. A guard asserted the hand-added bytes are byte-identical to what the generator
produces before the commit was made:

```
GUARD OK: hand-added fields are byte-identical to what the generator emits
```

**`README-GATE-POLICY.md`** documents the convention and the general rule it comes from — *a hash
belongs in a file that is not itself an input to the thing being hashed* — tying together X-1's
manifest split and Phase Z's ordering (artifacts are cut **after** the seal commit, never before).

**Tests**: the existing generator test now asserts both fields; a new test,
`test_version_document_never_claims_to_hold_the_seal_commit`, proves the generator never invents a
seal hash and fails if a future seat reintroduces a field promising otherwise.

## Measured

```
tools/release suite : 81 -> 84 tests, OK
release_manifest_check : PASS (0 problems)
```

## S-4 coupling — note for the reviewer

Five coupled manifest hashes were refreshed in the same commit. `VERSION.json` is enumerated in
**two** sections, `batch_files` *and* `identity_documents`, and both were updated.

Worth recording: before X-1, `identity_documents` was one of the three sections the checker never
looked at. Had X-5 landed on the old checker, the `identity_documents` copy of the `VERSION.json`
hash could have gone stale silently — the exact A-1 mechanism, one commit later, in a section
nobody had noticed. It is now verified.

## Deferred to Phase Z, by design

`VERSION.json.source_commit` still reads `a45fb98…`. Correct at this point: per the convention it
must name the **last product/tooling commit**, which is not known until the X phase ends. Phase Z
step 2 regenerates release identity with the final tooling commit, and step 5 writes the seal
commit into the untracked build manifest.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
