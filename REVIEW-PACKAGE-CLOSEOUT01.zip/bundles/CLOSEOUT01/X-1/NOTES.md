# X-1 — Break the release-manifest circularity (A-1 / OD-24)

Builder seat: `claude-code (opus-5)` · CLOSEOUT-01 · UTC 2026-08-29T18:26:09Z
Parent commit: `32f191e988e4690f5d68c83d541ca8668445dd03`

## Step 1 — locate the generator · REPORTED DEVIATION

The directive says: *"Locate the generator that emits `release_archives_gitignored` (read the
source; do not assume which script it is)."*

**There is no such generator.** Searched every `.py` and `.ps1` in the tree:

```
grep -rn "release_archives_gitignored" --include=*.py --include=*.ps1 .   -> no hits
grep -rn "RELEASE-MANIFEST" --include=*.py --include=*.ps1 .
    tools/release/generate_release_identity.py:220   READS it (module versions only)
    tools/release/release_manifest_check.py          READS it (validation)
    tools/release/test_release_manifest_check.py     READS it (tests)
```

`RELEASE-MANIFEST.json` is **not machine-generated at all**. No script writes it; it is
maintained by hand by the builder seat of the day. That is itself part of why A-1 happened —
there is no producer whose ordering could be fixed, so the C6 "regeneration" was a manual
transcription of hashes measured at one moment, committed, and then invalidated 32 seconds later
by the artifact recut (W-3).

The fix therefore lands on the file directly rather than on a generator. Recorded here so the
deviation from the directive's literal wording is visible and not inferred.

## Step 1 — the structural change

Removed the whole `release_archives_gitignored` array (17 hash-bearing entries) and replaced it,
in the same key position, with a non-hash reference field:

```json
"release_archive_hash_authority": "release-artifacts/release-build-manifest.json"
```

`policy` was extended to state the rule in the file itself: this manifest covers **tracked bytes
only** and carries no release-artifact hash, because a tracked manifest enters the archive it
would describe, so the archive's hash cannot live inside it.

Hash-bearing objects in the manifest: **80 -> 63**, and all 63 now sit in sections the checker
verifies.

## Step 2 — `release-build-manifest.json` becomes the sole, complete authority

`tools/release/build_release.ps1` previously hashed only the two composite ZIPs it built. The six
per-module archives cut by the C3 tooling had **no authoritative hash record anywhere** once the
`RELEASE-MANIFEST.json` section was removed. The producer now:

- enumerates **every** `*.zip` in the output directory, sorted by name, not just the two it built;
- requires each artifact to have a `.sha256` sidecar and **throws** if one is missing;
- cross-checks the hash *recorded inside* each sidecar against the freshly measured artifact hash
  and throws on disagreement;
- records, per artifact: `name`, `bytes`, `sha256`, and a nested `sidecar` object with the
  sidecar's own `name`, `bytes` and `sha256`;
- records `artifact_count` and a `hash_authority_note` stating why these hashes cannot live in
  `RELEASE-MANIFEST.json`;
- keeps `source_commit` (the seal commit) as before.

Schema bumped `sovereign.release-build.v1` -> `v2` because the artifact objects changed shape.
The file still excludes itself by construction: writing its own hash into itself would change
that hash — the same self-reference bar proven in W-7.

Not executed in this commit: artifacts are cut in Phase Z, after the seal, per §6.
`powershell -NoProfile` tokenizer parse check: **PARSE OK, 585 tokens**.

## Step 3 — the checker hardened (S-15)

`tools/release/release_manifest_check.py`:

1. `identity_documents` and `ui_assets` are now **actually verified** (path exists, SHA-256
   matches). W-2 found these were unverified too — the audit named only
   `release_archives_gitignored`, but the blindness covered three sections and 25 of 80 objects.
   S-15's remedy for a carried-but-unchecked hash is to check it, not to delete it.
2. A final sweep walks the **entire** manifest for any object carrying both `path` and `sha256`
   and reports every one the checks above did not actually verify, failing the gate.

Membership is tracked by **object identity** (`id(item)`), not by key name. That matters: a
key-name allow-list would still let a new hash-bearing group be added *inside* an already-handled
section (say `modules.sovereign.extra_files`) and pass. Identity tracking catches it, and
`test_hash_added_inside_a_handled_section_is_still_caught` proves it does.

Existing problem-message formats were left byte-identical so no existing test needed touching
(S-6, S-7).

## Step 4 — fail-before and pass-after

**Fail-before** (`fail-before.txt`) was captured against the **pristine bytes of `32f191e`**:
the working tree was returned to HEAD (`git status --porcelain` empty, shown in the capture) and
the sealed checker was run. All four cases returned **PASS** — the defect is the silence:

| case | original checker |
|---|---|
| A. real manifest, 17 provably wrong release-artifact hashes | **PASS** (0 problems) |
| B. invented hash-bearing section, hash wrong by construction | **PASS** (0 problems) |
| C. corrupted `identity_documents` hash | **PASS** (0 problems) |
| D. corrupted `ui_assets` hash | **PASS** (0 problems) |

A first capture attempt was discarded and re-taken: it had been run against a tree already
carrying my in-flight edit, and the checker file is itself a `batch_files` entry, so it reported
one unrelated problem. A second attempt against a `git archive HEAD` extract was also discarded —
the manifest enumerates two gitignored Distillery `dist/` artifacts that do not exist in an
archive extract, so that root produces two false "file missing" problems. Both discards are
recorded rather than hidden; only the third capture is evidence.

**Pass-after** (`pass-after.txt`), same four cases against the hardened checker:

| case | hardened checker |
|---|---|
| A. real manifest (artifact hashes now removed entirely) | **PASS** — expected PASS |
| B. invented hash-bearing section | **FAIL** — `unverified hash-bearing entry at $.a_future_section…[0]` |
| C. corrupted `identity_documents` hash | **FAIL** — `identity_documents: hash mismatch at LICENSE` |
| D. corrupted `ui_assets` hash | **FAIL** — `ui_assets: hash mismatch at shell/static/app.css` |

Gate: `release_manifest_check: PASS (0 problems)` exit 0.

Nine tests added, in two new classes:

```
UncheckedHashSectionTests
  test_unknown_hash_bearing_section_is_rejected
  test_unknown_section_rejected_even_when_its_hash_is_correct   (rejected for being
                                                                 unverified, not for being wrong)
  test_hash_added_inside_a_handled_section_is_still_caught
  test_release_archive_hashes_are_not_carried_by_this_manifest  (structural regression guard)
HandledSectionsStillValidateTests
  test_real_manifest_still_passes_after_hardening
  test_every_hash_bearing_entry_is_covered
  test_corrupted_identity_document_hash_detected
  test_corrupted_ui_asset_hash_detected
  test_missing_identity_document_detected
```

Measured: `test_release_manifest_check.py` **7 -> 16 tests**, all pass.
Whole `tools/release` suite: **72 -> 81 tests**, `OK`, 0 failures.

## Step 5 — manifest not regenerated

Honoured. No tracked-byte hash was recomputed wholesale; the full regeneration happens once, in
Phase Z, after the last byte change. What this commit did to the manifest is **structural**
(remove a section, add a reference field, restate the policy) plus the three coupled `batch_files`
hash updates S-4 requires for the files this commit changed:

```
tools/release/build_release.ps1               4790b971… -> 76769ff3…
tools/release/release_manifest_check.py       604304d1… -> a421e539…
tools/release/test_release_manifest_check.py  ea7597f7… -> 3de4eb3a…
```

Without those three, the gate would have gone red on this commit for a reason unrelated to the
defect. Leaving them stale would have been the same class of error as A-1 itself.

## Changed file set

```
RELEASE-MANIFEST.json                          (section removed, field added, policy, 3 hashes)
tools/release/build_release.ps1                (enumerate all artifacts + sidecars)
tools/release/release_manifest_check.py        (S-15 hardening, 2 sections now verified)
tools/release/test_release_manifest_check.py   (+9 tests)
```

Encoding assertion (S-2): all four files UTF-8, **no BOM**, **0 CRLF**.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
