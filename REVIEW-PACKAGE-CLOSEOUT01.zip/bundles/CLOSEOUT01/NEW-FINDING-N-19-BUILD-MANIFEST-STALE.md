# NEW FINDING · N-19 — `shell/BUILD-MANIFEST.txt` is stale at the seal commit

Raised by: builder seat `claude-code (opus-5)` · CLOSEOUT-01 · UTC 2026-08-29T18:42:14Z
Severity (builder assessment): **MEDIUM** — same defect class as A-1, in the shell
Status: **found, measured, NOT fixed** — out of X-1..X-5 scope. Reported for reviewer/operator.
Not in the validator audit. Found while satisfying S-5 after the Phase-Y shell-suite run.

## The finding

`shell/BUILD-MANIFEST.txt` is a tracked manifest of the `shell/` subtree: one SHA-256 per file.
At the seal commit `32f191e` it does not describe the tree it ships with.

Measured against `HEAD:shell/**` at `32f191e`, before any CLOSEOUT-01 change:

```
manifest entries recorded : 67      (header: "# entries: 67")
  match                   : 48
  MISMATCH                : 19
  MISSING                 : 0
shell/ tracked files      : 75      (excluding BUILD-MANIFEST.txt itself and __pycache__)
  omitted from manifest   : 8
```

**19 of 67 recorded hashes are wrong.** Among them are every adapter config, the install config,
`server.py`, `startup_test.py`, `app.css`, `app.js` and seven test files:

```
config/install.json          manifest 1ca7821b…   actual 960ccf0f…
modules/debate.json          manifest 5f57918f…   actual 90da913b…
modules/distillery.json      manifest 661d3605…   actual 876b83f8…
modules/sovereign.json       manifest 28d83596…   actual 33653feb…
modules/sow.json             manifest b2419a9f…   actual c815f690…
modules/tokencenter.json     manifest 94678a96…   actual 4390c944…
src/server.py                manifest 54d391c5…   actual 46f2ff00…
src/startup_test.py          manifest dfae2514…   actual 9c05df80…
static/app.css               manifest 88172e1f…   actual b2407ede…
static/app.js                manifest 8404bdb7…   actual 1aeaef2a…
static/workspace-bg.svg      manifest 18cccf8a…   actual 43d7de35…
tests/test_failure_classes.py, test_frontend.py, test_hardening.py, test_render.py,
tests/test_shell.py, test_states.py, test_tokencenter_loopback_and_csrf.py, test_zz_evidence.py
```

**8 tracked files are absent from it entirely:**

```
modules/debate.json.pre-rebase        modules/sovereign.json.pre-rebase
modules/distillery.json.pre-rebase    modules/sow.json.pre-rebase
modules/tokencenter.json.pre-rebase   static/sovereign.ico
static/workspace-bg-v2.png            tests/test_startup_evidence.py
```

## Root cause

Its own header dates it:

```
# SWS-BUILD-MANIFEST v1
# utc: 2026-08-28T16:55:59Z
# producer: claude-code REM-01
```

It was generated on **2026-08-28**, before the whole CONVERGE-01 run of 2026-08-29 — before the
C0 UI adoption (`1f0a59c`, which changed `app.css` and `workspace-bg.svg` and added
`workspace-bg-v2.png`), before N-13b's adapter rebase (`e03811e`, which rewrote all five adapter
configs and created the five `.pre-rebase` backups), and before OP-3/OP-4/OP-1. It was never
regenerated after any of them.

The tell is exact: the manifest's recorded hash for `modules/debate.json`, `5f57918f…`, is the
hash of the file that is now `modules/debate.json.pre-rebase`. The manifest is describing the
pre-rebase tree.

## Why this is the A-1 defect class

A-1 was: *a tracked manifest carries hashes that no longer match the bytes, and nothing fails.*
This is the same thing one directory over. The shell suite regenerates
`shell/BUILD-MANIFEST.txt` as a side effect of running, and standing rule S-5 requires the
regenerated file be restored byte-exactly from HEAD afterwards — so the suite can never surface
the drift, and the stale file is what ships. 166/166 passes either way. I verified this: the suite
was green both before restoration (regenerated manifest present) and after (stale manifest
restored).

So the shell ships a self-description that is wrong in 19 places and silent about 8 files, and no
gate in the program looks at it.

## Why I did not fix it

- **S-5 is explicit and unconditional**: restore each rewritten path byte-exactly from HEAD after
  every shell-suite run. I did, and hash-verified all 13 restorations.
- Regenerating it is a **product-byte change** in neither X-1..X-5 nor Phase Z step 2, which names
  module provenance, release identity and `RELEASE-MANIFEST.json` — not this file. **S-7** confines
  me to the fewest bytes that satisfy the item; **S-9** says park rather than substitute.
- Committing a 30-insertion / 22-deletion manifest rewrite as a **side effect** of a test run is
  precisely the drive-by change the standing rules exist to prevent.

## One consequence of my own work, disclosed

X-4 neutralised the three foreign paths in `shell/modules/llamacpp.json`. That file's entry in
`BUILD-MANIFEST.txt` was one of the 48 that still matched. After X-4 it does not. **The count is
now 20 mismatches of 67, not 19.** One of those twenty is mine; nineteen were there when I
arrived. `shell/modules/llamacpp.json` is not enumerated in `RELEASE-MANIFEST.json.batch_files`,
so no other coupled site exists and the release-manifest gate is unaffected — it reports
`PASS (0 problems)`.

## Builder recommendation (authorises nothing)

Regenerate `shell/BUILD-MANIFEST.txt` in a commit of its own, authorised for that purpose, after
the last shell-byte change and before the seal — and then decide the harder question: a tracked
manifest that a test suite rewrites on every run, and that a standing rule then reverts, cannot
stay honest. Either the suite should stop writing it and a gate should verify it, or it should be
generated into an untracked location like `release-artifacts/`, the way X-1 moved release-artifact
hashes to `release-build-manifest.json`. The second is the same fix A-1 got, and for the same
reason.

Until then the release ships a shell manifest that disagrees with the shell.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
