# PHASE W — INDEPENDENT RE-DERIVATION OF THE VALIDATOR AUDIT

Builder seat: `claude-code (opus-5)` · CLOSEOUT-01 · SWS-REM-DIR-20260828 R2 + Annex A
Directive of record: `CLAUDE-CLOSEOUT-01-DIRECTIVE-20260829.md` sha256 `67753c34…1537c5`
Audit under re-derivation: `VALIDATOR-AUDIT-CONVERGE01-SEAL-20260829.md` sha256 `96eb2722…6bccff`
HEAD at derivation: `32f191e988e4690f5d68c83d541ca8668445dd03`, porcelain empty (exit 0)
UTC: 2026-08-29T18:16:48Z

The audit is an input, not an authority. Every finding below was re-derived from bytes on this
host. Where my measurement differs from the audit's, my measurement is recorded and the audit's
number is marked as not reproducible. No finding was fixed before it was confirmed.

## Summary

| check | audit finding | verdict |
|---|---|---|
| W-1 | A-1 manifest hashes stale | **VERIFIED** exactly (80 / 63 / 17) |
| W-2 | A-1 checker blind to that section | **VERIFIED, SCOPE ENLARGED** — blind to 3 sections, 25 objects, not 1 section / 17 |
| W-3 | A-1 root cause = C4-era capture | **VERIFIED** exactly, with the ordering proven from timestamps |
| W-4 | A-2 spike ships from 2 roots, vulnerable pins | **VERIFIED**; audit's "69 entries each" **NOT REPRODUCIBLE** — measured 33 |
| W-5 | A-3 13 backup files ship | **VERIFIED** exactly (7 / 5 / 1) |
| W-6 | N-18 dev identifiers ship | **VERIFIED for the 5 named files; PARTIAL overall** — true population is 107 / 264 files |
| W-7 | A-4 self-reference impossible | **VERIFIED**, proven empirically, not asserted |
| W-8 | baseline capture | **CAPTURED** — 3565 entries, gate PASS, 72 tests |

---

## W-1 (A-1) · Re-hash every `path`+`sha256` object in RELEASE-MANIFEST.json — VERIFIED

Command: `py -3.12 -B W/w1_manifest_hashes.py` (script and full output retained in this bundle as
`w1_manifest_hashes.py` / `w1-output.txt`). The script walks the entire JSON recursively; it does
not rely on knowing the schema.

```
TOTAL path+sha256 objects: 80
MATCH   : 63
MISMATCH: 17
MISSING : 0
```

Distribution by top-level key:

```
MATCH    modules: 7            MATCH    identity_documents: 4
MATCH    ui_assets: 4          MATCH    batch_files: 48
NONMATCH release_archives_gitignored: 17
```

**VERIFIED.** 80 total, 63 match, 17 mismatch, and all 17 mismatches live under exactly one JSON
key, `release_archives_gitignored` — the audit's numbers reproduce precisely. Every tracked-tree
hash is correct; every release-artifact hash is wrong. Example, as the audit cited it:

```
release-artifacts/sovereign-workspace-1.0.0-rc.1-source.zip
  manifest e4b3e3da9bc4ec6e7f1448dc0d3a87b5d0268fe5796bbfb04a2c65e2914ef329  29,820,189 B
  measured 27de97cda3875d375f0d799bb482c56a1a6d593d0debec624d3a99669eefe10d  29,856,463 B
```

## W-2 (A-1) · Which manifest keys does the checker traverse? — VERIFIED, WITH THE SCOPE ENLARGED

Read of `tools/release/release_manifest_check.py`. The function `check()` traverses exactly:

| source lines | traversed |
|---|---|
| 48–69 | `modules[].current_provenance_path` + `provenance_record_sha256` |
| 71–73 | `modules[].superseded_provenance_paths` (existence only, no hash) |
| 75–87 | `modules[].{locks, module_manifests, artifacts}` — `path`+`sha256` |
| 89–97 | `modules[].source_identity` consistency |
| 99–113 | top-level `batch_files` — `path`+`sha256` |

`release_archives_gitignored` is **not** among them. Confirmed by running it:

```
release_manifest_check: PASS (0 problems)     exit 0
```

The gate reports PASS while 17 of the hashes in the file it validates are wrong. The audit's
characterisation — "blind to that section by construction" — is exact.

**Enlargement (my finding, not the audit's).** The audit named one blind section. Mechanical
enumeration shows **three**:

```
top-level key                    hash-objs  traversed-by-checker
modules                                  7  YES
identity_documents                       4  NO  <-- BLIND
ui_assets                                4  NO  <-- BLIND
release_archives_gitignored             17  NO  <-- BLIND
batch_files                             48  YES
```

25 of the 80 hash-bearing objects are unverified, not 17. `identity_documents` and `ui_assets`
happen to hash correctly today, so they produce no symptom — but they are structurally
unverified in exactly the same way, and would go stale silently on the next drift. This
strengthens rather than weakens X-1 step 3: the hardened checker must reject *any* unhandled
hash-bearing section, and two such sections already exist beyond the one that was noticed.

## W-3 (A-1 root cause) · Which build did the manifest capture? — VERIFIED

Manifest values vs. `bundles/CONVERGE01/C4/NOTES.md` vs. measurement:

| artifact | manifest | C4/NOTES.md | on disk now |
|---|---|---|---|
| `…-source.zip` | `e4b3e3da…` / 29,820,189 | `e4b3e3da…` / 29,820,189 | `27de97cd…` / 29,856,463 |
| `…-install.zip` | `baebaafe…` / 29,990,963 | `baebaafe…` / 29,990,963 | `85a3a028…` / 30,027,517 |
| `shell-1.0.0-rc.1-src.zip` | `2c362a39…` / 1,660,535 | `2c362a39…` / 1,660,535 | `d23713ad…` / 1,660,535 |

**The manifest captured the C4-era build**, byte-count for byte-count. The manifest also
self-declares it: `candidate.worktree_commit_at_generation` = `a45fb98…`, the C4 commit — not the
seal `32f191e…`.

**The ordering that produced it**, from mtimes and commit times (both UTC):

```
2026-08-29T15:29:59Z  a45fb98  C4 commit; build_release.ps1 produced e4b3e3da / baebaafe
2026-08-29T16:20:38Z  RELEASE-MANIFEST.json written  <-- hashed the artifacts AS THEY THEN WERE
2026-08-29T16:21:05Z  32f191e  seal commit           <-- froze those manifest bytes
2026-08-29T16:21:37Z  …-source.zip re-cut            <-- 32 s AFTER the manifest, AFTER the seal
2026-08-29T16:21:40Z  release-build-manifest.json written
2026-08-29T16:21:43Z  shell-1.0.0-rc.1-src.zip re-cut
```

The manifest hashed the artifacts, was committed, and then the artifacts were replaced. All 17
entries went stale by construction within 38 seconds of being written. Note `shell-…-src.zip`:
identical byte count, different hash — the recut is not a no-op even where size is unchanged.
This is a structural circularity, exactly as the audit interprets it, and no re-run of the same
ordering can avoid it.

## W-4 (A-2) · Spike compositor in the archive — VERIFIED; one audit number NOT REPRODUCIBLE

```
git archive HEAD: 3565 file entries (4273 members incl. directories)
entries containing spike_compositor: 56 files (66 members incl. directories)
distinct tracked roots: 2
    28 files / 33 members  modules/sow/tools/spike_compositor
    28 files / 33 members  evidence/cpm1/before-b/modules/sow/tools/spike_compositor
```

Cross-checked by a second method: `git ls-files` reports 28 tracked files under each root.
Both candidate ZIPs enumerate 66 spike entries each (33 per root).

**NOT REPRODUCIBLE:** the audit states "69 entries each". No counting basis I can construct
yields 69 — files (28), members including directories (33), or both roots combined (56 / 66).
**The substantive finding is unaffected and stands**: the spike ships, from two tracked roots, in
both candidate ZIPs. Only the count is wrong, and it is corrected here to 33 members / 28 files
per root.

Resolved pins, read from inside the source ZIP (both copies identical):

```
lockfileVersion 3, spike-compositor 0.1.0
  node_modules/electron    31.7.7      (declared devDependency ^31.0.0)
  node_modules/extract-zip 2.0.1
```

Mitigation re-derived (audit T-12) — confirmed in **both** candidate ZIPs:

```
node_modules entries        : 0
.exe/.node/.dll/.pyd entries: 0
```

So what ships is a vulnerable dependency *declaration*, not a vulnerable binary. The dossier
condition in `C2/PARKED-DOSSIERS.md` — exclusion "verified by C6 manifests/archive contents or
the risk remains release-blocking" — is measurably **not met** at `32f191e`. A-2 VERIFIED.

## W-5 (A-3) · Backup snapshots in the archive — VERIFIED

13 entries, cross-checked against `git ls-files` (also 13):

```
[.pre-CONVERGE01]     10,732 B  RELEASE-MANIFEST.json.pre-CONVERGE01
[.pre-CONVERGE01]    270,607 B  SBOM.json.pre-CONVERGE01
[.pre-CONVERGE01]     30,318 B  THIRD-PARTY-NOTICES.md.pre-CONVERGE01
[.pre-CONVERGE01]        315 B  VERSION.json.pre-CONVERGE01
[.pre-CONVERGE01]      2,514 B  modules/debate/INSTALL-PROVENANCE.json.pre-CONVERGE01
[.pre-CONVERGE01]      2,618 B  modules/distillery/INSTALL-PROVENANCE.json.pre-CONVERGE01
[.pre-CONVERGE01]      2,691 B  modules/sow/INSTALL-PROVENANCE.json.pre-CONVERGE01
[.pre-add08     ]        870 B  evidence/cpm1/baseline/host-hardware.pre-add08.json
[.pre-rebase    ]        928 B  shell/modules/debate.json.pre-rebase
[.pre-rebase    ]      1,124 B  shell/modules/distillery.json.pre-rebase
[.pre-rebase    ]      1,127 B  shell/modules/sovereign.json.pre-rebase
[.pre-rebase    ]      1,387 B  shell/modules/sow.json.pre-rebase
[.pre-rebase    ]      1,179 B  shell/modules/tokencenter.json.pre-rebase
                     326,410 B total   by pattern: pre-CONVERGE01 7, pre-rebase 5, pre-add08 1
```

**VERIFIED** exactly: 7 / 5 / 1 = 13. The distribution does contain two contradicting release
manifests and two contradicting SBOMs, as the audit states.

**Implementation trap found, reported here because it would have silently defeated X-3.** The
directive specifies `export-ignore` for `*.pre-add08`. That pattern **does not match** the only
file it is meant to catch: the file is `host-hardware.pre-add08.json` — `.pre-add08` is an infix,
not the terminal suffix. A literal application of the directive text would exclude 12 of 13 files
and report success. X-3 must use a pattern that actually matches.

## W-6 (N-18) · Developer-machine identifiers — VERIFIED for the named files; PARTIAL overall

### (i) The two mechanisms, read from source

`tools/release/install.ps1:94`, quoted:

```powershell
$python312 = (& $pyLauncher -3.12 -c 'import sys;print(sys.executable)').Trim()
```

The destination interpreter **is resolved dynamically at install time** — not copied from the
committed config. Line 103 writes it into the destination `install.json`; line 132 runs
`rebase_adapters.py --root $destRoot`. **The audit is right and its own retraction is right: this
is not a functional install defect.** I confirm it independently and will not report it as one.

`tools/release/rebase_adapters.py`, `_mapped()` lines 53–55:

```python
normalized_value = value.replace("\\", "/")
if normalized_value == OLD_PYTHON:      # OLD_PYTHON is the hardcoded constant at line 13
    return python_312
```

The interpreter rewrite **is value-matched against a hardcoded constant**, not applied
unconditionally. The trap the audit describes is real: neutralising the committed value to a
placeholder without changing this logic makes the placeholder match neither `OLD_PYTHON` nor any
root prefix, so `_mapped` returns it unchanged and the install silently keeps a non-existent
interpreter. VERIFIED.

### (ii) The five named files — VERIFIED

All five carry what N-18 says they carry: `shell/config/install.json`, `shell/modules/distillery.json`
and `shell/modules/tokencenter.json` hold `C:\Users\Sslaw\AppData\Local\Programs\Python\Python312\python.exe`;
`tools/release/rebase_adapters.py:13` holds it as `OLD_PYTHON`; `shell/modules/llamacpp.json` holds
three `D:/Product Software/Production Workspace/…` paths.

### (iii) PARTIAL — the population is far larger than N-18 states

Every file entering `git archive HEAD` was read and searched. Result:

| | developer username | `Product Software` |
|---|---|---|
| **total files entering the archive** | **107** | **264** |
| (a) live product/tooling | 31 | 29 |
| (b) `.pre-*` backups | 2 | 8 |
| (c) historical evidence captures | 68 | 199 |
| (d) documentation | 6 | 28 |

N-18 names 4 files for the username; 107 contain it. N-18 names 1 file for `Product Software`;
264 contain it. The remainder are overwhelmingly historical evidence captures under `evidence/`,
`dev/` and `modules/sow/docs/evidence/`, plus `AGENTS.md`, `CLAUDE.md`,
`BUILD-DIRECTIVE-SWS-UI-001.md`, `README.md`, the `tools-operator/Start-OpenCode-*.ps1` scripts,
the `INSTALL-PROVENANCE.json` provenance records, and `shell/tests/test_paths.py`.

### (iv) Consequence — X-4 pass-after criterion 5 is unsatisfiable as written · E-3

§4 X-4 step 5 requires: *"no tracked file that enters `git archive` contains the developer
username or `Product Software` (S-16)"*. That criterion **cannot be met by CLOSEOUT-01** without
violating higher-precedence rules:

- R2 §4 permanently prohibits *"deleting or rewriting historical evidence"* absent formal
  amendment, and R2 §8 requires historical evidence be *"preserved exactly"*. 68 + 199 of the
  hits are historical evidence captures.
- R2 §8 makes provenance records historical bytes; `INSTALL-PROVENANCE.json` files carry the old
  root by design.
- ENTRY 011 §3 retains `AGENTS.md` / `CLAUDE.md` / `BUILD-DIRECTIVE-SWS-UI-001.md` as release
  *subjects*; they are rooted at the old path by their nature.
- S-6 and S-14 bar loosening or rewriting the assertions in `shell/tests/test_paths.py`.

I therefore **execute X-4 steps 1–4 as written** (the five named files, which is what those steps
actually enumerate) and **report criterion 5 as refuted in its stated form**. The criterion I can
and do satisfy is the narrower one the directive's own steps describe:

> No **live shell configuration or release-tooling byte in the X-4 scope** contains the developer
> username or a foreign machine root.

The residue — historical evidence, provenance records, governance subjects, documentation — is
quantified above and carried to the reviewer and operator as a **named, measured limitation**, not
silently dropped. It is a genuine S-16 exposure in distributed bytes; it is simply not one this
seat is authorised to remove.

### (v) Second directive defect found in X-4 step 2 · E-3

X-4 step 2 instructs: set `python_312` **unconditionally** at "the enumerated interpreter pointers
(`/launch/argv/0`)", reasoning that "argv[0] is the interpreter by definition".

That is false for one of the three adapters carrying `/launch/argv/0`. `INVENTORY` in
`rebase_adapters.py:14-22` lists `/launch/argv/0` for `distillery.json`, `llamacpp.json` and
`tokencenter.json`. But `llamacpp.json`'s `argv[0]` is:

```
D:/Product Software/Production Workspace/runtime/llama.cpp/current/llama-server.exe
```

— a native server binary, **not a Python interpreter**. Applying the instruction literally to all
`/launch/argv/0` pointers would rewrite llama.cpp's server executable path to `python.exe` and
break the adapter. The directive's own wording says *interpreter* pointers; llamacpp's `argv[0]`
is not one. X-4 is therefore implemented as: unconditional `python_312` at the interpreter
pointers of `distillery.json` and `tokencenter.json` only, declared as data rather than as a
blanket rule on the pointer string. Recorded here so the deviation is visible, not inferred.

## W-7 (A-4) · Release-identity commit triple — VERIFIED

```
VERSION.json.source_commit            a45fb98cfa6d3619f6ea405044e3b76e87add24a   (C4 commit)
seal commit (HEAD)                    32f191e988e4690f5d68c83d541ca8668445dd03
release-build-manifest.source_commit  32f191e988e4690f5d68c83d541ca8668445dd03
```

The two identity documents disagree, as A-4 states. `VERSION.json` is tracked, and was last
modified by `32f191e` itself.

**Can a tracked file contain the hash of the commit that introduces it? No — proven, not asserted.**
Empirical demonstration in a throwaway repository, with author and committer dates pinned so file
content is the only variable:

```
attempt 1: commit introducing the file = dcf09c7a5d186fa3940b12d3f389c85879733fe9
attempt 2: wrote that hash into the file, commit is now = c3c64c49db733e2c4157bf8c233cd05f8f31e822
RESULT: NOT a fixed point. Writing the hash changed the hash.

commit object:  tree 4740b93fb81ec7315d3b378875e2b97c744b525d
tree contents:  100644 blob d3363a06…  V.json
```

The commit hash is taken over the tree; the tree contains the file's blob; changing the file
changes the blob, the tree, and therefore the commit. A fixed point would require a deliberate
SHA-1 preimage. A-4 VERIFIED, including the validator's acceptance that the original instruction
was unsatisfiable.

## W-8 · Baseline capture at `32f191e`, before any change

```
git archive HEAD file entries                       : 3565
git archive HEAD members including directories      : 4273

package_boundary_gate.py --root . --allowlist tools/release/fixture_allowlist.json
  run inside a clean `git archive HEAD` extract
  PASS (files scanned: 3565, violations: 0, credential hits: 0,
        quarantined-historical: 2011, allowlisted: 5)              exit 0

py -3.12 -B -m unittest discover -s tools/release -p 'test_*.py'
  Ran 72 tests — OK (72 pass, 0 fail)                              exit 0
```

The gate figures reproduce audit T-9 field for field, including the `--allowlist` dependency the
audit retracted its own FAIL over. Note one difference from the audit's L-1 note: the audit
records the builder's C5 measurement as "72 collected, 71 pass / 1 known manifest failure". At
`32f191e` I measure **72/72 passing** — the C6 regeneration resolved that failure. The audit's
L-1 POSIX path-separator failures do not occur here because this run measures on Windows.

## Standing-rule note recorded at Phase W · E-3 (narrow, resolved by the directive itself)

S-1 confines writes to `release-worktree` and `release-planning\bundles\CLOSEOUT01`, closing with
"or any path outside the worktree". §5 Phase Y then *requires* the C4 proxy cycle to write to
`D:\producttion software 2\install test area\`, and §6 Phase Z step 6 *requires* cold extraction
"to an empty temp directory". The general clause and the specific instructions conflict. Resolved
in favour of the specific instructions, which are unambiguous and later in the same document. All
of S-1's enumerated prohibitions are honoured without exception: no write to any frozen ZIP, no
write under `release-planning` outside this bundle, no write to Desktop or Start Menu. Ephemeral
extractions are made under the session scratchpad or the directive-named test area and removed
after use; every durable artefact lands in the bundle or the worktree.

---

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
