import json, hashlib, os, sys
root = r"D:\producttion software 2\release-worktree"
mf = os.path.join(root, "RELEASE-MANIFEST.json")
data = json.load(open(mf, encoding="utf-8"))

found = []  # (jsonpath, keyroot, path, sha256)
def walk(node, jp, keyroot):
    if isinstance(node, dict):
        if "path" in node and "sha256" in node and isinstance(node.get("path"), str) and isinstance(node.get("sha256"), str):
            found.append((jp, keyroot, node["path"], node["sha256"]))
        for k, v in node.items():
            walk(v, f"{jp}.{k}", keyroot if keyroot else k)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            walk(v, f"{jp}[{i}]", keyroot)

for k, v in data.items():
    walk(v, k, k)

def sha256_file(p):
    h = hashlib.sha256()
    try:
        with open(p, "rb") as f:
            for c in iter(lambda: f.read(1 << 20), b""):
                h.update(c)
        return h.hexdigest()
    except FileNotFoundError:
        return None

match = mismatch = missing = 0
from collections import Counter
mm_keys = Counter(); ok_keys = Counter()
rows = []
for jp, keyroot, p, expect in found:
    ap = os.path.join(root, p.replace("/", os.sep))
    actual = sha256_file(ap)
    if actual is None:
        st = "MISSING"; missing += 1; mm_keys[keyroot] += 1
    elif actual.lower() == expect.lower():
        st = "MATCH"; match += 1; ok_keys[keyroot] += 1
    else:
        st = "MISMATCH"; mismatch += 1; mm_keys[keyroot] += 1
    rows.append((st, keyroot, p, expect, actual))

print("TOTAL path+sha256 objects:", len(found))
print("MATCH   :", match)
print("MISMATCH:", mismatch)
print("MISSING :", missing)
print()
print("--- top-level manifest keys ---")
for k in data.keys(): print("   ", k)
print()
print("--- match counts by top-level key ---")
for k, c in ok_keys.items(): print(f"    MATCH    {k}: {c}")
for k, c in mm_keys.items(): print(f"    NONMATCH {k}: {c}")
print()
print("--- every non-MATCH row ---")
for st, kr, p, e, a in rows:
    if st != "MATCH":
        print(f"  [{st}] key={kr}")
        print(f"      path     = {p}")
        print(f"      manifest = {e}")
        print(f"      measured = {a}")
