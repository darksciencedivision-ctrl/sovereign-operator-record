# CLOSEOUT-01 release notes draft (CANDIDATE)

System: `sovereign-workspace` `1.0.0-rc.1`
**Seal commit: `50b47326f91c5abab8b6d5250d59b1dba96a4d46`**
Product/tooling head pinned in `VERSION.json.source_commit`: `be8dcb004b91c3d2ff2986f69a400b9317d36115`
Predecessor seal: `32f191e988e4690f5d68c83d541ca8668445dd03` (CONVERGE-01)
Rollback of record: `SOVEREIGN_RESET_BASELINE_20260827T193540Z.zip`
sha256 `00ae9eefc7dada37943bb08a305020c73e2c029a6398858e8bba27078c349a7c`

Release-artifact hashes are **not** in this document and **not** in `RELEASE-MANIFEST.json`. They
live in `release-artifacts/release-build-manifest.json`, which is untracked and written after the
seal commit exists. See "Release identity and the seal commit" in
`tools/release/README-GATE-POLICY.md`.

## Module versions

| module | version |
|---|---|
| debate | v1.2.1-hardening |
| distillery | 1.1.0rc3 |
| sovereign | SOVEREIGN_ENTERPRISE_PRODUCTION_20260813_142520 |
| sow | 0.1.0 |
| tokencenter | record-dated 2026-08-26 |
| shell | 1.0.0-rc.1 |

## Changes in CLOSEOUT-01 (`32f191e..50b4732`)

- **X-1** Release-manifest circularity broken. `RELEASE-MANIFEST.json` no longer carries any
  release-artifact hash; it covers tracked bytes only and names
  `release-artifacts/release-build-manifest.json` as the hash authority. The build-manifest
  producer now enumerates **all eight** artifacts and their sidecars, with each sidecar hashed in
  its own right — the six per-module archives previously had no authoritative hash record
  anywhere. The manifest checker is hardened: any `path`+`sha256` pair it does not actually verify
  now fails the gate (S-15).
- **X-2** The non-product Phase-1 spike compositor is excluded from release archives via
  `export-ignore` from both tracked roots. Files remain tracked and in history.
- **X-3** Backup snapshots (`*.pre-CONVERGE01`, `*.pre-rebase`, `*.pre-add08.json`) are excluded
  from release archives. All 13 remain tracked.
- **X-4** (partial) The installed-adapter interpreter rewrite is now unconditional at the
  interpreter pointers rather than matched against a hardcoded developer path;
  `shell/modules/llamacpp.json`'s three foreign-machine paths are neutralised.
- **X-5** The release-identity commit convention is recorded in `VERSION.json`, in
  `generate_release_identity.py`, and in `README-GATE-POLICY.md`.
- **Z** Provenance, identity and `RELEASE-MANIFEST.json` regenerated in acyclic order; artifacts
  cut **after** the seal commit.

## Status changes to previously accepted limitations

- **spike Electron / extract-zip nonproduct — NOW CLOSED BY EXCLUSION.** `electron 31.7.7` and
  `extract-zip 2.0.1` were shipping as a dependency *declaration* (no vulnerable binary ever
  shipped: 0 `node_modules` and 0 `.exe/.node/.dll/.pyd` entries in either candidate archive). The
  spike is now absent from all release archives — measured, 0 entries.
  *Caveat, see below:* the SBOM still declares those components.
- **Backup snapshots no longer ship.** The distribution no longer contains two contradicting SBOMs
  or two contradicting release manifests.

## Accepted limitations and parks, BY NAME

Carried forward from CONVERGE-01, all still open:

- **SOW Python dependencies are unpinned ranges and Distillery has no Python lock. Reproducible
  provisioning is NOT achieved for those two modules.** This remains the single largest genuine
  barrier to an enterprise production claim. CLOSEOUT-01 did not touch it: S-11 forbids
  synthesizing a missing lock, and §9 places it out of scope.
- SOW full pytest contract unverified (`pytest.ini` 2382/0/1) — parked on SOW-PY-LOCK-PARTIAL
- OD-20 lineage ruling outstanding (`e2e8e55` HELD)
- OD-23 assertion-inversion adjudication (inventory in `CONVERGE01/V/assertion-inventory.md`)
- Pre-existing shell-suite baseline disposition (this loop measured 166/166 OK)
- C2 supply-chain accepted risks: nanoid lock-held; Python vulnerability auditor not locked
- No-spend limitations (Grok registry leg, G28)
- Distillery status-only, deferred live testing, deferred UI (OP-6)
- H-6 composed-system proof
- MT-09 signature · G26 attended debug · live-acceptance and display legs
- OP-2 awaiting rulings (dossier only)
- Upstream Distillery W-4 tagging (outside write boundary)
- Canonical license text pending
- **True clean-room install pending.** The C4 proxy cycle was re-run in this loop and proves
  install/verify/boot/uninstall **mechanics and layout only**. It does not prove clean-room
  independence: this host already has Python 3.12, node and Ollama.
- Debate / SOVEREIGN / Distillery legs requiring Ollama or a live service were not run

## New limitations first disclosed by CLOSEOUT-01

- **N-20 — `provenance_cross_hash_check` is RED at the seal.** debate, distillery and sow report
  `UNKNOWN`; `tools/release/module_source_registry.json` is stale against the regenerated
  provenance records. Pre-existing: it was already red at `32f191e`, for a reason that commit
  itself created. Phase Z repaired the deeper half — the records are now reproducible from the
  commit they name — but refreshing the registry declares three modules' source identity and is an
  operator/reviewer act. **A release gate is failing. This is disclosed, not resolved.**
- **N-19 — `shell/BUILD-MANIFEST.txt` is stale.** 19 of 67 recorded hashes are wrong and 8 tracked
  shell files are omitted; it predates the CONVERGE-01 UI and adapter work. The shipped shell
  carries a self-description that disagrees with the shell.
- **Developer-machine identifiers still ship.** `shell/config/install.json`,
  `shell/modules/distillery.json` and `shell/modules/tokencenter.json` carry the developer's
  Windows username in an interpreter path. This is a **hygiene and privacy defect in distributed
  bytes; it is NOT a functional install defect** — `install.ps1:94` resolves the destination
  interpreter dynamically and the rebase now applies it unconditionally. X-4 removed the username
  from `rebase_adapters.py` and its test fixture but could not neutralise the three config files:
  every Python on the build host lives under `C:\Users\<user>\`, so no username-free path is also a
  working interpreter there. Three costed options are in
  `bundles/CLOSEOUT01/X-4/PARKED-X-4-STEP-3.md`.
  Beyond those three files, the archive additionally contains the username in **107** files and
  the previous machine root `D:\Product Software` in **264** files, overwhelmingly historical
  evidence captures that R2 §4 and §8 forbid rewriting.
- **The SBOM over-declares.** After X-2 excluded the spike, `SBOM.json` and
  `THIRD-PARTY-NOTICES.md` still list components sourced from the spike's lock — including
  `electron 31.7.7` and `extract-zip 2.0.1` — because the spike lock remains a `NODE_LOCKS` input
  to the identity generator. The SBOM therefore declares more than the archive contains.
  Over-declaration, not under-declaration; entries are labelled `sow-spike-nonproduct`. Operator
  ruling requested in `bundles/CLOSEOUT01/X-2/PARKED-SBOM-SPIKE-COUPLING.md`.
- **Module release tags no longer identify the shipped module archives.** `rel/debate/…`,
  `rel/distillery/…`, `rel/sovereign/…`, `rel/sow/…` and `rel/tokencenter/…` point at `0722692`
  and `rel/shell/1.0.0-rc.1` points at `a45fb98`, but per Phase Z step 4 all module archives are
  cut from the seal `50b4732`. Their contents differ from the tagged trees — the sow archive in
  particular no longer contains the spike. R2 §9(2) requires modules pinned by immutable tag plus
  commit SHA plus artifact SHA-256; that correspondence is currently broken. Re-tagging at the
  seal is a release-identity act belonging to the operator, and this builder did not perform it.
- **`SKIPPED-WITH-RECORD llamacpp` no longer appears in install logs.** A side effect of
  neutralising llamacpp's paths in X-4: the rebase now has nothing to change for that adapter, so
  the optional-skip record never fires. Reduced observability, disclosed.

## Measured at the seal

```
SOW desktop  1104/1104     SOW terminal 225/225     Token Center 32 OK
shell        166/166       tools/release 84 OK      (72 at 32f191e; +12 this loop)

package boundary gate, cold extract of the sealed source archive:
    PASS - 3497 scanned, 0 violations, 0 credential hits, 1982 quarantined-historical, 5 allowlisted
release_manifest_check   PASS (0 problems)
check_governance_bom     PASS
check_model_consistency  PASS
innerhtml_sink_audit     PASS - 39 templates, 112 interpolations
provenance_cross_hash    FAIL - N-20, pre-existing, disclosed above

archive entries 3565 -> 3497: +1 .gitattributes, -56 spike, -13 backups. 0 unexplained.
all 8 artifacts + 8 sidecars cold-extracted and hash-verified against the build manifest.
```

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
