# Sovereign Workspace 1.0.0-rc.1 — release notes (DRAFT)

## Candidate seal `0b6e3fe7346e7eaa581ce7fc02cf36f46e58bc75`
## Prepared by builder seat `claude-code (opus-5)` under LOCAL-01 · DRAFT ONLY — not promoted

> This is a builder-authored draft. Promotion to 1.0 is the operator's alone (§9), and no gate
> here is submitted for reviewer evaluation.

---

## The headline: the system runs on local models

Before this run, the operator had never had a session in which he could select a model and talk to
it. He can now. A SOW terminal, the Conductor, the Debate table and SOVEREIGN all run on models
that live on his own disk, with no frontier provider authorized and no network call to any model
service.

## Local models are selectable, and the operator's size limit is enforced honestly

- The picker enumerates the **whole local library** — 60 models on the reference host — and offers
  the ones at or under the operator's **8B ceiling**.
- Every model it will not offer stays **visible and greyed with a sentence saying why**, never
  hidden: over the ceiling (with its true parameter count named), an embedding model that cannot
  hold a conversation, or an Ollama Cloud row that would leave the machine.
- The display and the authorization now agree. A model the picker greys is refused by the spawn
  gate for **the same stated reason**, instead of being offered and refused after the click.
- Seven models that were silently missing from every list are back: namespaced tags such as
  `sam860/dolphin3-llama3.2:3b` were being dropped by a name filter meant for a different purpose.

## The Conductor is model-agnostic

- The Conductor offers the **local library** alongside the frontier providers, under the same
  ceiling and from the same enumeration.
- It **launches, accepts typing, and starts nothing** until you pick a model and send a message.
  Opening the app no longer spends a session — or loads a model into your GPU — before you have
  asked for anything.
- Frontier entries remain listed and honestly marked unavailable while frontier operation is not
  authorized. They are never removed, and local models are no longer gated behind that switch.
- The conversation transcript now names the model that actually answered, instead of a fixed label.

## Debate and SOVEREIGN

- **Debate** runs a real multi-model exchange on local seats and reports each seat's parameter
  count and ceiling status; a seat configured above the ceiling degrades the table visibly rather
  than failing quietly.
- **SOVEREIGN**'s four reasoning roles now run four different model families, all within the
  ceiling, and its model list marks every installed model that it will not assign to a role.

## Housekeeping that matters to anyone building from source

- **Using the product no longer dirties the release candidate.** SOW's runtime receipts moved out
  of the git-tracked tree into a gitignored runtime lane, and a new check asserts that no module
  declares a runtime write into a tracked directory.
- **The release producer now cuts all eight archives** from the sealed commit rather than adopting
  whatever files were left in the output directory. A stray archive now aborts the build instead of
  being published as authoritative.
- **Module provenance is consistent again.** The source registry matches every module's own record,
  and the provenance cross-hash gate passes for the first time since CONVERGE-01.

## Known limitations, stated

- **Frontier providers are not authorized.** This is a deliberate operator decision, not a defect.
  Every frontier row reports itself unavailable and says why.
- **Models above 8B are installed but not selectable.** Also deliberate, and each says so.
- The first message to a cold local model can report its delivery as *unconfirmed* while the model
  loads; the reply still arrives.
- A conductor pane does not apply the VRAM residency check a worker pane does; the 8B ceiling is
  what bounds it today.
- Two source files carry a UTF-8 byte-order mark, which the project's own text-integrity check
  flags. Pre-existing and untouched by this run.

## Gates at this seal

All six pass: package boundary, release manifest, provenance cross-hash, model consistency,
governance BOM, and the innerHTML sink audit.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
