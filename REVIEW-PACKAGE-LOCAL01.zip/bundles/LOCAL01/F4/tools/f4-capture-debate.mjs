/**
 * LOCAL-01 F-4 — capture a REAL multi-model exchange from the running Debate table.
 *
 * Connects to Debate's own `/ws` (the same stream its UI renders) and records the turns as they
 * arrive, then correlates each seat with the model Ollama actually had resident (`/api/ps`) so the
 * directive's "confirm which model each seat loads" is answered by measurement rather than by the
 * config file's say-so.
 *
 * Read-only: it sends nothing to Debate and pulls no model.
 */
import fs from "node:fs";
import http from "node:http";
import path from "node:path";

const DEBATE = process.env.F4_DEBATE || "127.0.0.1:8700";
const OLLAMA = process.env.F4_OLLAMA || "127.0.0.1:11434";
const OUT = process.env.F4_OUT || ".";
const WANT_TURNS = Number(process.env.F4_TURNS || 4);
const DEADLINE_MS = Number(process.env.F4_DEADLINE_MS || 900000);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function getJson(hostport, p) {
  const [host, port] = hostport.split(":");
  return new Promise((resolve, reject) => {
    const req = http.get({ host, port: Number(port), path: p }, (res) => {
      let d = "";
      res.on("data", (c) => (d += c));
      res.on("end", () => { try { resolve(JSON.parse(d)); } catch (e) { reject(e); } });
    });
    req.on("error", reject);
    req.setTimeout(8000, () => req.destroy(new Error("timeout")));
  });
}

const turns = [];
const residentSamples = [];
const frames = [];

async function sampleResidency() {
  try {
    const ps = await getJson(OLLAMA, "/api/ps");
    residentSamples.push({
      at: new Date().toISOString(),
      models: (ps.models || []).map((m) => ({
        name: m.name, size_vram_gb: Number(((m.size_vram || 0) / 1e9).toFixed(2)),
      })),
    });
  } catch { /* the daemon is busy generating; a missed sample is not a fact */ }
}

async function main() {
  const ready = await getJson(DEBATE, "/ready");
  const ws = new WebSocket(`ws://${DEBATE}/ws`);
  await new Promise((resolve, reject) => {
    ws.addEventListener("open", resolve, { once: true });
    ws.addEventListener("error", () => reject(new Error("debate ws error")), { once: true });
  });

  ws.addEventListener("message", (ev) => {
    let m;
    try { m = JSON.parse(ev.data); } catch { return; }
    frames.push(m.type || "(untyped)");
    // A completed public turn is the unit the directive cares about: one seat, one model, one
    // argument. Streaming deltas are ignored — a partial sentence is not an exchange.
    if (m.type === "turn" || m.type === "message" || m.type === "say" || m.type === "turn_end") {
      const text = m.text || m.content || m.message || "";
      const speaker = m.name || m.speaker || m.seat || null;
      if (speaker && String(text).trim().length > 0) {
        turns.push({ at: new Date().toISOString(), speaker,
                     model: m.model || null, chars: String(text).length,
                     text: String(text) });
      }
    }
  });

  const deadline = Date.now() + DEADLINE_MS;
  while (turns.length < WANT_TURNS && Date.now() < deadline) {
    await sampleResidency();
    await sleep(5000);
  }
  await sampleResidency();
  const readyAfter = await getJson(DEBATE, "/ready");
  try { ws.close(); } catch { /* closing */ }

  // Which model did each seat actually load? Correlate the configured seat with every model the
  // daemon was observed holding while that seat was speaking.
  const seatModels = {};
  for (const s of readyAfter.seats || []) seatModels[s.name] = s.model;
  const everResident = new Set();
  for (const s of residentSamples) for (const m of s.models) everResident.add(m.name);

  const receipt = {
    check: "LOCAL-01.F-4.debate-local-exchange",
    started: new Date().toISOString(),
    ready_before: ready,
    ready_after: readyAfter,
    seat_models_configured: seatModels,
    models_observed_resident: [...everResident].sort(),
    every_seat_model_was_resident: Object.values(seatModels)
      .every((m) => everResident.has(m)),
    turn_count: turns.length,
    distinct_speakers: [...new Set(turns.map((t) => t.speaker))].sort(),
    residency_samples: residentSamples,
    ws_frame_types: [...new Set(frames)].sort(),
    turns,
    ok: turns.length >= WANT_TURNS
      && new Set(turns.map((t) => t.speaker)).size >= 2
      && readyAfter.over_ceiling_models.length === 0,
  };
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, "F4-RECEIPT.json"),
    JSON.stringify(receipt, null, 2) + "\n", "utf8");
  console.log(JSON.stringify({
    ok: receipt.ok, turns: receipt.turn_count, speakers: receipt.distinct_speakers,
    seatModels, resident: receipt.models_observed_resident,
    everySeatModelResident: receipt.every_seat_model_was_resident,
    overCeiling: readyAfter.over_ceiling_models, status: readyAfter.status,
    frameTypes: receipt.ws_frame_types,
  }, null, 2));
  process.exit(receipt.ok ? 0 : 1);
}

main().catch((e) => { console.error("F4 capture failed:", e.message); process.exit(2); });
