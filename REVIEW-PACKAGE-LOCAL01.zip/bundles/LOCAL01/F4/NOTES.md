# LOCAL-01 · F-4 — Debate on local models

Commit `607d3581e504bc04f2f395acb77d63fefbf9d897`. Directive §4 F-4.

## Result: a real multi-model exchange, both models measured resident

```
ok                      : true
turns                   : 4        speakers : ["Clue", "Neo"]
seat models configured  : Neo = qwen3:8b     Clue = dolphin3:8b
models observed RESIDENT: ["dolphin3:8b", "qwen3:8b"]
every seat model resident: true
over_ceiling_models     : []       status : ready
```

**"Confirm which model each seat loads"** is answered by measurement, not by reading the config
back. `/api/ps` was sampled every 5 s while the table ran, and the two models are seen
**alternating** in VRAM:

```
05:33:43  dolphin3:8b  5.27 GB
05:33:53  qwen3:8b     5.58 GB
05:34:08  dolphin3:8b  5.27 GB
05:34:13  qwen3:8b     5.58 GB
```

That alternation is itself the 8 GB card's signature: two 8B models are 10.85 GB together, so only
one is resident at a time and Ollama swaps them per turn. The table works; it works by swapping.

Sample of the real exchange (`F4-RECEIPT.json`, `turns[]`):

> **Clue** (1587 chars) — *"I stand firmly against the notion that we can simply 'build a better
> system' to avoid the harsh realities of a post-human future. The question of accountability and
> responsibility is not merely a matter of tweaking our moral frameworks…"*

## What was wrong

**The punch list had the cause wrong, twice over.** N-28 recorded "Debate reaches no models —
Ollama is not running. Host state. Start it." D-1 measured the deeper cause: `OLLAMA_MODELS` pointed
at an empty vault, so following that instruction would have produced a *healthy daemon serving
nothing* — the symptom unchanged and one clue poorer.

**One seat was over the ceiling.** `config.json` ran Clue on `qwen2.5:14b-instruct` — **14.8B**,
the same straddle class ENTRY 017 exists to prevent, and precisely what punch-list §5 S-8 asks to
be confirmed absent. It is now `dolphin3:8b` (8.0B). That also makes the exchange genuinely
multi-*model*: `qwen3` family against `llama` family, rather than two tags from one vendor.

**Nothing enforced the ceiling.** A seat could be configured at any size and the table would report
`ready`.

## What changed

`/ready` now classifies every seat against the ceiling using the daemon's own parameter counts and
reports, per seat, `parameter_size`, `within_ceiling` and a `ceiling_reason`, plus a table-level
`over_ceiling_models` and a `local_model_ceiling` block naming ENTRY 017 as the authority. An
over-ceiling seat **degrades** the table exactly as a missing model does — a seat that cannot take
its turn must not sit behind a green badge (S-19).

Live, after the change:

```json
{"name": "Neo",  "model": "qwen3:8b",    "installed": true, "parameter_size": "8.2B", "within_ceiling": true},
{"name": "Clue", "model": "dolphin3:8b", "installed": true, "parameter_size": "8.0B", "within_ceiling": true}
```

## The duplicated constant, stated (S-4)

The ceiling is implemented a second time in `modules/debate/app.py` rather than imported from
`modules/sow/adapters/local/model_ceiling.py`. Debate and SOW are separate products with separate
install provenance and separate virtualenvs; a cross-module import would tie Debate's startup to
SOW's package tree. **Both sites move together**, and each names the other in its comment. The two
sites are:

- `modules/sow/adapters/local/model_ceiling.py` — `CEILING_NAMEPLATE_B`, `_TRUE_PARAM_LIMIT`
- `modules/debate/app.py` — `CEILING_NAMEPLATE_B`, `_CEILING_TRUE_PARAMS`

## S-20 and the frontier half — reported, not built

S-20 says a component that can only reach one class of model is defective, and that where frontier
is unauthorized its entries are **shown and honestly marked unavailable**. Debate has **no frontier
surface at all**: it is Ollama-only by construction (`ollama_url`, `/api/tags`, `/api/chat`), as the
punch list itself records in §7 ("Debate is Ollama-only").

So there are no frontier entries to keep visible — there is nothing to remove and nothing to grey.
Giving Debate one would mean **building** a frontier provider surface for providers the operator has
DENIED (OD-31/OD-5), which is punch-list **OP-7**, named there as "a program, not a punch-list line".
Recorded as **N-36** rather than improvised into this item (S-9). The local half of S-20 — the whole
library within the ceiling — is what F-4 delivers.

## Reported, NOT fixed

**N-35 · a thinking model produces short turns and skips (PARTIAL — mechanism inferred, not fully
root-caused).** Measured: Neo (`qwen3:8b`) produced a 306-character turn where Clue produced
1362–1635, and `skipped_turns` rose from 1 to 4 across the run while `completed_public_turns`
reached 10.

The mechanism is *consistent with* — and I did not close the loop on it, so it is stated as an
inference rather than a measured root cause, unlike D-4: `qwen3:8b` is a thinking model;
`output_guard` correctly strips `<think|analysis|reasoning>` and `app.py:920` deliberately ignores
Ollama's separate `thinking` field; the seat's budget is `num_predict: 320` and the table requires
`turn_word_min: 110`. Reasoning consumes the budget, leaving a spoken remainder under the minimum,
and the turn is retried/skipped.

Not fixed, deliberately. The remedy is a tuning decision between `num_predict`, `turn_word_min` and
which seat carries a thinking model — and the operator explicitly named `qwen3:8b` as the model to
prove the system with (punch-list S-8 asks to confirm Debate loads it), so removing it from a seat
would be the wrong correction. Raising the budget is a behaviour change outside this item (S-9).

## Teardown

Debate was stopped and `/health` confirmed unreachable afterwards; no orphaned process. The
`ollama` daemon remains up by design.

## Artifacts

`F4-RECEIPT.json` (turns, residency samples, both `/ready` snapshots) · `f4-ready-final.json` ·
`tools/f4-capture-debate.mjs`

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
