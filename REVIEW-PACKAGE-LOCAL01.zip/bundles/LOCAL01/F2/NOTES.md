# LOCAL-01 · F-2 — SOW terminals run local models

Directive §4 F-2: *"The operator opens a terminal, picks a local model, types, and gets a response.
Demonstrate it."*

## Result: demonstrated on the real product, end to end

```
ok               : true
pane             : pane-2
argv             : ["C:\\Users\\Sslaw\\AppData\\Local\\Programs\\Ollama\\ollama.EXE", "run", "qwen3:8b"]
interactive_argv : true          (no third bare positional — not a one-shot prompt)
subscription     : null          (a local pane holds no I-X3 terminal — invariant 19)
prompt_sent      : true
answered         : true
response_chars   : 1494
torn_down        : true
```

The model's own words, from `f2-pane-scrollback.txt`:

> *"…that serves as the seat of government. I remember that **Paris** is the capital. Wait, is there
> any chance it could be another city? No, I think Paris is definitely correct. …The user wants
> exactly one short sentence, so I should state…"*

That is `qwen3:8b` reasoning and answering, streamed token by token into a SOW terminal.
**This is the first session in this program in which the operator could pick a local model and talk
to it**, which is the deliverable ENTRY 017 set.

## THIS ITEM REQUIRED NO CODE CHANGE — and that is the finding

F-2 has **no commit**. The path was already complete (D-5 traced it and produced an authorized
ticket at the parent seal); what was missing was the ceiling, and F-1 supplied it. Recording an item
as "done, no diff" is more honest than manufacturing a change to have something to point at.

## How it was demonstrated — the real product, not a re-creation

`tools/f2-local-terminal.mjs` launches the packaged SOW Electron app and then acts **only** through
`window.sovereign`, the contextBridge preload that is the renderer's sole channel:

| step | call | what it really is |
|---|---|---|
| read the picker | `sovereign.picker()` | the live host enumeration the drawer renders |
| the operator's click | `sovereign.spawnFromSelection(...)` | the exact `pane:spawnFromSelection` IPC |
| the operator's typing | `sovereign.input(paneId, text + "\r")` | the exact `pane:input` IPC a keystroke sends |
| read the answer | `sovereign.scrollback(paneId)` | byte-exact pane output, read-only |

No test-only path and no code was added to the product to make this observable: every governance
gate that runs for an operator ran here. Node 24's global `WebSocket` drives CDP with nothing
installed (`tools/cdp.mjs`), the same dependency-free approach FIXUP-01's Phase D used for Edge.

`SOW_CONDUCTOR_AUTOLAUNCH=0` was set so the conductor could not auto-spawn, keeping the run to
exactly one local model session. **`live_operation.json` was verified absent before launch and was
never created.** No model was pulled.

## What the run independently proves about F-1 and S-20, in the live UI

```
picker counts    : {total: 83, available: 8, frontier: 23, local: 60}
local offered    : 8      (every one at or under the 8B nameplate ceiling)
local greyed     : 52
greyed with NO stated reason : 0
frontier visible : 23     frontier available : 0
```

The refusal sentences the operator actually sees, read back out of the live picker:

- `phi4:14b` — *"has 14.7B parameters, above the operator's 8B ceiling (ENTRY 017). This host's GPU
  carries 8 GB of VRAM and a larger model straddles it, running partly on the CPU."*
- `deepseek-r1:70b` — same class, naming 70.6B.
- `nomic-embed-text:latest` — *"is an embedding model (137M parameters, family nomic-bert). It turns
  text into vectors and cannot answer a typed message."*

**S-20 holds in the running product**: all 23 frontier options remain *visible* and are *honestly
unavailable*, none removed, and local is offered while `live_operation.json` is absent — local is
not gated behind the frontier switch.

## Teardown (D-LOOP-1)

The pane was closed, the app quit, and an orphan sweep found no `electron` and no `ollama run`
child — only the Ollama **daemon**, which this run deliberately started and which the operator
authorized. `git status --porcelain` after the run carries only the four named untracked paths.

## N-29 reproduced, live

Running the product rewrote `modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json` — inside the
**tracked** tree. This is the defect OD-34 rules on and F-6 fixes: using the product dirties its own
release candidate.

## Artifacts

- `F2-RECEIPT.json` — the full machine-readable receipt
- `f2-pane-scrollback.txt` — byte-exact pane output, including the model's answer
- `f2-local-terminal.png` — screenshot of the shell at the moment of the answer
- `f2-electron.log` — the app's own stdout/stderr for the run
- `tools/f2-local-terminal.mjs`, `tools/cdp.mjs` — the driver, re-runnable

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
