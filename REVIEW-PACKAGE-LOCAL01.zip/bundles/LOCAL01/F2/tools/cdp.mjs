/**
 * Minimal dependency-free Chrome DevTools Protocol client (LOCAL-01).
 *
 * Node 24 ships a global WebSocket, so this installs nothing — the same approach FIXUP-01's Phase D
 * used to drive Edge. Here it drives the SOW Electron renderer so a demonstration can go through the
 * product's own bridge (`window.sovereign`, the contextBridge preload) rather than around it.
 */
import http from "node:http";

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** GET a JSON endpoint on the DevTools HTTP port, retrying until the app is listening. */
export async function devtoolsJson(port, path = "/json", timeoutMs = 60000) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    try {
      const body = await new Promise((resolve, reject) => {
        const req = http.get({ host: "127.0.0.1", port, path }, (res) => {
          let d = "";
          res.on("data", (c) => (d += c));
          res.on("end", () => resolve(d));
        });
        req.on("error", reject);
        req.setTimeout(4000, () => req.destroy(new Error("devtools http timeout")));
      });
      return JSON.parse(body);
    } catch (e) {
      if (Date.now() > deadline) throw new Error(`devtools port ${port} never answered: ${e.message}`);
      await sleep(400);
    }
  }
}

/** The renderer page target for the shell window (never a devtools:// or extension target). */
export async function findPageTarget(port, { titleIncludes = "" } = {}, timeoutMs = 60000) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const targets = await devtoolsJson(port, "/json", Math.max(1000, deadline - Date.now()));
    const page = targets.find((t) => t.type === "page"
      && typeof t.webSocketDebuggerUrl === "string"
      && !String(t.url).startsWith("devtools://")
      && String(t.title || "").includes(titleIncludes));
    if (page) return page;
    if (Date.now() > deadline) {
      throw new Error(`no page target: ${JSON.stringify(targets.map((t) => ({ t: t.type, u: t.url })))}`);
    }
    await sleep(400);
  }
}

export class Cdp {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    this.events = [];
    ws.addEventListener("message", (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(`${msg.error.message} (${msg.error.code})`));
        else resolve(msg.result);
      } else if (msg.method) {
        this.events.push(msg);
      }
    });
  }

  static async connect(wsUrl) {
    const ws = new WebSocket(wsUrl);
    await new Promise((resolve, reject) => {
      ws.addEventListener("open", resolve, { once: true });
      ws.addEventListener("error", () => reject(new Error("cdp websocket error")), { once: true });
    });
    return new Cdp(ws);
  }

  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(`${method} timed out`));
        }
      }, 180000);
    });
  }

  /** Evaluate an async expression in the page and return its value (throws on a page-side throw). */
  async eval(expression, { awaitPromise = true } = {}) {
    const res = await this.send("Runtime.evaluate", {
      expression, awaitPromise, returnByValue: true, userGesture: true,
    });
    if (res.exceptionDetails) {
      const d = res.exceptionDetails;
      throw new Error(`page threw: ${(d.exception && (d.exception.description || d.exception.value)) || d.text}`);
    }
    return res.result && res.result.value;
  }

  close() { try { this.ws.close(); } catch { /* already gone */ } }
}

/** Poll `fn` until it returns a truthy value, or give up. Returns the value or null. */
export async function until(fn, timeoutMs, stepMs = 500) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    let v = null;
    try { v = await fn(); } catch { v = null; }
    if (v) return v;
    if (Date.now() >= deadline) return null;
    await sleep(stepMs);
  }
}
