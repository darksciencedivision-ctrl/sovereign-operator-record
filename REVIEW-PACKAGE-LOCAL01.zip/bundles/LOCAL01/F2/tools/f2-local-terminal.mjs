/**
 * LOCAL-01 F-2 — the operator opens a terminal, picks a local model, types, and gets a response.
 *
 * This drives the REAL product. It launches the packaged SOW Electron app and then acts through
 * `window.sovereign`, the contextBridge preload that is the ONLY channel the renderer has:
 *
 *   sovereign.picker()             -> the live host enumeration the picker drawer renders
 *   sovereign.spawnFromSelection() -> the exact IPC `pane:spawnFromSelection` an operator's click sends
 *   sovereign.input(id, data)      -> `pane:input`, the exact IPC a keystroke sends to the PTY
 *   sovereign.scrollback(id)       -> the byte-exact pane output, read-only
 *
 * Nothing here is a test-only path: every governance gate that runs for an operator runs here.
 *
 * It creates no `live_operation.json`, pulls no model, and selects nothing above the operator's 8B
 * ceiling. `SOW_CONDUCTOR_AUTOLAUNCH=0` is set so the conductor cannot auto-spawn (H-10), which
 * keeps this run to exactly one local model session.
 */
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { Cdp, findPageTarget, sleep, until } from "./cdp.mjs";

const DESKTOP = String(process.env.SOW_DESKTOP
  || "D:/producttion software 2/release-worktree/modules/sow/apps/desktop");
const ELECTRON = path.join(DESKTOP, "node_modules", "electron", "dist", "electron.exe");
const PORT = Number(process.env.CDP_PORT || 9222);
const OUT = String(process.env.F2_OUT || ".");
const WANT = String(process.env.F2_MODEL || "qwen3:8b");
const QUESTION = String(process.env.F2_QUESTION
  || "Reply with exactly one short sentence: what is the capital of France?");

const receipt = {
  check: "LOCAL-01.F-2.local-terminal",
  started: new Date().toISOString(),
  ok: false,
  model_requested: WANT,
  live_operation_json_present: null,
  picker_ok: null,
  picker_counts: null,
  local_total: null,
  local_offered: null,
  local_greyed: null,
  greyed_without_reason: null,
  ceiling_refusal_samples: {},
  chosen: null,
  spawn: null,
  pane_id: null,
  argv: null,
  interactive_argv: null,
  subscription: "unset",
  prompt_sent: null,
  prompt_text: QUESTION,
  response_chars: null,
  response_excerpt: null,
  answered: false,
  torn_down: false,
  notes: [],
};

function save() {
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, "F2-RECEIPT.json"),
    JSON.stringify(receipt, null, 2) + "\n", "utf8");
}

let child = null;
async function shutdown() {
  if (child && !child.killed) {
    try { child.kill(); } catch { /* gone */ }
    await sleep(1500);
    try { process.kill(child.pid, 0); spawn("taskkill", ["/PID", String(child.pid), "/T", "/F"]); }
    catch { /* already dead */ }
  }
}

async function main() {
  const liveCfg = path.resolve(DESKTOP, "..", "..", "config", "live_operation.json");
  receipt.live_operation_json_present = fs.existsSync(liveCfg);
  if (receipt.live_operation_json_present) {
    throw new Error("live_operation.json exists — this run requires the local-only posture (OD-31)");
  }

  child = spawn(ELECTRON, [".", `--remote-debugging-port=${PORT}`], {
    cwd: DESKTOP,
    env: { ...process.env, SOW_CONDUCTOR_AUTOLAUNCH: "0", PYTHONDONTWRITEBYTECODE: "1" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const logLines = [];
  child.stdout.on("data", (d) => logLines.push(String(d)));
  child.stderr.on("data", (d) => logLines.push(String(d)));

  const page = await findPageTarget(PORT, {}, 90000);
  const cdp = await Cdp.connect(page.webSocketDebuggerUrl);
  await cdp.send("Runtime.enable");
  await cdp.send("Page.enable");

  // The bridge must exist before anything else is claimed about it.
  const bridge = await until(
    () => cdp.eval("typeof window.sovereign === 'object' && typeof window.sovereign.picker === 'function'"),
    60000);
  if (!bridge) throw new Error("window.sovereign never appeared — the preload bridge did not load");

  // ---- 1. the live picker, exactly as the operator's drawer renders it -----------------------
  const pick = await until(async () => {
    const r = await cdp.eval(`(async () => {
      const m = await window.sovereign.picker();
      if (!m || m.ok !== true) return { ok: false, error: (m && m.error) || 'picker failed' };
      const opts = (m.picker && m.picker.options) || [];
      const local = opts.filter(o => o.locality === 'local');
      const pickOne = (tag) => local.find(o => o.label === tag) || null;
      return {
        ok: true,
        counts: m.picker.counts,
        localTotal: local.length,
        localOffered: local.filter(o => o.available).length,
        localGreyed: local.filter(o => !o.available).length,
        greyedWithoutReason: local.filter(o => !o.available && !o.unavailable_reason).length,
        want: pickOne(${JSON.stringify(WANT)}),
        samples: {
          'phi4:14b': (pickOne('phi4:14b') || {}).unavailable_reason || null,
          'deepseek-r1:70b': (pickOne('deepseek-r1:70b') || {}).unavailable_reason || null,
          'nomic-embed-text:latest': (pickOne('nomic-embed-text:latest') || {}).unavailable_reason || null,
        },
        frontierVisible: opts.filter(o => o.locality === 'frontier').length,
        frontierAvailable: opts.filter(o => o.locality === 'frontier' && o.available).length,
      };
    })()`);
    return r && r.ok ? r : null;
  }, 120000, 2000);

  if (!pick) throw new Error("the picker never returned a usable enumeration");
  receipt.picker_ok = true;
  receipt.picker_counts = pick.counts;
  receipt.local_total = pick.localTotal;
  receipt.local_offered = pick.localOffered;
  receipt.local_greyed = pick.localGreyed;
  receipt.greyed_without_reason = pick.greyedWithoutReason;
  receipt.ceiling_refusal_samples = pick.samples;
  receipt.frontier_visible = pick.frontierVisible;
  receipt.frontier_available = pick.frontierAvailable;

  if (!pick.want) throw new Error(`${WANT} was not enumerated by the host picker`);
  if (pick.want.available !== true) {
    throw new Error(`${WANT} is not offered: ${pick.want.unavailable_reason}`);
  }
  receipt.chosen = { label: pick.want.label, model_slug: pick.want.model_slug,
                     locality: pick.want.locality, adapter: pick.want.adapter };

  // ---- 2. the operator's picker click: a governed spawn into a new pane ----------------------
  const spawnRes = await cdp.eval(`(async () => {
    const opt = (await window.sovereign.picker()).picker.options
      .find(o => o.locality === 'local' && o.label === ${JSON.stringify(WANT)});
    return await window.sovereign.spawnFromSelection({
      option: opt, role: 'reasoning', mode: 'attended', targetPaneId: null,
    });
  })()`);
  receipt.spawn = spawnRes;
  receipt.pane_id = (spawnRes && spawnRes.target) || null;
  receipt.argv = (spawnRes && spawnRes.argv) || null;
  if (!spawnRes || spawnRes.launched !== true) {
    throw new Error(`the governed local launch did not run: ${JSON.stringify(spawnRes)}`);
  }
  // An INTERACTIVE `ollama run <tag>` — a third bare positional would make it one-shot.
  receipt.interactive_argv = Array.isArray(receipt.argv)
    && receipt.argv.includes("run")
    && receipt.argv.filter((a) => !String(a).startsWith("-")).length === 3;
  receipt.subscription = (spawnRes.chrome && spawnRes.chrome.subscription) || null;

  // ---- 3. wait for the model to be ready to take a prompt -----------------------------------
  const paneId = receipt.pane_id;
  const readBack = async () => {
    const r = await cdp.eval(
      `(async () => { const s = await window.sovereign.scrollback(${JSON.stringify(paneId)}); return (s && s.text) || ''; })()`);
    return typeof r === "string" ? r : "";
  };
  const ready = await until(async () => {
    const t = await readBack();
    // `ollama run` prints its own interactive prompt once the model is loaded.
    return t && (t.includes(">>>") || /Send a message/i.test(t)) ? t : null;
  }, 240000, 1500);
  receipt.notes.push(ready ? "the local session reached its interactive prompt"
    : "no interactive prompt marker was seen before the deadline; the prompt was sent anyway");

  const before = await readBack();

  // ---- 4. the operator types, through `pane:input` — the keystroke IPC ------------------------
  const sent = await cdp.eval(
    `window.sovereign.input(${JSON.stringify(paneId)}, ${JSON.stringify(QUESTION + "\r")})`);
  receipt.prompt_sent = sent !== false;

  // ---- 5. the model answers ------------------------------------------------------------------
  const answer = await until(async () => {
    const t = await readBack();
    if (t.length <= before.length) return null;
    const grown = t.slice(before.length);
    // Discount the echo of the operator's own keystrokes; require real generated text after it.
    const afterEcho = grown.includes(QUESTION)
      ? grown.slice(grown.indexOf(QUESTION) + QUESTION.length)
      : grown;
    const cleaned = afterEcho.replace(/[\s\r\n>]+/g, " ").trim();
    return cleaned.length >= 12 ? { grown, cleaned } : null;
  }, 240000, 1500);

  if (answer) {
    receipt.answered = true;
    receipt.response_chars = answer.cleaned.length;
    receipt.response_excerpt = answer.grown.slice(0, 1600);
  } else {
    const t = await readBack();
    receipt.response_chars = Math.max(0, t.length - before.length);
    receipt.response_excerpt = t.slice(-1600);
  }

  fs.mkdirSync(OUT, { recursive: true });
  const shot = await cdp.send("Page.captureScreenshot", { format: "png" });
  fs.writeFileSync(path.join(OUT, "f2-local-terminal.png"), Buffer.from(shot.data, "base64"));
  fs.writeFileSync(path.join(OUT, "f2-pane-scrollback.txt"), await readBack(), "utf8");

  // ---- 6. tear down: no orphaned model process (D-LOOP-1) ------------------------------------
  try { await cdp.eval(`window.sovereign.close(${JSON.stringify(paneId)})`); } catch { /* closing */ }
  await sleep(1500);
  receipt.torn_down = true;
  cdp.close();
  fs.writeFileSync(path.join(OUT, "f2-electron.log"), logLines.join(""), "utf8");
  receipt.ok = receipt.answered === true && receipt.interactive_argv === true;
}

main()
  .catch((e) => { receipt.error = e.message; })
  .finally(async () => {
    receipt.finished = new Date().toISOString();
    await shutdown();
    save();
    console.log(JSON.stringify({
      ok: receipt.ok, answered: receipt.answered, pane: receipt.pane_id,
      argv: receipt.argv, localOffered: receipt.local_offered, localGreyed: receipt.local_greyed,
      greyedWithoutReason: receipt.greyed_without_reason,
      responseChars: receipt.response_chars, error: receipt.error || null,
    }, null, 2));
    process.exit(receipt.ok ? 0 : 1);
  });
