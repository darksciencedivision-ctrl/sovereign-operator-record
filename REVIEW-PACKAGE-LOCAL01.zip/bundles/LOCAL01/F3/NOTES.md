# LOCAL-01 · F-3 — THE CONDUCTOR IS AGNOSTIC

Commit `39079f64a4dbdf6d5e3ace9041f3e7b429132340`. Directive §4 F-3 · ENTRY 018 · S-20.
Ruled by the operator, not optional, and **not parkable on construction grounds**.

## The acceptance, met

```
spawnedNothingBeforeSend : true          (option C)
conductorCapableLocal    : 8             (the local library, under the 8B ceiling)
frontierVisible          : 23            frontierAvailable : 0      (S-19 / S-20)
selected                 : true          ollama_local / qwen3:8b
answered                 : true          660 chars
transcript labels        : ollama_local / qwen3:8b
argv                     : [...\ollama.EXE, run, qwen3:8b]
liveOperationJsonAfter   : false
```

The Conductor's own words, from `f3-conductor-scrollback.txt`:

> `>>> ` In one short sentence: what is 17 plus 25?
> *Thinking… 17 plus 20 is 37, and then plus 5 more is 42. Wait, is that right? Let me check again.
> 10 plus 20 is 30, 7 plus 5 is 12, so 30 plus 12 is 42. Yep, that's correct.*
> **"17 plus 25 equals 42."**

That is the Conductor, backed by a local 8B model, answering a message the operator typed — with
`live_operation.json` absent, no subscription, and no credential.

## Six blockers, each measured before it was moved

| # | what stood in the way | where |
|---|---|---|
| 1 | three registered conductor seats, **all frontier** | `control_plane/conductor/registry.py` |
| 2 | `commands_for("ollama_local")` raised | `adapters/conductor/provider_commands.py` |
| 3 | every conductor routed through the frontier gate chain + required a `subscription_ref` | `node_runtime/supervisor/conductor_pane_spawn.py` |
| 4 | resolved `claude_code/fable-5` whenever `live_operation.json` was absent — its permanent state | `registry.load_runtime_conductor_descriptor` |
| 5 | the operator's selection was persisted **into** `live_operation.json` | `tools/live/select_conductor.py` |
| 6 | **`assert_provider_live('ollama_local')` REFUSED** | `control_plane/profiles/live_authorization.py`, via the spawn path |

Blocker 6 is the one that mattered most, and it is S-20 verbatim. A model that costs nothing was
refused with a message about *spend authorization*. The worker path escaped it only because it
**branches around** the gate before reaching it (`worker_pane_spawn:448`); nothing made the gate
itself local-aware. F-3 gives the conductor the same split.

## Two governors, and the difference is stated rather than skipped

A local conductor does **not** run: the `LIVE_OPERATION_AUTHORIZED` gate, `assert_provider_live`,
the R8 §6 spend-terms confirmation, or the I-X3 subscription count. Its `lease` is `null`, its
`subscription_ref` is `""`, its `chrome.subscription` is `null`, and `teardown` releases nothing —
because there is nothing to release, not because a step is missing.

It **does** run: the node identity and permission profile (invariant 2/29), the **deployment-profile
check** (`check_eligible` — a *locality* question, invariant 20, and a local model passes it even
air-gapped, which is the point of asserting rather than assuming it), a **resolved** binary rather
than a bare name the ConPTY would PATH-search after the gate, and the **credential scrub** — which
matters most precisely because a local model needs no credential, so the child must not inherit the
operator's frontier keys merely because nothing here would use them.

## Three honesty repairs found while wiring it

**The authority boundary would have lied.** `_apply_permission_profile`'s non-Claude branch reports
`sandbox: "read-only"`, `approval_policy: "untrusted"` — flags `ollama run` does not have, for
controls it does not implement. That is the "enabled control that does nothing" S-19 forbids, in the
one field where a false claim is worst. A local session now carries `conductor_local_boundary@1.0`
stating the truth — **no tool surface at all** — and the shell verifies that claim *from the argv*
(`isWellFormedLocalBoundary`: exactly three arguments, no flags, no trailing prompt).

**The transcript named the wrong model.** `handleOperatorText` stamped every turn
`provider: "openai_codex_cli", model: "gpt-5.6-sol"` — hardcoded, regardless of what was answering,
and naming a provider that cannot even be authorized under OD-31. It now reads the resolved
descriptor. This is the U65 badge-drift defect reappearing one surface over.

**The delivery guard had no vocabulary for a local runtime.** `deliverChat` refused with *"no
non-executing boundary with supervisor-process enforcement is bound"*, and `paneAcceptsTypedText`
saw *"no input-box chrome this shell recognises"* — both correct fail-closed rules whose vocabulary
covered only the Claude TUI. Extended, not loosened, and argued in the code: the guard asks whether
the conductor is prevented from EXECUTING; for an agentic CLI only a supervisor broker can answer,
while `ollama run` has **no tool-call protocol**, so the property holds by construction — and that
construction is re-derived from the argv, not taken on trust. The frontier path is untouched: a
Claude conductor with no bound broker is refused exactly as before.

## Option C — the deferred spawn

The shell no longer auto-launches a conductor session at startup. It launches, accepts typing, and
the session is born on the operator's **first message**. Measured in the demonstration: after
launch, and again after *selecting* a model, the Conductor had spawned nothing; only sending did it.

This is the quota protection replacing H-10 (which D-4 measured as redundant — the live gate already
fails closed upstream), and it protects local attention as well as frontier quota: opening the shell
no longer loads a 4.9 GB model into an 8 GB card unasked. `SOW_CONDUCTOR_AUTOLAUNCH=1` is an
explicit opt-in for the old behaviour; `=0` keeps its meaning, so the guard `sow.json` sets is
unchanged and still honoured.

## Assertions changed, with authority (S-14)

Authority: directive §4 F-3 and ENTRY 018. Each was extended to cover the local contract; **none was
loosened**, and no test was deleted, skipped or xfailed (S-6).

| test | change |
|---|---|
| `test_pane_picker.py` local roles | `["reasoning","coding"]` → `+ "conductor"`; the uniformity the test guards is intact — every admitted model gets the same three roles and nothing is inferred from a name |
| `test_emit_conductor_launch.py` gates | one added key, `locality`; the four frontier verdicts are unchanged |
| `conductor-source.test.js` | the registered set can no longer be a literal (local rows are host-derived); a local pair is admitted by SHAPE and the internal-agreement assertions still do the work |
| `conductor-launch-source.test.js` | a third reachable state. It previously only ever exercised the REFUSAL branch on this host; an authorized LOCAL ticket now asserts the mirror contract — lease null, nothing to release, `ix3_counted` false, `live_operation_authorized` **null** (not applicable, not merely false) |

## U186 — the mutation baseline, discharged properly

`main.js` changed, and `tools/mutation/pane_input_bypass_mutations.js` pins its hash with the
instruction that the pin "must be updated by someone who re-read these mutations against it". It was
re-pinned **twice** (once per main.js edit) and the harness re-run each time. Both runs:
**ALL MUTATIONS CAUGHT**, and `main.js` restored **byte-identical**. The re-read is recorded in the
file: none of the five anchors the mutations splice on (`IN_HANDLER`, `HANDLER_TOP`, `AFTER_RESUME`,
`BEFORE_INPUT`, `REAL_DISARM`) lies in an edited region, and each still occurs exactly once.

`main.js` carries a **UTF-8 BOM** (N-32a, pre-existing). Every edit was made at byte level and the
BOM verified intact afterwards — removing it would have silently fixed a failing test and moved a
blob hash no item authorizes moving.

## Suites

- `tests/unit` — **2460 passed**, 12 failed. The failing set is **byte-identical** to the parent-seal
  baseline (`diff` of the sorted FAILED lines is empty): **zero regressions**. 2441 → 2460 is the 19
  new cases in `test_agnostic_conductor_local.py`.
- SOW desktop — **1104 / 1104**. SOW terminal — **225 / 225**.

## Reported, NOT fixed

**N-33 · a conductor pane skips VRAM residency admission.** `worker_pane_spawn._authorize_local`
routes a local *worker* through the ResidencyPlanner; `conductor_pane_spawn` holds no planner, so a
conductor pane can be admitted where a worker for the same model would be refused on residency. The
8B ceiling is what bounds a conductor selection today (largest admitted ≈5.1 GB against 8151 MiB).
The asymmetry is real, is stated in the function's own docstring, and is not closed here.

**N-34 · the first message to a cold local model always reports UNCONFIRMED.** Measured: the reply
arrived and was correct, but `submitted: false` with *"the conductor had not accepted the utterance
4000ms after the submit key — it may still land"*. Loading a 4.9 GB model exceeds that window. The
shell **under**-claims, which is the safe direction, so this is reported rather than changed (S-9):
the honest fix is to start the confirmation window when the pane's prompt appears rather than at the
submit key, and that is a behaviour change outside F-3's item.

## Artifacts

`F3-RECEIPT.json` · `f3-conductor-scrollback.txt` (the answer) · `f3-conductor-local.png` ·
`f3-electron.log` · `tools/f3-conductor-local.mjs`

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
