/**
 * LOCAL-01 F-3 — THE CONDUCTOR IS AGNOSTIC. The acceptance ENTRY 018 set.
 *
 * Drives the REAL packaged SOW shell through `window.sovereign`, the contextBridge preload, and
 * establishes the four §7 rows in order:
 *
 *   1. the Conductor LAUNCHES and ACCEPTS TYPING, and SPAWNS NOTHING (option C) — asserted by
 *      reading the conductor state before anything is selected or sent;
 *   2. the Conductor OFFERS THE LOCAL LIBRARY — `sovereign.picker()` local options carrying the
 *      conductor role, under the operator's 8B ceiling;
 *   3. FRONTIER ENTRIES REMAIN VISIBLE AND HONESTLY UNAVAILABLE (S-19/S-20);
 *   4. the Conductor ANSWERS A TYPED MESSAGE FROM A LOCAL MODEL — `sovereign.selectConductor(...)`
 *      then `sovereign.sendOperatorText(...)`, the exact IPCs the dropdown and the send button use.
 *
 * `live_operation.json` is verified ABSENT before launch and must still be absent after. No model
 * is pulled. Nothing above the 8B ceiling is selected.
 */
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { Cdp, findPageTarget, sleep, until } from "../../F2/tools/cdp.mjs";

const DESKTOP = String(process.env.SOW_DESKTOP
  || "D:/producttion software 2/release-worktree/modules/sow/apps/desktop");
const ELECTRON = path.join(DESKTOP, "node_modules", "electron", "dist", "electron.exe");
const PORT = Number(process.env.CDP_PORT || 9223);
const OUT = String(process.env.F3_OUT || ".");
const WANT = String(process.env.F3_MODEL || "qwen3:8b");
const QUESTION = String(process.env.F3_QUESTION
  || "In one short sentence: what is 17 plus 25?");

const r = {
  check: "LOCAL-01.F-3.agnostic-conductor",
  started: new Date().toISOString(),
  ok: false,
  live_operation_json_present_before: null,
  live_operation_json_present_after: null,
  // 1 — option C
  conductor_before: null,
  spawned_nothing_before_send: null,
  // 2 — offers the local library
  conductor_capable_local: null,
  conductor_capable_local_sample: null,
  local_over_ceiling_not_conductor_capable: null,
  // 3 — frontier visible + honestly unavailable
  frontier_visible: null,
  frontier_available: null,
  // 4 — answers a typed message
  selected: null,
  selected_descriptor: null,
  conductor_after_select: null,
  send_result: null,
  transcript_provider: null,
  transcript_model: null,
  answer_chars: null,
  answer_excerpt: null,
  answered: false,
  argv: null,
  subscription: "unset",
  torn_down: false,
  notes: [],
};

function save() {
  fs.mkdirSync(OUT, { recursive: true });
  fs.writeFileSync(path.join(OUT, "F3-RECEIPT.json"), JSON.stringify(r, null, 2) + "\n", "utf8");
}

let child = null;
async function shutdown() {
  if (child && !child.killed) {
    try { child.kill(); } catch { /* gone */ }
    await sleep(1500);
    try { process.kill(child.pid, 0); spawn("taskkill", ["/PID", String(child.pid), "/T", "/F"]); }
    catch { /* already dead */ }
  }
}

const LIVE_CFG = path.resolve(DESKTOP, "..", "..", "config", "live_operation.json");

async function main() {
  r.live_operation_json_present_before = fs.existsSync(LIVE_CFG);
  if (r.live_operation_json_present_before) {
    throw new Error("live_operation.json exists — LOCAL-01 requires it absent (OD-31/S-18)");
  }
  // Clear any remembered selection so the run proves the OPERATOR's choice, not a leftover.
  const store = path.resolve(DESKTOP, "..", "..", ".runtime", "conductor-selection.json");
  try { fs.unlinkSync(store); r.notes.push("cleared a previously remembered local selection"); }
  catch { /* none */ }

  child = spawn(ELECTRON, [".", `--remote-debugging-port=${PORT}`], {
    cwd: DESKTOP,
    // AUTOLAUNCH deliberately UNSET: option C must hold on the default path, not because a guard
    // forced it. If the shell auto-spawned here, row 1 below would fail — which is the point.
    env: { ...process.env, PYTHONDONTWRITEBYTECODE: "1" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const logLines = [];
  child.stdout.on("data", (d) => logLines.push(String(d)));
  child.stderr.on("data", (d) => logLines.push(String(d)));

  const page = await findPageTarget(PORT, {}, 90000);
  const cdp = await Cdp.connect(page.webSocketDebuggerUrl);
  await cdp.send("Runtime.enable");
  await cdp.send("Page.enable");
  const bridge = await until(
    () => cdp.eval("typeof window.sovereign === 'object' && typeof window.sovereign.selectConductor === 'function'"),
    60000);
  if (!bridge) throw new Error("window.sovereign never appeared");

  // ---- ROW 1: it launches, takes typing, and has spawned NOTHING ----------------------------
  const before = await until(async () => {
    const s = await cdp.eval("(async () => await window.sovereign.conductorState())()");
    return s && typeof s === "object" ? s : null;
  }, 90000, 1500);
  r.conductor_before = before && {
    paneId: before.paneId, live: before.live, nodeState: before.nodeState,
    launchState: (before.launch || {}).state || null,
  };
  // "spawns nothing" — no live session, and the launch record is not running.
  r.spawned_nothing_before_send = Boolean(before) && before.live !== true
    && ((before.launch || {}).state || "idle") !== "running";

  // ---- ROWS 2 & 3: the Conductor offers the local library; frontier stays visible ------------
  const opts = await until(async () => {
    const m = await cdp.eval("(async () => await window.sovereign.picker())()");
    return m && m.ok ? m : null;
  }, 120000, 2000);
  if (!opts) throw new Error("the picker never returned a usable enumeration");
  const summary = await cdp.eval(`(async () => {
    const m = await window.sovereign.picker();
    const o = (m.picker && m.picker.options) || [];
    const local = o.filter(x => x.locality === 'local');
    const cond = local.filter(x => (x.roles || []).includes('conductor') && x.conductor_capable === true);
    const over = local.filter(x => !x.available);
    return {
      conductorCapableLocal: cond.length,
      sample: cond.slice(0, 8).map(x => x.label),
      overCeilingConductorCapable: over.filter(x => x.conductor_capable === true).length,
      frontierVisible: o.filter(x => x.locality === 'frontier').length,
      frontierAvailable: o.filter(x => x.locality === 'frontier' && x.available).length,
      want: local.find(x => x.label === ${JSON.stringify(WANT)}) || null,
    };
  })()`);
  r.conductor_capable_local = summary.conductorCapableLocal;
  r.conductor_capable_local_sample = summary.sample;
  r.local_over_ceiling_not_conductor_capable = summary.overCeilingConductorCapable === 0;
  r.frontier_visible = summary.frontierVisible;
  r.frontier_available = summary.frontierAvailable;
  if (!summary.want || summary.want.available !== true) {
    throw new Error(`${WANT} is not an available local option`);
  }

  // ---- ROW 4a: the operator selects a LOCAL model as the Conductor ---------------------------
  const sel = await cdp.eval(`(async () => {
    const m = await window.sovereign.picker();
    const opt = (m.picker.options || []).find(o => o.locality === 'local' && o.label === ${JSON.stringify(WANT)});
    const st = await window.sovereign.conductorState();
    return await window.sovereign.selectConductor({
      option: opt, role: 'conductor', targetPaneId: st.paneId,
    });
  })()`);
  r.selected = sel && sel.selected === true;
  r.selected_descriptor = (sel && sel.descriptor) || null;
  if (!r.selected) throw new Error(`the Conductor refused the local selection: ${JSON.stringify(sel)}`);

  const afterSelect = await cdp.eval("(async () => await window.sovereign.conductorState())()");
  r.conductor_after_select = afterSelect && {
    live: afterSelect.live, nodeState: afterSelect.nodeState,
    badge: afterSelect.badge, launchState: (afterSelect.launch || {}).state || null,
  };
  // Still nothing spawned: selecting is not sending (option C).
  r.notes.push(afterSelect && afterSelect.live !== true
    ? "after SELECTING a model the Conductor had still spawned nothing — only sending does that"
    : "WARNING: a session existed after selection alone");

  // ---- ROW 4b: the operator types, and the local model answers -------------------------------
  const send = await cdp.eval(
    `(async () => await window.sovereign.sendOperatorText(${JSON.stringify(QUESTION)}))()`,
    { awaitPromise: true });
  r.send_result = send && { ok: send.ok, responseChars: send.responseChars,
                            turn: send.turn && { provider: send.turn.provider, model: send.turn.model,
                                                 delivered: send.turn.delivered,
                                                 submitted: send.turn.submitted,
                                                 reason: send.turn.reason } };
  r.transcript_provider = (send && send.turn && send.turn.provider) || null;
  r.transcript_model = (send && send.turn && send.turn.model) || null;

  const state = await cdp.eval("(async () => await window.sovereign.conductorState())()");
  r.argv = (state && state.launch && state.launch.argv) || null;
  r.subscription = (state && state.badge && state.badge.subscription) !== undefined
    ? (state.badge || {}).subscription : ((state || {}).subscription ?? null);

  // The reply lands in the conductor transcript as an "in" turn.
  const answer = await until(async () => {
    const t = await cdp.eval(`(async () => {
      const s = await window.sovereign.scrollback((await window.sovereign.conductorState()).paneId);
      return (s && s.text) || '';
    })()`);
    if (typeof t !== "string") return null;
    const i = t.indexOf(QUESTION);
    const after = i === -1 ? t : t.slice(i + QUESTION.length);
    const cleaned = after.replace(/\u001b\[[0-9;?]*[a-zA-Z]/g, "").replace(/[\s>]+/g, " ").trim();
    return cleaned.length >= 12 ? { raw: after, cleaned } : null;
  }, 240000, 1500);

  if (answer) {
    r.answered = true;
    r.answer_chars = answer.cleaned.length;
    r.answer_excerpt = answer.raw.slice(0, 2000);
  }

  fs.mkdirSync(OUT, { recursive: true });
  const shot = await cdp.send("Page.captureScreenshot", { format: "png" });
  fs.writeFileSync(path.join(OUT, "f3-conductor-local.png"), Buffer.from(shot.data, "base64"));
  const transcript = await cdp.eval(`(async () => {
    const s = await window.sovereign.scrollback((await window.sovereign.conductorState()).paneId);
    return (s && s.text) || '';
  })()`);
  fs.writeFileSync(path.join(OUT, "f3-conductor-scrollback.txt"), String(transcript || ""), "utf8");

  r.live_operation_json_present_after = fs.existsSync(LIVE_CFG);
  r.torn_down = true;
  cdp.close();
  fs.writeFileSync(path.join(OUT, "f3-electron.log"), logLines.join(""), "utf8");
  r.ok = Boolean(r.spawned_nothing_before_send && r.selected && r.answered
    && r.conductor_capable_local > 0 && r.frontier_visible > 0 && r.frontier_available === 0
    && r.live_operation_json_present_after === false);
}

main()
  .catch((e) => { r.error = e.message; })
  .finally(async () => {
    r.finished = new Date().toISOString();
    if (r.live_operation_json_present_after === null) {
      r.live_operation_json_present_after = fs.existsSync(LIVE_CFG);
    }
    await shutdown();
    save();
    console.log(JSON.stringify({
      ok: r.ok, spawnedNothingBeforeSend: r.spawned_nothing_before_send,
      conductorCapableLocal: r.conductor_capable_local,
      frontierVisible: r.frontier_visible, frontierAvailable: r.frontier_available,
      selected: r.selected, answered: r.answered, answerChars: r.answer_chars,
      transcript: [r.transcript_provider, r.transcript_model], argv: r.argv,
      liveOperationJsonAfter: r.live_operation_json_present_after, error: r.error || null,
    }, null, 2));
    process.exit(r.ok ? 0 : 1);
  });
