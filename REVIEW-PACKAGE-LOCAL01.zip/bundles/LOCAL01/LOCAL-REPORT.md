# LOCAL-01 — BUILDER REPORT
## Seat `claude-code (opus-5)` · SWS-REM-DIR-20260828 R2 + Annex A · ENTRIES 017 + 018
## Parent seal `8d9f5d2415599eeb0b71dc85a25a36469b41641e`
## **LOCAL-01 seal `0b6e3fe7346e7eaa581ce7fc02cf36f46e58bc75`** (9 commits)
## Directive: `CLAUDE-LOCAL-01-DIRECTIVE-R2-20260830.md`, hash verified at boot

---

## THE OBJECTIVE, AND WHETHER IT WAS MET

ENTRY 017 set the bar so it could not drift: *"a green suite that does not end in a working
conversation with a local model is a FAILED run."*

It ends in one. The Conductor, backed by `qwen3:8b` running on the operator's own disk, answered a
typed message:

> `>>>` In one short sentence: what is 17 plus 25?
> *Thinking… 17 plus 20 is 37, and then adding 5 more makes 42. Wait, let me check again. 10+20 is
> 30, 7+5 is 12, so 30+12 is 42.*
> **"17 plus 25 equals 42."**

`live_operation.json` was absent before, during and after. No model was pulled. Nothing above 8B was
selected, defaulted to or used.

---

## §7 CONVERGENCE CHECKLIST — no blank row

```
[x] D-1 local library enumerated, every model over 8B named
[x] D-2 VRAM admission gate: establishes, or exact reason
[x] D-3 Conductor model path scoped — what stands between it and a local session
[x] D-4 H-10 redundancy measured, not reasoned
[x] D-5 selection-to-prompt path traced
[x] F-1 local models selectable, 8B ceiling enforced with stated reasons
[x] F-2 SOW terminal reaches a live local prompt
[x] F-3 Conductor offers the local library
[x] F-3 Conductor launches and accepts typing, spawning nothing until sent
[x] F-3 Conductor answers a typed message from a local model
[x] F-3 frontier entries visible and honestly unavailable
[x] F-4 Debate runs a real local multi-model exchange
[x] F-5 SOVEREIGN offers the local library under the ceiling
[x] F-6 SOW receipts out of the tracked tree
[x] F-7 build_release cuts all eight
[x] F-8 provenance cross-hash GREEN
[x] G suites measured
[x] G all six gates measured, provenance GREEN
[x] G end-to-end local demonstration captured
[x] H seal, artifacts after the seal, cold-extract verified
[x] H review package, notes, report with LIVE-VERIFICATION REQUEST
```

---

## BOOT — an obstruction, reported in-session (ENTRY 011 §5)

All three directive hashes matched. HEAD matched the parent seal. ENTRIES 001–018 present.

`git status --porcelain` (exit 0) carried **13 modified tracked files and 4 untracked entries**, not
the one untracked file the directive expected. The modified files are stamped
`2026-08-30T03:38:31Z`–`03:38:34Z` — between ENTRY 016 and ENTRY 017 — and are the **validator's own
live-census session**, not product runtime writes.

They were preserved byte-for-byte (`D/boot-preserved/`, `D/BOOT-dirt-sha256.txt`) and restored from
an **explicit closed list**, never from `git diff --name-only` — the S-5 mistake FIXUP-01 recorded
against itself. The four untracked entries were left where they were written (E-2); **every
porcelain assertion in this run is stated modulo those four named paths.**

---

## PHASE D — what the measurements changed

Full detail in `D/DIAGNOSIS.md`. Four findings mattered enough to change the work:

**D-1 · The library was invisible for a reason nobody had found.** `OLLAMA_MODELS` is set at user
scope to `D:\SOVEREIGN\models\vault` — a directory that **did not exist**. The real 984 GB library
is at `C:\Users\Sslaw\.ollama\models`. So the daemon was healthy and served **zero** models. The
punch list's N-28 remedy ("Ollama is not running. Host state. Start it.") would have produced a
green daemon serving nothing, with the symptom unchanged and one clue fewer. **60 models
enumerated, 8 admitted, 52 excluded with reasons.** Recorded for the operator as **N-30**.

**D-2 · The VRAM gate was never the blocker.** It establishes with the daemon up; FIXUP-01 saw it
fail only because the daemon was unreachable. But it establishes at a **12288 MB stand-in on a card
that has 8151 MiB** (`nvidia-smi`, RTX 5060 Ti) — the operator's exact straddle complaint. **N-31.**

**D-4 · The live gate refused `ollama_local`.** Measured, not reasoned. A model that costs nothing
was refused with a message about *spend authorization* — S-20 verbatim. The worker path escaped it
only by branching around the gate. This became the centre of F-3.

**D-5 · The picker authorized `phi4:14b`.** 14.7B, 8633 MB, on an 8 GB card — the exact hazard
ENTRY 017 exists to prevent — while offering `deepseek-r1:70b` as available and refusing it only
after the click, and silently dropping seven namespaced models.

---

## PHASE F — nine commits

| commit | item |
|---|---|
| `d379d77` | F-1 the 8B ceiling, one authority, honest exclusions |
| `39079f6` | F-3 the Conductor seat is agnostic |
| `607d358` | F-4 Debate on local seats under the ceiling |
| `f0fe9dd` | F-5 SOVEREIGN's every assignment under the ceiling |
| `029177e` | F-6 runtime receipts leave the tracked tree |
| `c9821f5` | F-7 the producer cuts all eight |
| `e191081` | F-8 the registry refresh — the last blocking gate goes green |
| `b39d472` | G a test bound to a magic character count, corrected |
| `0b6e3fe` | H **the seal** |

**F-2 has no commit, and that is the finding.** The path was already complete; what was missing was
the ceiling, which F-1 supplied. Recording an item as "done, no diff" is more honest than
manufacturing a change to point at.

Every item's notes, evidence and receipts are under `bundles/LOCAL01/F*/`.

---

## PHASE G — measured at the seal

### Suites

| suite | result | baseline |
|---|---|---|
| SOW desktop (node) | **1104 / 1104** | 1104 ✓ |
| SOW terminal (node) | **225 / 225** | 225 ✓ |
| Token Center | **32 passed** | 32 ✓ |
| shell | **190 passed, 0 failed** | 190 ✓ |
| tools/release | **89 passed, 0 failed** | 84 + 5 new ✓ |
| SOW `tests/unit` | **2460 passed, 12 failed** | failing set **byte-identical** to the parent seal — zero regressions |

The 12 are **pre-existing at the seal** (**N-32**), proven by running the same command in a clean
`git worktree` detached at `8d9f5d24`: `diff` of the sorted FAILED lines is empty. 2379 → 2460 is
this run's 81 new cases.

**Interpreter finding.** `py -3.12` is the baseline interpreter — the only one on this host with
both pytest and jsonschema, the one the shell itself invokes, and the one
`release-worktree/CLAUDE.md` §9 already mandates ("`py -3.12` always; bare `python` (3.14) never").
Under the host default 3.14 the shell suite reports 188 passed + 2 `ModuleNotFoundError:
jsonschema` failures — which reconciles the directive's stale "shell 188" baseline exactly:
188 + 2 = 190. This is punch-list **E-1** surfacing as a suite result.

**No whole-`pytest tests` figure is asserted.** That run reached ~14% in ~25 minutes against a
recorded 638 s baseline and was stopped rather than left for hours; `tests/unit` alone completes in
~80 s, so the cost is entirely in `tests/integration`, whose host-coupled members now probe a
**running** daemon with 60 models for the first time in this program. That is a measurement about
the suite's cost, not a claim about its result.

### All six gates at the seal — GREEN

```
package_boundary_gate       PASS  3508 scanned, 0 violations, 0 credential hits   exit 0
release_manifest_check      PASS  0 problems                                      exit 0
provenance_cross_hash_check PASS  all five modules OK                             exit 0
check_model_consistency     PASS                                                  exit 0
check_governance_bom        PASS                                                  exit 0
innerhtml_sink_audit        PASS  39 templates, 112 interpolations                exit 0
```

The boundary gate was run **archive-bound on the cold extract**, `--allowlist` taken from inside
that tree — the invocation FIXUP-01 recorded, because passing the worktree's allowlist produces a
false FAIL on the archive's own fixture file. `innerhtml_sink_audit` needs `--file` (the ledger's
own `scope_file`) and `--ledger`; the invocation is recorded in `G/g-six-gates.txt` so it is not
reported unmeasured a second time.

### Archive delta, accounted item by item

**3503 → 3508 = +5**, and 52 modified, 0 deleted. The five added files are
`adapters/local/model_ceiling.py`, three SOW test files, and `tools/release/test_runtime_writes_are_gitignored.py`.
Full `--name-status` listing in `G/`.

### S-5 restoration, hash-verified from the closed list

The shell suite regenerates `evidence/hardening/*` and `shell/BUILD-MANIFEST.txt` as a side effect.
All 13 were restored from the **explicit closed list** and each verified byte-identical to its
committed blob (`git hash-object` vs `git rev-parse HEAD:<path>`) — `G/g-s5-restoration.txt`.
Porcelain after: clean, modulo the four named untracked paths.

### The acceptance that matters (S-17) — captured end to end

One consolidated run at final bytes, `bundles/LOCAL01/G/`:

| leg | result |
|---|---|
| Ollama up, library enumerated | 60 enumerated, 8 admitted under the ceiling |
| a local model ≤8B selected | `qwen3:8b` (8.2B) selected in the Conductor |
| a SOW terminal reaching a live prompt | `ollama run qwen3:8b` in pane-2, **1756 chars** answered |
| **the Conductor answering a typed message from a local model** | **"17 plus 25 equals 42."** |
| the Conductor spawned nothing until sent to | `spawnedNothingBeforeSend: true` |
| frontier visible and honestly unavailable | 23 visible, 0 available |
| a real Debate exchange | 4 turns, both seats, **both models observed resident in VRAM** |
| clean stop, no orphans | no `electron`, no `node`; ports 8700/5175/5180 free |

The Debate residency samples show `qwen3:8b` (5.58 GB) and `dolphin3:8b` (5.27 GB) **alternating**
in VRAM — which is how one 8 GB card serves two 8B seats, measured rather than assumed.

Everything was driven through the product's own bridge (`window.sovereign`: `picker()`,
`spawnFromSelection()`, `selectConductor()`, `sendOperatorText()`, `input()`, `scrollback()`) — the
exact IPCs an operator's clicks and keystrokes send. No test-only path, and no code was added to the
product to make any of it observable.

---

## PHASE H — the seal, in acyclic order

1. No code changes → identity regenerated (`source_commit b39d472`, the last product/tooling commit)
   and `RELEASE-MANIFEST.json` re-measured over **tracked bytes only**, using the checker's own
   `_hash_bearing_objects` walker so the refreshed set is exactly the set it verifies. 15 hashes
   re-measured; **no entry added or removed**.
2. **Committed — the seal `0b6e3fe7`.**
3. All eight artifacts **cut from that commit** by the F-7 producer. Every one carries the seal in
   its zip comment, matches `release-build-manifest.json` byte-for-byte, and agrees with its sidecar.
4. The stranger guard proven live: a planted `STALE-LEFTOVER-src.zip` **aborted** the build with the
   OD-33 reason instead of being published as authoritative.
5. Cold-extracted: **3508 files**, equal to `git archive HEAD`; boundary gate PASS on the extract.
6. **S-15 re-verified after the regeneration**: a *correct* hash smuggled into an unverified section
   is still caught — the property FIXUP-01 recorded as T-4 survives.

---

## LIVE-VERIFICATION REQUEST — for the validator and the operator

Everything below was driven from this seat through the product's own IPC bridge. These are the legs
where a human's own eyes and hands are the point, not a substitute for a measurement I could not
take.

**LV-1 (operator, ~2 minutes) — the deliverable, in your hands.**
Open the shell, open the Conductor pane, choose `qwen3:8b` from the model list, type a question,
press Enter. Confirm: (a) nothing spawned before you sent; (b) it answers; (c) the badge and the
transcript name `ollama_local / qwen3:8b`. This is the row ENTRY 017 wrote the run for, and the one
thing only you can confirm is *yours*.

**LV-2 (operator, ~1 minute) — the ceiling reads as intended.**
In the picker, look at `phi4:14b` and `deepseek-r1:70b`. Confirm they are **listed, greyed, and
explain themselves** rather than being missing, and that the sentence is one you would want to read.
The wording is a judgement I made; it is yours to accept or change.

**LV-3 (operator, one line, host state — this is N-30 and it is not a repo fix).**
`OLLAMA_MODELS` is set at user scope to `D:\SOVEREIGN\models\vault`, which is empty; your 984 GB
library is at `C:\Users\Sslaw\.ollama\models`. This run started the daemon against the real store
**session-scoped only** — your user variable was not modified, because it is outside the write set.
Until you change it (or populate the vault), a daemon started from your normal environment will
serve **zero** models and every symptom returns. Decide which store is authoritative.

**LV-4 (validator) — the frontier refusal is intact.**
Confirm independently that `live_operation.json` is still absent, that every frontier row reports
unavailable, and that no path in this run creates, stubs or routes around it. F-3 deliberately
*relies* on that refusal rather than removing it, and I am the wrong seat to certify my own restraint.

**LV-5 (validator) — the delivery-guard extension.**
`voice/conductor-write.js` now accepts a `conductor_local_boundary@1.0` as a non-executing boundary,
verified from the argv by `launch-source.isWellFormedLocalBoundary` (exactly three arguments, no
flags). The argument — that `ollama run` has no tool-call protocol, so the property the supervisor
broker enforces for Claude holds here by construction — is in the code. It is a security guard and a
second pair of eyes on that reasoning is worth more than my confidence in it.

**LV-6 (reviewer) — still the longest pole, and untouched by this run.**
The 19 CANDIDATE gates and Gate-5/5b remain unadjudicated, as does OD-23 and OD-28 (N-19). This run
confirmed N-19 incidentally: the validator's own session had regenerated
`shell/BUILD-MANIFEST.txt` from 67 to 80 entries, which is independent evidence the sealed manifest
is stale. Reported, not fixed — it is your lane (§9).

---

## FINDINGS REPORTED, NOT FIXED

| id | finding |
|---|---|
| **N-30** | `OLLAMA_MODELS` points at an empty vault; the real library is elsewhere. Host state, outside the write set. The true cause behind N-28. |
| **N-31** | The VRAM stand-in claims 12288 MB where the card has 8151 MiB. The ceiling makes it moot for selection today; `SOW_VRAM_BUDGET_MB=8192` is the operator's one-line remedy. Hardcoding it would bake a developer-machine value into distributed bytes (S-16). |
| **N-32** | 12 `tests/unit` failures pre-exist at the parent seal, including **two tracked files carrying a UTF-8 BOM** (`main.js`, `preload.js`) which the repo's own guard forbids. Every edit to `main.js` in this run preserved that BOM deliberately — removing it would have fixed a failing test as a side effect of unrelated work and moved a blob hash no item authorizes moving. `pytest.ini`'s recorded "2382 passed / 0 failed" contract is stale. |
| **N-33** | A conductor pane skips the VRAM residency admission a worker pane applies; the 8B ceiling bounds it today. Stated in the function's own docstring. |
| **N-34** | The first message to a cold local model reports UNCONFIRMED — the 4 s echo window is shorter than a 4.9 GB model load. The shell **under**-claims, which is the safe direction. |
| **N-35** | Debate's `qwen3:8b` seat produces short turns and skips (PARTIAL — mechanism inferred, not root-caused to D-4's standard). A thinking model's budget goes to reasoning, leaving a spoken remainder under `turn_word_min`. SOVEREIGN already disables thinking for qwen3; Debate does not. |
| **N-36** | Debate has no frontier surface at all, so S-20's "frontier shown and honestly unavailable" half has nothing to show. Building one is OP-7, named in the punch list as a program, not a line. |
| **N-37** | The operator's ceiling now lives in **three** files (sow, debate, sovereign), duplicated rather than imported across product boundaries. Each names the others. A shared policy artifact is the structural fix and is an architecture decision, not a builder's. |
| **N-38** | The general runtime-writes assertion found **seven more instances of the N-16 class** in four other adapters — `debate.json` persists a seat-model change into its own tracked `config.json`, so using the model dropdown edits the release candidate. Pinned in a list that may only shrink; not fixed (S-9). |
| **N-39** | **S-2 is not satisfied tree-wide, and has not been for the whole program.** The rule reads "assert no tracked file begins `FF FE` after each commit". **Eight tracked files do**, and the census is **byte-identical at the parent seal** — this run introduced none. See below; recorded because I asserted the narrow form twice before measuring the broad one. |

---

## WHAT I REFUTED OR CORRECTED

- **N-28's cause.** "Ollama is not running" was true and insufficient; the daemon was healthy and
  serving nothing (N-30).
- **The directive's "shell 188" baseline.** It is 190; 188 is what passes on an interpreter missing
  SOW's unpinned dependency.
- **My own first F-3 acceptance.** The `answered: true` in the first conductor run was a **false
  positive** — my check matched the spinner and the prompt, not a reply. I found it by reading the
  scrollback for the actual answer, corrected the run, and the recorded result is the corrected one.

- **My own S-2 assertions (N-39).** After F-1 and F-3 I asserted "no `FF FE`" having checked only
  the files those commits touched. That is the narrow form. Measured tree-wide at the end, **eight
  tracked files begin `FF FE`**:

  ```
  dev/v1.2.1-hardening/release-evidence/lifecycle/phase0-baseline-boot.json
  evidence/manifests/manifest-diff-4b-distillery.txt
  evidence/manifests/manifest-diff-4b-product-software.txt
  evidence/manifests/manifest-diff-4b-sow.txt
  evidence/manifests/manifest-diff-final-distillery.txt
  evidence/manifests/manifest-diff-final-product-software.txt
  evidence/manifests/manifest-diff-final-sow.txt
  modules/sovereign/WORKSPACE-RESOLVED-LOCK.txt
  ```

  The census is **identical at the parent seal** (8 files, same paths), so **this run introduced
  none** and the rule's intent — my commits must not add one — holds. But S-2 as written is a
  property of the tree, not of a diff, and the tree has not satisfied it for the whole program.
  Seven are frozen historical evidence that R2 forbids rewriting; the eighth,
  `modules/sovereign/WORKSPACE-RESOLVED-LOCK.txt`, is a **live dependency lock** the identity
  generator reads, which makes it the one worth the operator's attention. Not fixed: converting a
  lock's encoding moves bytes the identity documents digest, and it is outside this run's items
  (S-9). Reported so the next seat measures the property rather than the diff.

---

## STANDING RULES

S-1 write set respected (`release-worktree`, `bundles/LOCAL01`), plus the two files directive
§6 explicitly requires outside it: `release-planning/REVIEW-PACKAGE-LOCAL01.zip` (+ sidecar)
and the appended `release-planning/bundles/LOOP-RUN-REPORT.md`. S-2 measured tree-wide rather than
per-diff: **8 tracked files begin `FF FE`, identical at the parent seal — this run introduced none**
(N-39). `main.js`'s pre-existing UTF-8 BOM preserved through four edits. S-3 every API read before use —
`LiveAuthorization.denied` (not `unauthorized`), the Ollama config-blob schema, `ProfileLoader`'s
signature, the manifest checker's own walker. S-4 coupled values moved together, each site listed.
S-5 restoration from a closed list, hash-verified. S-6 no test deleted, skipped, xfailed or loosened.
S-8 one item, one commit, fail-before and pass-after. S-9 nine findings parked rather than
improvised. S-10 **no model pulled, of any size**; no billed call; no provider call. S-13/S-14
assertion changes carry their authority in the commit and in the code. S-15 re-verified by tamper
test. **S-18 `live_operation.json` neither created, stubbed, mocked nor routed around.** S-19/S-20
are what most of this run is.

`main.js` changed four times; the U186 mutation baseline was re-pinned and the harness re-run each
time, with the re-read recorded in the file. **Every run: ALL MUTATIONS CAUGHT, `main.js` restored
byte-identical.**

---

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
