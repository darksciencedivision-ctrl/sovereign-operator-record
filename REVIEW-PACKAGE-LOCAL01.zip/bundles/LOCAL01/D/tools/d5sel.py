"""D-5: build the picker's own local option for qwen3:8b, hermetically.
No frontier probe, no network, no model call."""
import json, sys
from pathlib import Path
ROOT = Path(r"D:\producttion software 2\release-worktree\modules\sow")
sys.path.insert(0, str(ROOT))
from adapters import detect
from control_plane.nodes.pane_picker import _local_options

models = detect.ollama_models()
print(f"# detect.ollama_models() returned {len(models)} models", file=sys.stderr)
opts = _local_options(models, None, None)
want = sys.argv[1] if len(sys.argv) > 1 else "qwen3:8b"
match = next((o for o in opts if o["label"] == want), None)
if match is None:
    print(f"# {want!r} NOT in local options", file=sys.stderr); sys.exit(3)
print(json.dumps({"option": match, "role": "reasoning"}, indent=2))
