"""D-4: does anything billable actually spawn with live_operation.json absent?
Measured, not reasoned. No CLI is launched by this probe; it exercises the real gates."""
import sys, os, traceback
from pathlib import Path
ROOT = Path(r"D:\producttion software 2\release-worktree\modules\sow")
sys.path.insert(0, str(ROOT))

print("live_operation.json exists:", (ROOT/"config"/"live_operation.json").exists())

from control_plane.profiles.live_authorization import load_live_authorization, LiveAuthorizationError
try:
    la = load_live_authorization()
    print("load_live_authorization() ->", la.as_dict())
except Exception as e:
    print(f"load_live_authorization() RAISED {type(e).__name__}: {e}")
    la = None

if la is not None:
    for prov in ("claude_code", "openai_codex_cli", "ollama_local"):
        try:
            la.assert_provider_live(prov)
            print(f"  assert_provider_live({prov!r}) -> ALLOWED")
        except Exception as e:
            print(f"  assert_provider_live({prov!r}) -> REFUSED: {type(e).__name__}: {e}")

# The governed conductor spawn itself.
from control_plane.conductor.registry import load_runtime_conductor_descriptor
d = load_runtime_conductor_descriptor()
print("\nruntime conductor descriptor:", d.as_dict())

from node_runtime.supervisor.conductor_pane_spawn import spawn_conductor_pane
import inspect
print("\nspawn_conductor_pane signature:", inspect.signature(spawn_conductor_pane))
