"""LOCAL-01 D-1: enumerate the on-disk Ollama library from bytes.

Reads manifests and their config blobs directly. Contacts no daemon, pulls
nothing, loads nothing (S-10).

Schema, read from an actual config blob rather than assumed (S-3):
  model_type   -> parameter count string, e.g. "8.2B", "566.70M"
  file_type    -> quantization, e.g. "Q4_K_M"
  model_family -> architecture family; absent on cloud rows
  remote_host / remote_model -> present ONLY on Ollama Cloud rows (not local)
"""
import json, os, re, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\Sslaw\.ollama\models"
MAN = os.path.join(ROOT, "manifests")
BLOBS = os.path.join(ROOT, "blobs")

# Families that produce embeddings, not chat completions.
EMBED_FAMILIES = {"bert", "nomic-bert"}

CEILING_PARAMS = 9.0e9      # true-count implementation of the 8B nameplate class
CEILING_NAMEPLATE = 8       # billions


def blob_path(digest):
    return os.path.join(BLOBS, digest.replace(":", "-"))


def parse_params(s):
    if not s:
        return None
    m = re.match(r"^\s*([\d.]+)\s*([BbMmKkTt])?\s*$", str(s))
    if not m:
        return None
    return float(m.group(1)) * {"T": 1e12, "B": 1e9, "M": 1e6, "K": 1e3, "": 1.0}[
        (m.group(2) or "").upper()]


def nameplate_b(tag, true_params):
    """Vendor nameplate size in billions, from the tag when it encodes one."""
    m = re.match(r"^(\d+(?:\.\d+)?)b\b", tag.lower())
    if m:
        return float(m.group(1))
    if true_params is None:
        return None
    b = true_params / 1e9
    # round to the class the vendor would print
    return float(round(b)) if b >= 1 else b


def human(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}"
        n /= 1024


rows = []
for dirpath, _d, filenames in os.walk(MAN):
    for fn in filenames:
        full = os.path.join(dirpath, fn)
        rel = os.path.relpath(full, MAN).replace("\\", "/")
        p = rel.split("/")
        tag, model, ns = p[-1], p[-2], p[-3]
        if p[0] == "registry.ollama.ai":
            name = f"{model}:{tag}" if ns == "library" else f"{ns}/{model}:{tag}"
        else:
            name = f"{'/'.join(p[:-1])}:{tag}"

        man = json.load(open(full, encoding="utf-8"))
        seen, size = set(), 0
        for layer in man.get("layers") or []:
            d = layer.get("digest")
            if d and d not in seen:
                seen.add(d)
                size += int(layer.get("size") or 0)

        cfg = {}
        cfgd = (man.get("config") or {}).get("digest")
        if cfgd and os.path.exists(blob_path(cfgd)):
            cfg = json.load(open(blob_path(cfgd), encoding="utf-8"))

        params_str = cfg.get("model_type")
        params = parse_params(params_str)
        family = cfg.get("model_family")
        is_cloud = bool(cfg.get("remote_host") or cfg.get("remote_model"))
        is_embed = family in EMBED_FAMILIES
        np_b = nameplate_b(tag, params)
        missing = [d for d in seen if not os.path.exists(blob_path(d))]

        # Admission, in priority order; every exclusion carries a reason (S-19).
        if is_cloud:
            admitted, reason = False, (
                f"Ollama Cloud model ({cfg.get('remote_model') or name} via "
                f"{cfg.get('remote_host') or 'remote host'}) - runs remotely, not on "
                f"this machine, and is not local operation. Frontier/live authorization "
                f"is DENIED for now (OD-31), so it cannot be selected.")
        elif missing:
            admitted, reason = False, (
                f"{len(missing)} of {len(seen)} layer blobs are missing from the local "
                f"store - the model is listed but not fully present on disk.")
        elif is_embed:
            admitted, reason = False, (
                f"embedding model ({family}, {params_str} parameters) - produces vectors, "
                f"not chat replies; it cannot answer a typed message.")
        elif params is None:
            admitted, reason = False, "parameter count could not be read from the model config."
        elif params >= CEILING_PARAMS:
            admitted, reason = False, (
                f"{params_str} parameters exceeds the operator's {CEILING_NAMEPLATE}B ceiling "
                f"(ENTRY 017) - this host's GPU has 8 GB of VRAM.")
        else:
            admitted, reason = True, ""

        rows.append({
            "name": name, "manifest": rel, "params_str": params_str, "params": params,
            "nameplate_b": np_b, "quant": cfg.get("file_type"), "family": family,
            "cloud": is_cloud, "embedding": is_embed, "missing_blobs": len(missing),
            "size_bytes": size, "size_human": human(size),
            "admitted": admitted, "reason": reason,
        })

rows.sort(key=lambda r: (not r["admitted"], -(r["params"] or 0), r["name"]))

if "--json" in sys.argv:
    print(json.dumps(rows, indent=2))
else:
    adm = [r for r in rows if r["admitted"]]
    exc = [r for r in rows if not r["admitted"]]
    print(f"store: {ROOT}")
    print(f"models found: {len(rows)}   admitted: {len(adm)}   excluded: {len(exc)}")
    tot = sum(r["size_bytes"] for r in rows)
    print(f"total on-disk: {human(tot)}\n")
    print(f"== ADMITTED (at or under the {CEILING_NAMEPLATE}B ceiling, chat-capable, fully present) ==")
    print(f"{'MODEL':<40} {'PARAMS':>8} {'NAME':>6} {'QUANT':<9} {'ON DISK':>10}")
    for r in adm:
        print(f"{r['name']:<40} {str(r['params_str']):>8} {str(r['nameplate_b'])+'B':>6} "
              f"{str(r['quant']):<9} {r['size_human']:>10}")
    print(f"\n== EXCLUDED, each with a stated reason (S-19) ==")
    for r in exc:
        print(f"{r['name']:<40} {str(r['params_str']):>8} {r['size_human']:>10}")
        print(f"    reason: {r['reason']}")
