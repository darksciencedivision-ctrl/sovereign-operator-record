import json, sys, urllib.request
from pathlib import Path
sys.path.insert(0, r"D:\producttion software 2\release-worktree\modules\sow")
from adapters import detect
det = set(detect.ollama_models())
tags = {m["name"] for m in json.load(urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=10))["models"]}
print("detect:", len(det), " /api/tags:", len(tags))
print("in /api/tags but NOT in detect:", sorted(tags - det))
print("in detect but NOT in /api/tags:", sorted(det - tags))
import inspect
print("\n--- detect.ollama_models source ---")
print(inspect.getsource(detect.ollama_models))
