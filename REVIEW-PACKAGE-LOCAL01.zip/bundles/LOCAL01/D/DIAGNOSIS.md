# LOCAL-01 · PHASE D — DIAGNOSIS
## Builder seat `claude-code (opus-5)` · parent seal `8d9f5d2415599eeb0b71dc85a25a36469b41641e`
## Method: every claim reproduced from bytes and from the running product before any change.
## Standard adopted from `bundles/FIXUP01/D/DIAGNOSIS.md` (directive §2.4).

The Ollama daemon was started for this run (operator-authorized, local, no spend). **No model was
pulled, of any size (S-10). No model above 8B was loaded, selected or defaulted to.**
`modules/sow/config/live_operation.json` was never created and does not exist.

---

## Summary table

| check | item | verdict |
|---|---|---|
| D-1 | local library enumerated, every model over 8B named | **VERIFIED + new root cause found** |
| D-2 | VRAM admission gate establishes, or exact reason | **VERIFIED — it establishes; its budget is wrong by +4 GB** |
| D-3 | Conductor model path scoped | **VERIFIED — five blockers, every one inside the write set** |
| D-4 | H-10 redundancy measured | **VERIFIED for frontier + new defect: the live gate refuses LOCAL too** |
| D-5 | selection-to-prompt traced | **VERIFIED — the path works; the ceiling does not exist** |
| D-6 | baselines | **VERIFIED — archive 3503, boundary gate PASS** |

---

## BOOT OBSTRUCTION, recorded (not a hash mismatch ⇒ no BOOT-FAILURE.md, ENTRY 011 §5)

All three directive hashes matched exactly. HEAD matched the parent seal `8d9f5d24…`.
ENTRIES 001–018 present.

`git status --porcelain` (exit status 0 captured) did **not** carry only the one expected untracked
file. It carried **13 modified tracked files and 4 untracked entries**:

```
 M evidence/gate5/screenshots/shell-grid-rendered.png
 M evidence/hardening/deps-proof.txt          M evidence/hardening/h16-contrast.txt
 M evidence/hardening/h1-listen.txt           M evidence/hardening/h17-dom.txt
 M evidence/hardening/h13-assets.txt          M evidence/hardening/h3-headers.txt
 M evidence/hardening/h14-doclinks.txt        M evidence/hardening/h4-dom.txt
 M evidence/hardening/h15-distillery-contract.txt  M evidence/hardening/h6-jobobject.txt
 M evidence/hardening/h8-sentinel.txt         M shell/BUILD-MANIFEST.txt
?? docs/SOVEREIGN_LIVE_ANSWERS_20260830.json
?? docs/SOVEREIGN_LIVE_STATE_20260830.md
?? evidence/live-census-20260830/
?? modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json   <- the ONE expected file (N-29 / F-6)
```

The modified files are stamped `utc: 2026-08-30T03:38:31Z`–`03:38:34Z` — between ENTRY 016
(03:33:22Z) and ENTRY 017 (03:39:55Z). They are the **validator's own live-census session**, not
product runtime writes and not this seat's work.

**Handling.** The 13 tracked files were preserved byte-for-byte into `D/boot-preserved/`, with
`D/BOOT-dirt-sha256.txt` and `D/BOOT-tracked-dirt.patch`, and then restored to sealed bytes from an
**explicit closed list** (`D/BOOT-restore-closed-list.txt`) — never from `git diff --name-only`,
which is the exact S-5 mistake FIXUP-01 recorded against itself. The tracked tree is now clean at
the seal.

The 4 untracked entries were **left exactly where they were written** (E-2 — nothing outside the
write set is deleted). Every porcelain assertion in this run is stated modulo those 4 named paths.

**A note bearing on OD-28 / N-19, reported not fixed.** The restored `shell/BUILD-MANIFEST.txt` is
the stale sealed copy (**67 entries**). The validator's session had regenerated it to **80 entries**.
That regeneration is independent evidence that N-19's staleness is real and reproducible — the
manifest at the seal omits 13 entries and carries changed hashes for others. N-19 is the reviewer's
lane and explicitly out of scope (§9); it is recorded here only because the bytes passed through my
hands.

---

## D-1 · THE LOCAL LIBRARY · VERIFIED — and the reason it looked empty is not what was thought

Enumerated **from bytes** by `D/tools/enum_local_library.py`: manifests and their config blobs read
directly off disk, no daemon consulted, nothing pulled. The config schema was read from a real blob
before any field was used (S-3) rather than assumed: `model_type` carries the parameter count,
`file_type` the quantization, `model_family` the architecture, and `remote_host`/`remote_model`
appear **only** on Ollama Cloud rows.

**60 models, 1008.8 GB on disk.** The byte enumeration and the daemon's `/api/tags` agree
**exactly — 60/60, zero discrepancy in both directions** (`D/d1-daemon-tags.txt`).

### THE ROOT CAUSE of "no local models anywhere" — supersedes N-28 "Ollama is not running"

`OLLAMA_MODELS` is set at **user scope** to `D:\SOVEREIGN\models\vault`. That directory **did not
exist** before this run; the daemon created it empty on first start. The real library — 984 GB,
60 manifests — lives at `C:\Users\Sslaw\.ollama\models`, which the daemon was configured never to
look at.

Measured in this order (`D/d1-daemon-vault-empty.txt`):

```
daemon /api/version -> {"version":"0.33.2"}     <- healthy
daemon /api/tags    -> {"models":[]}            <- ZERO models
files in the vault  -> 0
manifests in the real store -> 60
```

A *running, healthy* daemon reporting zero models. Restarting it with
`OLLAMA_MODELS=C:\Users\Sslaw\.ollama\models` — **session-scoped; the host's user variable was NOT
modified**, being outside the write set — immediately yields **60 models visible**.

This is a strictly better explanation than "Ollama is down". Following the punch list's N-28 remedy
("Host state. Start it.") would have produced a healthy daemon serving **nothing**, and every
downstream symptom — Debate reaching no models, the picker's empty local group, SOVEREIGN's
`model_service_reachable: false` — would have persisted with no further clue and a green daemon.
Recorded for the operator as **N-30**; the remedy is one line of host configuration and is the
operator's environment, not a repo file.

### Every model over the 8B ceiling, NAMED — the directive's D-1 requirement

52 of 60 are excluded. The full per-row table with reasons is `D/d1-library.txt`.

**Over the ceiling by parameter count (47):**
mistral-medium-3.5:latest 127.7B · gpt-oss:120b 116.8B · llama4:scout 108.6B ·
qwen3-coder-next:latest 79.7B · dolphin-llama3:70b 71B · llama3.3:70b 70.6B · deepseek-r1:70b 70.6B ·
qwen3.5:35b-a3b 36.0B · qwen3.6:35b 36.0B · ornith-1.5:35b 35.5B · ornith:35b 34.7B ·
laguna-xs-2.1:latest 33.4B · nemotron-3.5-lightning:latest 32.9B · deepseek-r1:32b 32.8B ·
qwen2.5-coder:32b 32.8B · qwen3:32b 32.8B · hf.co/bartowski/THUDM_GLM-4-32B-0414-GGUF:Q4_K_M 32.6B ·
hf.co/unsloth/GLM-4-32B-0414-GGUF:UD-Q4_K_XL 32.6B · gemma4:31b 31.3B · qwen3-coder:30b 30.5B ·
qwen3:30b-a3b 30.5B · glm-4.7-flash:latest 29.9B · granite4.2:30b 29.3B · granite4.1:30b 28.9B ·
muse-glimmer:30b 27.9B · qwen3.6:27b 27.8B · medgemma:27b 27.4B · qwen3.8:27b 27.3B ·
qwen3.8:latest 27.3B · orcarouter/Qwen3.8-27B-Uncensored:latest 27.3B · qwen3.6-fable-iq2:latest
26.9B · gemma4:26b 25.8B · devstral-small-2:latest 24.0B · mistral-small3.2:latest 24.0B ·
GFalcon-UA/dolphin3-r1-mistral:latest 23.6B · Jotschi/dolphin-mistral-24b:24b-instruct-q5_0 23.6B ·
ikiru/Dolphin-Mistral-24B-Venice-Edition:latest 23.6B · magistral:latest 23.6B · codestral:latest
22.2B · gpt-oss:20b 20.9B · deepseek-r1:14b 14.8B · qwen2.5:14b-instruct 14.8B · qwen3:14b 14.8B ·
phi4:14b 14.7B · gemma4:12b 11.9B · ornith-1.5:9b 9.0B · ornith:9b 9.0B.

**Excluded as Ollama Cloud — remote, therefore not local operation (2):**
`deepseek-v4-pro:cloud` (1.65T, `remote_host https://ollama.com`) and `glm-5.2:cloud` (756B). These
route **off this machine** and fall under the frontier authorization the operator has DENIED
(OD-31). They carry **0 bytes on disk**, which is itself the proof they are not local. A ceiling
implemented on parameter count alone would have excluded them for the wrong reason; they are
excluded for the right one.

**Excluded as embedding-only — cannot answer a typed message (3):**
`bge-m3:latest` 566.70M · `mxbai-embed-large:latest` 334M · `nomic-embed-text:latest` 137M. All are
comfortably under the ceiling, but a `bert`/`nomic-bert` model emits vectors, not chat. Offering one
would violate S-19's "no model offered that cannot run" clause. Worth noting: FIXUP-01's hermetic
run reported "3 local options", and one of those three was `nomic-embed-text` — an embedding model
counted as a selectable option.

### ADMITTED under the ceiling (8)

| model | true params | on disk | VRAM footprint |
|---|---|---|---|
| granite4.2:8b | 8.8B | 5.0 GB | 5100 MB |
| deepseek-r1:8b | 8.2B | 4.9 GB | 4983 MB |
| deepseek-r1:latest | 8.2B | 4.9 GB | 4983 MB |
| **qwen3:8b** | **8.2B** | **4.9 GB** | **4983 MB** |
| dolphin3:8b | 8.0B | 4.6 GB | 4692 MB |
| dolphin-llama3:8b | 8B | 4.3 GB | 4445 MB |
| dolphin-llama3:latest | 8B | 4.3 GB | 4445 MB |
| sam860/dolphin3-llama3.2:3b | 3.2B | 2.0 GB | 2035 MB |

### A SPEC TENSION THE OPERATOR SHOULD SEE (E-3 class — stated, not blocking)

ENTRY 017 says both *"no model above eight billion parameters"* **and** *"Use the eight billion
parameters one so we can run through tests."* The model the operator names — `qwen3:8b`, which is
also the model punch-list §5 S-8 pins for Debate — has a **true parameter count of 8.2B**. Read as a
strict arithmetic bound on the true count, the ceiling would exclude the exact model the operator
directed be used, and the run would have no model to prove the system with.

**Resolution taken, stated rather than hidden.** The ceiling is implemented as the **8B nameplate
class** — admitted when the vendor nameplate is 8B or smaller — and **every admitted model's true
parameter count is displayed**, so nothing is concealed. Mechanically this is `true_params < 9.0B`.
On this library the two readings are **identical across all 60 models**: nameplate ≤ 8B and true
< 9.0B admit exactly the same 8. The choice therefore changes no behaviour here, and is recorded
only because it would matter on a library containing a 9B-nameplate model.

The operator can overrule to a strict 8.0B bound. That would drop `granite4.2:8b`, `deepseek-r1:8b`,
`deepseek-r1:latest` and `qwen3:8b`, leaving `dolphin3:8b`, the two `dolphin-llama3` tags and the
3.2B model — and would remove the model the operator named. Flagged for the operator's call; the
constant is one line (`CEILING_PARAMS`).

---

## D-2 · THE VRAM ADMISSION GATE · VERIFIED — it establishes, and its budget is wrong

**It establishes.** With the daemon up (`D/d2-residency-standin.json`):

```
established = True     vram_budget_mb = 12288     running_vram_mb = 0
budget_source = "STAND-IN 12288MB constant - NOT a GPU query and NOT derived from what is
                 resident; set SOW_VRAM_BUDGET_MB to this host's real VRAM"
```

FIXUP-01 measured `established: false` **only** because the daemon was unreachable — that is the
`_NO_BUDGET` shape at `enumerate_pane_picker.py:82`, whose `budget_source` is literally
*"ollama daemon unreachable — no planner"*. Daemon reachability is the whole of that condition.
**This gate was never what blocked local panes**, and the directive's framing of it as "what decides
whether local panes run at all" is correct in mechanism but was, on this host, downstream of D-1's
root cause.

**But the budget overstates this host by ~50%.** Measured GPU (`D/d2-gpu.txt`):

```
NVIDIA GeForce RTX 5060 Ti — 8151 MiB total, 5605 MiB free
```

`STAND_IN_VRAM_BUDGET_MB = 12 * 1024` (`enumerate_pane_picker.py:76`) asserts **12288 MB** on a card
that physically has **8151 MiB**. Measured consequence: **22 of 60** models "fit" the stand-in
budget; only **16** fit a truthful 8192 (`D/d2-residency-8192.json`). That 4137 MB gap is exactly the
operator's stated complaint — *"a 12 GB model previously straddled it at a 51/49 CPU/GPU split."*

The constant is scrupulously honest about being a stand-in in its own `budget_source` string, and
`_operator_vram_budget_mb()` reads `SOW_VRAM_BUDGET_MB` to replace it. Nothing on this host sets it.

---

## D-3 · THE CONDUCTOR'S MODEL PATH · SCOPED — five blockers, all inside the write set

Per ENTRY 018 this measurement scopes the work; it never decides whether the work happens.

**What already exists, and is reusable.** The architecture is genuinely provider-neutral and was
written anticipating precisely this. `control_plane/conductor/selection.py:18-19` names *"a successor
conductor on a different backend (codex, **a local Ollama model**)"*. `ConductorModelRegistration`
and `ConductorDescriptor` both already carry a `locality` field. `registry.py`'s own header reads
*"The conductor is a role. Provider differences stop at the command-adapter boundary."* And the
**worker** path already has a complete, working local implementation:
`adapters/local/ollama_session.build_interactive_ollama_command` producing `ollama run <tag>`,
admitted by `worker_pane_spawn._authorize_local` through the ResidencyPlanner with **no subscription
and no credential**.

There is also `control_plane/canonical_registry.py`, which already merges
`_seed_conductor()` + `_live_ollama()` + `_seed_roster()` into one dump — a registry that already
knows local models exist.

**What stands between the Conductor and a local Ollama session — precisely:**

1. **`control_plane/conductor/registry.py` — `CONDUCTOR_MODEL_REGISTRY` holds exactly three
   registrations, all frontier**: `openai_codex_cli/gpt-5.6-sol`, `claude_code/fable-5`,
   `claude_code/opus-4.8`. `resolve_conductor_descriptor` fails closed on anything else, so no local
   model is ever a "registered conductor-capable combination". **The selection feed can carry a
   local model structurally; the registry simply never offers one.**

2. **`adapters/conductor/provider_commands.py` — `_COMMANDS` maps exactly two adapter ids**
   (`CLAUDE_CODE_ADAPTER`, `CODEX_ADAPTER`). `commands_for("ollama_local")` raises
   `ConductorProviderUnavailable`. **This is the module that hardcodes the provider**, in the
   directive's words.

3. **`node_runtime/supervisor/conductor_pane_spawn.spawn_conductor_pane` routes every conductor
   through the frontier gate chain** — `profile_loader.assert_startup([cap], live_auth)` →
   `live_auth.assert_provider_live(provider)` → R8 §6 live-terms confirmation — and it **requires a
   `subscription_ref`**, refusing an "uncounted terminal" under I-X3. A local model has no
   subscription and needs no live authorization. Contrast `worker_pane_spawn:448`, which branches on
   `adapter_id == OLLAMA_LOCAL_ADAPTER` **before** any frontier gate and never touches `live_auth`
   at all. The conductor path has no such branch.

4. **`registry.load_runtime_conductor_descriptor` defaults to `claude_code/fable-5`** whenever
   `live_operation.json` is absent — which is its permanent state under OD-31. Measured:
   `selection_source: "recorded_default_selection"`, `locality: "frontier"`. So the Conductor's
   resolved selection is frontier even with no configuration present at all.

5. **`adapters/conductor/adapter.ConductorAdapter.capability()` hardcodes**
   `adapter="conductor_fable5"`, `locality="frontier"`, `requires_network=True`,
   `local_runtime=False`, `offline_profile_eligible=False`, `subscription_backed=True`.

**None of these is a physical dependency (E-5) and none lies outside `release-worktree`.** F-3 is
therefore not parkable on any ground the exception classes recognise — which is what ENTRY 018 ruled
in advance.

---

## D-4 · IS H-10 REDUNDANT TODAY? · MEASURED — yes for frontier, and the measurement found worse

Measured by `D/tools/d4probe.py`, exercising the **real** gates with `live_operation.json` absent.
No CLI was launched by the probe.

```
live_operation.json exists: False
load_live_authorization() -> authorized=False, providers=[], terminals_per_subscription=0,
    reason "no live-operation config at ...\config\live_operation.json (enforcement-by-absence)"

assert_provider_live('claude_code')      -> REFUSED  LiveAuthorizationError
assert_provider_live('openai_codex_cli') -> REFUSED  LiveAuthorizationError
assert_provider_live('ollama_local')     -> REFUSED  LiveAuthorizationError    <-- !!

load_runtime_conductor_descriptor() -> claude_code / fable-5 / locality frontier /
                                       subscription_ref 'sub-claude_code' /
                                       selection_source 'recorded_default_selection'
```

**H-10 is redundant for frontier — CONFIRMED by measurement, not by reasoning.** The governed
conductor spawn's gates (1) and (2) both refuse `claude_code` before any process is created, and the
resolved descriptor *is* `claude_code/fable-5`. Nothing billable can spawn while the file is absent.
ENTRY 017's prediction reproduces exactly. The `SOW_CONDUCTOR_AUTOLAUNCH=0` pin in `sow.json`
`env_set` is therefore belt-and-braces over a gate that already fails closed.

**NEW DEFECT — the S-20 violation in its purest form.** The live gate refuses `ollama_local` **too**.
Local operation costs nothing and requires no authorization, yet `assert_provider_live` treats it
identically to a billed frontier provider, and the refusal it emits talks about *spend
authorization*. The worker path escapes this only because it **branches around** the gate before
reaching it; nothing in the design makes the gate itself local-aware.

This is precisely what S-20 forbids — *"local is never gated behind a frontier switch"* — and it is
why F-3 cannot be completed by adding registry entries alone. Scoped into F-3.

---

## D-5 · SELECTION TO PROMPT · VERIFIED end to end — and the ceiling does not exist

**The path, traced through the source and then exercised:**

```
picker/source.js  --(py -3.12 bounded subprocess)-->  tools/live/enumerate_pane_picker.py --emit-picker
  -> detect.ollama_models()  (GET /api/tags)  -> build_pane_picker -> _local_options
  -> renderer/renderer.js:936 providerGroupHtml
  -> operator selects  -> picker/worker-spawn.js createWorkerPaneLauncher
  -> tools/live/emit_worker_launch.py --emit-worker-launch   (selection on stdin)
  -> worker_pane_spawn.authorize_worker_pane -> _authorize_local -> ResidencyPlanner
  -> build_interactive_ollama_command  -> argv ["<ollama.exe>", "run", "<tag>"]
  -> shell asserts authorized===true, scrubs credential env by NAME, spawnSession -> ConPTY pane
```

**It works today.** A real ticket for `qwen3:8b` (`D/d5-ticket-qwen3-8b.json`), emitted with
`live_operation.json` absent:

```json
"authorized": true,  "node_state": "launch_authorized",
"launch":  {"argv": ["C:\\...\\Ollama\\ollama.EXE", "run", "qwen3:8b"],
            "interactive": true, "one_shot": false, "env_credential_scrubbed": true},
"chrome":  {"locality": "local", "subscription": null, "residency": "loading"},
"identity":{"node_id": "worker-pane-2", "subscription_ref": null}
```

`py -3.12` resolves on this host (3.12.10), so the shell's subprocess contract holds.

**Three defects measured on that same path** (`D/d5-selection-to-prompt.txt`):

| model | offered by the picker | ticket verdict |
|---|---|---|
| `qwen3:8b` (8.2B) | yes | **AUTHORIZED** |
| `phi4:14b` (14.7B) | yes | **AUTHORIZED** ← breaks the operator's ceiling |
| `deepseek-r1:70b` (70.6B) | yes, `available: true` | refused at gate `vram_admission` |
| `sam860/dolphin3-llama3.2:3b` (3.2B) | **never offered** | dropped silently |

1. **No ceiling exists anywhere.** `_local_options` offers every enumerated model; nothing filters on
   parameter count. `phi4:14b` — 14.7B, 8633 MB footprint — is **authorized to spawn** against the
   12288 MB stand-in on an 8151 MiB card. That is exactly the 12 GB straddle ENTRY 017 exists to
   prevent, and punch-list §5 S-8 already names `phi4:14b` as the hazard to keep out of Debate.

2. **Offered-then-refused (S-17 / S-19).** `deepseek-r1:70b` renders `available: true` and is then
   refused at spawn by the VRAM gate. A rendered control that is not a performable action — the
   defect class the punch list says no gate in this program can catch.

3. **Silent absence (S-19).** `detect.ollama_models()` returns **53** where `/api/tags` returns
   **60**. The 7 lost are exactly the namespaced tags: `sam860/…`, `hf.co/bartowski/…`,
   `hf.co/unsloth/…`, `ikiru/…`, `orcarouter/…`, `GFalcon-UA/…`, `Jotschi/…`. The cause is
   `MODEL_SLUG_RE` (`adapters/frontier/provider_cli_common.py:907`),
   `^[A-Za-z0-9][A-Za-z0-9._:@\-]{1,80}$`, which admits no `/`.

   That regex is a **prose defence**: it exists so that parsing a frontier CLI's *text* output cannot
   turn a stray `Traceback` or a help paragraph into a model id — its own comment says so, and W-44
   records exactly that failure for `agy`. It is here being applied to Ollama's **structured JSON**,
   where `name` is authoritative and `/` is a legitimate namespace separator. One of the seven,
   `sam860/dolphin3-llama3.2:3b`, is an admissible **3.2B** model the operator can never see, and
   nothing anywhere reports that it was dropped.

---

## D-6 · BASELINES · VERIFIED

| measurement | value |
|---|---|
| `git archive HEAD` file count | **3503** |
| archive-bound package boundary gate | **PASS** — scanned 3503, violations 0, credential hits 0, quarantined-historical 1982, allowlisted 5, exit 0 |

FIXUP-01 measured **3497** at the *parent* seal `50b47326`; the +6 is FIXUP-01's own eight commits.

Invocation reproduced per FIXUP-01's S-3 note: `--root` points at an **extracted** `git archive HEAD`
tree and `--allowlist` is the copy **inside that tree**. Passing the worktree's allowlist while
scanning the extract produces a false FAIL on the archive's own `fixture_allowlist.json`.

### An interpreter finding that matters for every suite count in this program

Run under this host's default `python` (**3.14.6**), the shell suite reports **188 passed, 2 failed**.
Both failures are `ModuleNotFoundError: No module named 'jsonschema'`, raised while importing
`modules/sow/node_runtime/context/loaders.py` through the conductor registry — an **environment**
fault, not a product defect and not caused by any change in this run (the tree was at sealed bytes).

Interpreter inventory taken before drawing any conclusion:

| interpreter | version | pytest | jsonschema |
|---|---|---|---|
| `python` (default) | 3.14.6 | yes | **no** |
| `modules/debate/.venv` | 3.14.6 | no | no |
| `modules/sovereign/.venv` | 3.12.10 | no | yes |
| **`py -3.12`** | **3.12.10** | **yes** | **yes** |

`py -3.12` is the interpreter the shell itself uses for every Python subprocess
(`picker/source.js`, `conductor/source.js`), so it is the correct baseline interpreter. Suite counts
are recorded in `D/d6-suites.txt`.

This is the **E-1 dependency defect** (punch list §6) showing up as a suite result: SOW declares only
unpinned ranges and has **no `.venv` at all**, so which interpreter a seat happens to use changes the
measured suite outcome. Reported, not fixed — inventing a lock is forbidden to a builder and the
operator's decision on where authoritative locks come from is still open.

---

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
