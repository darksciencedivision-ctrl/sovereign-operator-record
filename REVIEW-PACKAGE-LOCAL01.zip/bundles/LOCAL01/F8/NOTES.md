# LOCAL-01 · F-8 — the last release-blocking gate goes GREEN (OD-27)

Commit `e191081881e900621f6de6b466b1990a6d6c818a`. Directive §4 F-8.

`provenance_cross_hash_check` has been RED since CONVERGE-01 and is named in the punch list as
the last gate blocking release.

```
BEFORE                                        AFTER
debate       UNKNOWN                          debate       OK
distillery   UNKNOWN                          distillery   OK
sovereign    OK                               sovereign    OK
sow          UNKNOWN                          sow          OK
tokencenter  PENDING                          tokencenter  OK
FAIL, exit 1                                  PASS, exit 0
```

Invoked as the tool requires — `--root . --registry tools/release/module_source_registry.json`.
A prior validator run hit a missing `--registry` and never re-ran it correctly; that is why the
invocation is recorded here verbatim.

## Three causes wearing one verdict

**DISTILLERY** was the pure OD-27 case: its record already reproduced itself and only the
**registry** was stale — exactly what ENTRY 016 described when it ruled the refresh mechanical.

**DEBATE and SOW** were stale for a reason *this run created*. F-4 changed debate's bytes and
F-1/F-3/F-6 changed sow's, so a content digest taken before those commits could not describe
them. Their records are regenerated against the current tree by the tool that owns that method.

**TOKENCENTER could not be "filled from its own record"** — its record had no hash to fill from.
It is a copy-time record carrying a source path, an exclusion list and two copy-only edits, and
never had a `source_sha256` at all. So the record **gains** one, computed by the SAME
`content_digest()` its peers use, over its 20 git-tracked files, excluding the record itself.
Every other field is left exactly as the copy left it, and a `source_sha256_basis` string states
precisely how the number was derived and why it appeared now.

**SOVEREIGN is deliberately untouched.** Its registered identity is the upstream **archive** hash
(`source_kind: "archive"`), not a digest of the worktree, so it neither drifted with this run's
F-5 edits nor needed refreshing.

## Reproducibility re-checked after writing

This is the property CLOSEOUT-01 Phase Z established, and the thing that makes the refresh a
mechanical act rather than a declaration. All four digests re-derive identically from the bytes
on disk:

```
debate       record=b89c773051eafa2a...  re-derived=b89c773051eafa2a...  REPRODUCES
sow          record=7a8e81aaab917068...  re-derived=7a8e81aaab917068...  REPRODUCES
distillery   record=1efcf7c0d1caf96e...  re-derived=1efcf7c0d1caf96e...  REPRODUCES
tokencenter  record=ad81cc050f69c423...  re-derived=ad81cc050f69c423...  REPRODUCES
```

The self-reference exclusion is what makes that stable: writing a hash into a record cannot
change that record's hash.

## Not promoted

The gate being green removes the blocker OD-27 named. It is **not** a promotion and not a PASS:
promotion to 1.0 is the operator's alone (§9), and the 19 CANDIDATE gates plus Gate-5/5b remain
the reviewer's lane.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
