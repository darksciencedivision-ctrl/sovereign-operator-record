# LOCAL-01 · F-7 — the producer CUTS all eight (OD-33)

Commit `c9821f563d5c1caebf42a1c462f563c3f1ac7e92`. Directive §4 F-7.

## The defect

`build_release.ps1` `git archive`d the **two** composite archives, then took
`Get-ChildItem *.zip` from the output directory as authoritative. The six per-module archives
were never cut by it. At the FIXUP-01 seal all six on disk were stale leftovers from the
**parent** commit, and without the builder's manual re-cut they would have shipped pre-fix
bytes under correct-looking hashes — worse than the defect X-1 fixed, because every number
would have agreed with every other number and been wrong.

The validator recorded this as its own: X-1 step 2 said "extend the producer so it
**enumerates** every release artifact", and *enumerate* was the wrong verb.

## The fix, both halves

1. **It cuts all eight** from the named commit.
2. **The artifact list is the CUT LIST**, not a directory listing — and a `.zip` in the output
   directory this run did not cut is now a hard **error**. Previously it would have been adopted
   and published as this release's bytes, which is exactly how six stale archives came to be
   recorded. Each target is also removed before its archive is written, so a stale file cannot
   survive a build even transiently.

## The eight, enumerated explicitly

Never by glob — `module_source_registry.json`'s own policy states that rule for this program.
Each per-module archive derives its version from a **named file and field**, so the name is
reproducible from the commit rather than remembered from the last build. The sources genuinely
differ per module, and that is recorded rather than smoothed over:

| artifact | pathspec | version from |
|---|---|---|
| `sovereign-workspace-<v>-source.zip` | (whole tree) | `VERSION.json` |
| `sovereign-workspace-<v>-install.zip` | (whole tree, `--prefix`) | `VERSION.json` |
| `debate-<v>-src.zip` | `modules/debate` | its `INSTALL-PROVENANCE.json` `.version` |
| `distillery-<v>-src.zip` | `modules/distillery` | its `INSTALL-PROVENANCE.json` `.version` |
| `shell-<v>-src.zip` | `shell` | workspace `VERSION.json` |
| `sovereign-<rev>-src.zip` | `modules/sovereign` | its `.source_revision` |
| `sow-<v>-src.zip` | `modules/sow` | its `INSTALL-PROVENANCE.json` `.version` |
| `tokencenter-record-dated-<date>-src.zip` | `modules/tokencenter` | the DATE of its provenance record — it carries no version of its own, and that is what the sealed name has always encoded |

## Verified before committing

Cutting all eight from the **parent seal** with these derived names reproduces the eight sealed
artifacts **byte-identically**, zip comment included:

```
sovereign-workspace-1.0.0-rc.1-source.zip                   IDENTICAL
sovereign-workspace-1.0.0-rc.1-install.zip                  IDENTICAL
debate-v1.2.1-hardening-src.zip                             IDENTICAL
distillery-1.1.0rc3-src.zip                                 IDENTICAL
shell-1.0.0-rc.1-src.zip                                    IDENTICAL
sovereign-SOVEREIGN_ENTERPRISE_PRODUCTION_...-src.zip       IDENTICAL
sow-0.1.0-src.zip                                           IDENTICAL
tokencenter-record-dated-2026-08-26-src.zip                 IDENTICAL
```

So this is a correction of the **producer**, not a change of product bytes. The script parses
clean, and refuses a dirty tree by construction, so it is exercised end to end in Phase H against
the new seal.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
