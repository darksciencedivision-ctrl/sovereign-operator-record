# LOCAL-01 · F-5 — SOVEREIGN on local models

Commit `f0fe9dd48fd683a64d16b76a052d3be12fe370be`. Directive §4 F-5.

## What was wrong

SOVEREIGN starts (FIXUP-01 F-4 fixed its readiness probe), and it started **configured to run
models this host cannot serve**. Three of its four chat roles named models above the ceiling:

| role | was | params | now | params |
|---|---|---|---|---|
| PRIMARY_REASONER | `qwen3:14b` | 14.8B | `qwen3:8b` | 8.2B |
| ADVERSARIAL_CHALLENGER | `ornith:9b` | 9.0B | `granite4.2:8b` | 8.8B |
| CRITIC | `qwen3:8b` | 8.2B | `dolphin3:8b` | 8.0B |
| SYNTHESIZER | `qwen3.8:27b` | 27.3B | `deepseek-r1:8b` | 8.2B |
| EMBEDDING_MODEL | `nomic-embed-text:latest` | 137M | unchanged | — |

Four families now sit across four roles, so the adversarial and critic seats argue in a different
voice from the reasoner instead of being the same weights twice. The embedding role keeps an
embedder, which is what that role wants.

**The defaults were the worse half.** ENTRY 017 forbids a model above the ceiling being "used,
selected, **defaulted to** or pulled". `semantic_deep.py` defaulted `member_models` and
`synthesizer_model` to `qwen2.5:14b-instruct` and `qwen3:14b`. The manifest path always passes
explicit values, so those defaults were unreachable in practice — which is exactly why they could
sit there being wrong. `synthesis/model_hierarchy.json` carried **eight more** over-ceiling
assignments across both wings, the reconciliation pair and four CLU roles.

## The coupled change (S-4), and the gate that enforced it

`tools/release/check_model_consistency.py` pins `SYSTEM_MANIFEST.json` against README_PRODUCTION's
five bullets and against `model_hierarchy.json`'s `king_synthesizer` and `cross_channel.critique`.
It **passed before and passes after**, which is what made this land as one coupled change rather
than four drifting ones.

Sites moved together: `SYSTEM_MANIFEST.json` · `README_PRODUCTION.md` (5 bullets) ·
`synthesis/model_hierarchy.json` (2 gate-checked + 8 unchecked) · `sovereign_product/semantic_deep.py`
(defaults, think-control key, minimum key).

Note the gate only checks **2** of `model_hierarchy.json`'s 16 model entries. The other six
over-ceiling ones were unwatched — found by grepping the module for every over-ceiling tag, not by
any gate.

## The model list is now ceiling-aware, from the same enumeration

`_probe_ollama` reads parameter sizes out of the **same `/api/tags` payload** it already parses for
names — never a second probe, which is the directive's "sourced from the same enumeration rather
than a second one". Every `model_states` row gains `parameter_size`, `within_ceiling` and a
`ceiling_reason`, and the probe returns a `local_model_ceiling` block naming ENTRY 017 and
separating two different facts: `over_ceiling_models` (the library) and `configured_over_ceiling`
(a **role** pointed at a model that cannot run — the state that actually matters).

Measured live:

```
reachable: True   probe_status: online
model_states: 60          over the ceiling, still LISTED: 49
configured roles: deepseek-r1:8b 8.2B · dolphin3:8b 8.0B · granite4.2:8b 8.8B
                  nomic-embed-text:latest 137M · qwen3:8b 8.2B   — all within_ceiling True
configured_over_ceiling: []
```

An over-ceiling model is **marked, not hidden** (S-19). Sample of what the operator reads:

> *"GFalcon-UA/dolphin3-r1-mistral:latest has 23.6B parameters, above the operator's 8B ceiling
> (ENTRY 017) — this host's GPU carries 8 GB of VRAM. Installed and kept, but not assignable to a
> SOVEREIGN role in this build."*

## An independent confirmation of FIXUP-01's N-27

`/v1/health` answered in **0.068 s**, against the **1.25 s** FIXUP-01 measured at the parent seal.
The difference is `model_service_reachable: true` — the daemon is up and serving. That is exactly
FIXUP-01's root cause for N-27 ("it waits on the local Ollama daemon, which is down on this host"),
confirmed from the other direction: with the daemon up, the endpoint is 18× faster and the 0.5 s
probe timeout that could never be satisfied would now be satisfied comfortably.

## Reported, NOT fixed

**N-37 · the operator's ceiling now lives in three files.** `modules/sow/adapters/local/model_ceiling.py`,
`modules/debate/app.py` and `modules/sovereign/sovereign_product/introspection.py` each implement
it. They are duplicated rather than imported because these are three separate products with
separate install provenance and separate virtualenvs, and a cross-module import would tie one
product's startup to another's package tree — a worse coupling than the duplication. Each site
names the others in its comment, and all three must move together (S-4).

The structural fix is a shared operator-policy artifact all three read, which is an architecture
decision about how policy reaches three products, not a builder's call. Recorded for the operator.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
