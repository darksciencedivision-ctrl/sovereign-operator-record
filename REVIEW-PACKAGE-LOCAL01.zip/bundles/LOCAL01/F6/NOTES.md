# LOCAL-01 · F-6 — SOW receipts leave the tracked tree (OD-34 / N-29)

Commit `029177ee1e225548a364a703609de5c45033dc88`. Directive §4 F-6.

## The defect

`modules/sow/docs/evidence/receipts/` is **git-tracked**, and `sow.json` both declared it in
`runtime_writes` and pointed its `receipt_file` readiness probe at a file inside it. So merely
**using** the product wrote into the release candidate. This run's BOOT found a dirty tree, as
FIXUP-01's did, and every future builder BOOT would have.

## The fix

Runtime receipts write to the gitignored `.runtime/` lane — the N-16 remedy OD-34 rules for. That
lane is gitignored (`.gitignore:64`) **and** a rejected runtime lane in `package_boundary_gate.py`,
so a receipt can neither be committed nor packaged.

**Relocating `receipt-path.js` alone would have fixed 9 files and left 19 broken.** Those 19 built
the path from a literal and never called it. All 19 now route through `receiptPath`, so the
destination is decided in one place. Each receipt keeps its exact file name; only the directory
moves.

That also completes the repair `receipt-path.js` was created for: a re-run used to **overwrite a
closed gate's receipt in place** (MEDIUM-2). It now writes beside the run instead, and the committed
gate receipts stay tracked and untouched — history, as OD-34 requires.

`sow.json`'s `readiness.path` and `runtime_writes` moved with it (S-4), or the shell would probe a
file the product no longer writes.

## Verified live

Re-ran the F-2 driver end to end after the change:

```
ok: true   answered: true   argv: [...\ollama.EXE, run, qwen3:8b]   responseChars: 1676
receipt now at   modules/sow/.runtime/receipts/SHELL-LIVE-READY.json
git check-ignore  .gitignore:64:.runtime/   <- git confirms it is ignored
```

The product still reaches a live local prompt, and the receipt is out of the tracked tree.

## THE GENERAL ASSERTION, and the seven more instances it found

No gate in this program could catch N-29. The boundary gate rejects runtime state that reaches an
**archive**; the manifest check verifies hashes. Nothing asserted the simpler property: *a product's
own declaration of "I write here at runtime" must not name a place git is watching.* The declaration
and the tracked-ness were each fine alone and only wrong together — the shape a cross-cutting
assertion catches and a per-file one never does.

`tools/release/test_runtime_writes_are_gitignored.py` asserts it for **every** adapter, asking git
itself via `check-ignore` rather than a copy of the ignore rules (so it holds on a clean clone where
no runtime file exists yet).

Written generally, it immediately found **seven more instances in four other adapters** — recorded
as **N-38**. N-29 is the fifth through eleventh instance of the N-16 class, not one:

```
debate.json      ${root}/config.json        <- Debate PERSISTS a seat-model change back into
                                              its own tracked config: using the model dropdown
                                              edits the release candidate
distillery.json  ${root}/logs
llamacpp.json    ${root}/logs
sovereign.json   ${root}/runtime  ${root}/published  ${root}/library/queues  ${root}/logs
```

They are **pinned, not fixed** — each is another module's runtime contract and outside this run's
authorized item set (S-9). The list may only **shrink**: a new offender fails the test, a fixed one
must be removed from the list (a second test catches a stale entry), and SOW may never be added to
it.

## A residue, recorded

`modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json` remains on disk **untracked**, written by
runs before this fix. It is left where the product wrote it (E-2) and the product no longer writes
there. It is one of the four untracked paths every porcelain assertion in this run is stated modulo.

## U186

`main.js` changed, so the mutation baseline was re-pinned and the harness re-run: **ALL MUTATIONS
CAUGHT**, `main.js` restored byte-identical, UTF-8 BOM preserved.

## Suites

SOW desktop **1104 / 1104**. `tools/release` **87 passed** (84 baseline + 5 new; the 2 failures are
`RELEASE-MANIFEST.json` staleness, which Phase H regenerates by design).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
