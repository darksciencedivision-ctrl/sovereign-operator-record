# LOCAL-01 · F-1 — Local models selectable and runnable, 8B ceiling enforced

Scoped by D-1 / D-2 / D-5. Directive §4 F-1.

## What was wrong, measured live at the parent seal `8d9f5d24` before any change

| model | picker said | `emit_worker_launch` said |
|---|---|---|
| `qwen3:8b` (8.2B) | offered, `available: true` | **AUTHORIZED** |
| `phi4:14b` (14.7B) | offered, `available: true` | **AUTHORIZED** ← breaks the operator's ceiling |
| `deepseek-r1:70b` (70.6B) | offered, `available: true` | refused at `vram_admission` |
| `sam860/dolphin3-llama3.2:3b` (3.2B) | **never offered** | — |

Three distinct defects:

1. **No ceiling existed anywhere.** A 14.7B model with an 8633 MB footprint was authorized to spawn
   on a card with 8151 MiB. That is the exact straddle ENTRY 017 was written to prevent, and
   punch-list §5 S-8 already names `phi4:14b` as the hazard.
2. **Offered-then-refused (S-17/S-19).** `deepseek-r1:70b` rendered as a launchable control and was
   refused only after the operator chose it.
3. **Silent absence (S-19).** `detect.ollama_models()` returned 53 of the host's 60 models. The 7
   lost were every namespaced tag, and one of them is a 3.2B model well inside the ceiling.

## What changed

**`adapters/local/model_ceiling.py` — NEW. The single ceiling authority (S-20).**
Pure functions over `/api/tags` records; contacts no daemon, loads nothing. Four exclusion classes,
tested in this order, each producing the sentence the operator reads:

1. **not local weights** — Ollama Cloud rows are ~300-byte pointers that execute on ollama.com.
   Refused for *leaving the host*, not for size, so a small remote model is still refused.
   Detected by on-disk footprint rather than a `:cloud` tag spelling — the footprint is the fact.
2. **cannot hold a conversation** — embedding models, detected from the daemon's OWN `capabilities`
   list rather than a family-name guess. All three on this host are far under the ceiling.
3. **parameter count unreadable** — fail closed; a model that cannot be shown to be small is not
   assumed small.
4. **over the ceiling** — with the daemon's own parameter string quoted verbatim.

The Conductor (F-3), Debate (F-4) and SOVEREIGN (F-5) all classify through this one module, so
S-20's "every local model within the ceiling" means the same set in every surface.

**`adapters/detect.py` — `ollama_model_records()` added; `ollama_models()` re-based on it.**
`MODEL_SLUG_RE` was dropping every namespaced tag. That regex is a **prose defence** — it exists so
that parsing a frontier CLI's free TEXT output cannot turn a stray `Traceback` into a model id (its
own comment says so; W-44/W-45 record that exact failure for `agy`). It was being applied to
Ollama's **structured JSON**, where `name` is a declared field and `/` is a legitimate namespace
separator. `OLLAMA_TAG_RE` replaces it on this path and still refuses whitespace, shell
metacharacters and a leading `-` — the property that actually matters, since the tag becomes an
argv element in `ollama run <tag>`.

**`control_plane/nodes/pane_picker.py` — `_local_options` / `build_pane_picker` take
`ceiling_reasons`.** An over-ceiling model is rendered **greyed with its reason, never removed**
(ENTRY 017: "excluded from selection with a stated reason, not silently hidden"). Resolution order
is stated in the code: a host-wide VRAM refusal greys everything and wins, because telling the
operator a model is too large implies a smaller one would work when none would.

**`tools/live/enumerate_pane_picker.py` — one enumeration, classified once**, and `meta` now carries
a `local_ceiling` block (nameplate, authority, admitted list, excluded map) so the operator report
and the host test can both read the decision instead of re-deriving it.

## Coupled values moved together (S-4) — every site

| site | what moved |
|---|---|
| `adapters/detect.py` | `ollama_model_records()` added; `ollama_models()` now derives from it; `OLLAMA_TAG_RE` replaces `MODEL_SLUG_RE` on the local path |
| `adapters/local/model_ceiling.py` | new — the ceiling constant and the four exclusion classes |
| `control_plane/nodes/pane_picker.py` | `_local_options(..., ceiling_reasons)`, `build_pane_picker(..., local_ceiling_reasons)` |
| `tools/live/enumerate_pane_picker.py` | classifies once, passes `local_ceiling_reasons`, records `meta["local_ceiling"]` |
| `tests/unit/test_local_admission_visibility.py` | fixtures moved onto the new `ollama_model_records` seam via `_records()`; **no assertion changed** |
| `tests/unit/test_pane_picker_host.py` | the `available is True` assertion replaced by the stronger ceiling-agreement assertion (see below) |

## The one assertion that changed, and the authority for it (S-14)

`test_pane_picker_host.py::test_local_options_mirror_the_live_ollama_enumeration_exactly` asserted
`o["available"] is True` for **every** enumerated local model. That is precisely the defective
contract F-1 exists to correct — it is the assertion that made "offer a 70B model as launchable"
pass. Authority: directive §4 F-1 ("the picker offers only models at or under 8B; anything larger is
excluded with a stated reason") and ENTRY 017.

It was replaced with a **stronger** assertion, not a weaker one: every enumerated model must be
classified, admitted and excluded must be disjoint, `available` must agree exactly with the ceiling
verdict, and no greyed option may lack a reason. The no-fabrication/no-omission label-set assertion
above it is untouched. No test was deleted, skipped, xfailed or loosened (S-6).

## Fail-before / pass-after (S-8), measured live on this host

```
BEFORE (parent seal)                     AFTER (this commit)
qwen3:8b          AUTHORIZED             qwen3:8b          AUTHORIZED
phi4:14b          AUTHORIZED             phi4:14b          refused@selection_guard
deepseek-r1:70b   refused@vram_admission deepseek-r1:70b   refused@selection_guard
sam860/…3.2:3b    NOT OFFERED            sam860/…3.2:3b    AUTHORIZED
```

The two refusals now happen at `selection_guard` — i.e. the authorization refuses for the *same
reason the operator was shown*, rather than the picker offering and a later gate refusing. The
display and the gate agree, which is what S-17 asks for.

Picker as the operator now sees it: **60 local options shown, 8 offered, 52 greyed, 0 greyed
without a stated reason.** Frontier rows remain visible and honestly unavailable (S-20).

## Suites

`tests/unit/test_local_model_ceiling.py` (new, 44 cases) and
`tests/unit/test_pane_picker_local_ceiling.py` (new, 18 cases) — 62 passed.
Affected existing suites re-run green: `test_pane_picker.py`, `test_pane_picker_host.py`,
`test_op12_pane_picker.py`, `test_detect_ollama_hardening.py`, `test_local_admission_visibility.py`,
`test_local_group_reason.py` — 132 passed together with the new ones.

## Reported, NOT fixed

**N-31 · the stand-in VRAM budget overstates this host by ~4 GB.**
`STAND_IN_VRAM_BUDGET_MB = 12 * 1024` (`enumerate_pane_picker.py:76`) claims 12288 MB where
`nvidia-smi` measures **8151 MiB total, 5605 MiB free** on the RTX 5060 Ti. Nothing on this host
sets `SOW_VRAM_BUDGET_MB`, which is the supported override. The ceiling makes this moot for
selection today — the largest admitted model is 5100 MB, inside both budgets — so it is reported
rather than changed: hardcoding 8192 would bake a developer-machine value into distributed bytes
(S-16), and querying the GPU is new behaviour outside F-1's scope (S-9). The operator's one-line
remedy is `SOW_VRAM_BUDGET_MB=8192`.

**N-30 · `OLLAMA_MODELS` points at an empty vault.** See `D/DIAGNOSIS.md` D-1. Host environment,
outside the write set.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
