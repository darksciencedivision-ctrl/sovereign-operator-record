# F-1 · regression measurement against the parent seal

Method: a clean `git worktree` detached at the parent seal `8d9f5d24…`, run with the same
interpreter (`py -3.12`) and the same command, so the two runs differ only in F-1's commit.

```
BASELINE  (worktree @ 8d9f5d2415599eeb0b71dc85a25a36469b41641e)
  py -3.12 -m pytest tests/unit -q -p no:cacheprovider
  -> 12 failed, 2379 passed, 2 skipped  in 88.57s

AFTER F-1 (d379d77382be45d91119c7ad4b56a32ea72d1c1e)
  py -3.12 -m pytest tests/unit -q -p no:cacheprovider
  -> 12 failed, 2441 passed, 2 skipped  in 81.10s
```

**Zero regressions.** The failing set is byte-identical between the two runs — the same 12 node ids,
listed below. `2441 − 2379 = 62`, exactly the two new test files F-1 adds
(`test_local_model_ceiling.py` 44 + `test_pane_picker_local_ceiling.py` 18).

## The 12 failures are PRE-EXISTING at the seal (N-32) — reported, not fixed

```
tests/unit/test_freeze_manifest_check.py::test_the_freeze_check_passes_on_this_tree
tests/unit/test_mcp_registration_provenance.py::test_the_codex_registration_pins_the_mcp_server_working_directory
tests/unit/test_node_schema_amendment.py::test_the_frozen_schema_set_is_still_exactly_twelve_files
tests/unit/test_node_schema_amendment.py::test_the_manifest_is_reproducible_on_this_host
tests/unit/test_node_schema_amendment.py::test_an_unattributed_amendment_file_is_itself_drift
tests/unit/test_node_schema_amendment.py::test_an_amendment_citing_a_ruling_nobody_recorded_is_unattributed
tests/unit/test_node_schema_amendment.py::test_check_verifies_the_two_integrity_hashes_it_publishes
tests/unit/test_schemas.py::test_frozen_schema_count_is_exactly_twelve
tests/unit/test_terminal_suite_coverage.py::test_the_complete_terminal_suite_runs_and_every_test_passes
tests/unit/test_text_integrity.py::test_no_tracked_text_file_carries_a_utf8_BOM
tests/unit/test_threat_model_honesty.py::test_not_implemented_claims_are_enumerated
tests/unit/test_u326_before_after_import_hygiene.py::test_the_evaluation_still_runs_when_invoked_from_a_foreign_cwd
```

They are outside this run's authorized item set (S-9: park, do not improvise) and are recorded for
the operator and the reviewer. Two are worth naming because they bear on rules this program
enforces elsewhere:

**N-32a · two tracked files carry a UTF-8 BOM, at the seal.**
```
tracked files carry a UTF-8 BOM (PowerShell 5.1 `Set-Content -Encoding UTF8` writes one):
    apps/desktop/main.js
    apps/desktop/preload.js
```
This is the product's own guard failing on the product's own bytes. It is a **UTF-8** BOM
(`EF BB BF`), not the **UTF-16** `FF FE` that standing rule S-2 asserts against — S-2 remains
satisfied — but the repo's own `test_text_integrity` forbids it because "a BOM is CONTENT, not a
line ending: it changes the blob and every hash taken over it."

Consequence for this run, and the reason it is recorded here rather than in the report alone:
**F-2/F-3 must edit `apps/desktop/main.js`, and those edits must preserve the existing BOM
byte-for-byte.** Stripping it would fix a failing test as a side effect of unrelated work, change
the file's blob hash, and move a value no item in this directive authorizes moving. Every edit to
that file in this run is checked for BOM preservation afterwards.

**N-32b · `pytest.ini`'s recorded contract no longer matches the tree.** `pytest.ini` states a
"Measured contract … 2382 passed / 0 failed / 1 skipped" for the whole suite. `tests/unit` alone
now yields 2379 passed / 12 failed / 2 skipped at the seal. The recorded contract is stale and the
suite is not green, which matters because S-12 ("a red suite is not an authorization") has been
applied in this program on the assumption that this suite was green.

## A note on `tests/integration`, and why the whole-suite figure is not reported

The full `pytest tests` run was started and reached only ~14% after ~25 minutes against a recorded
whole-suite baseline of 638s, so it was stopped rather than left to run for hours. `tests/unit`
alone completes in ~81s, so the cost is entirely in `tests/integration`, whose `host_coupled`
members probe the live host — and the Ollama daemon is UP in this run for the first time, with 60
models to enumerate, where every previous run in this program had it down.

That is a measurement about the suite's cost under a running daemon, not a claim about its result.
**No whole-suite figure is asserted for this run.** The five suites the directive names as
baselines (§3 D-6) are all measured and recorded in `D/d6-suites.txt`; this SOW pytest suite is not
one of them.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
