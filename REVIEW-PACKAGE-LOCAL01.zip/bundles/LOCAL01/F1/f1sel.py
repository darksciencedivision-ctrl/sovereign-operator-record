import json,sys
sys.path.insert(0, r"D:\producttion software 2\release-worktree\modules\sow")
from adapters import detect
from adapters.local.model_ceiling import classify_local_models, reasons_by_name
from control_plane.nodes.pane_picker import _local_options
v=classify_local_models(detect.ollama_model_records())
opts=_local_options([x.name for x in v], None, None, reasons_by_name(v))
want=sys.argv[1]
m=next((o for o in opts if o["label"]==want), None)
if m is None: print(f"# {want} not enumerated", file=sys.stderr); sys.exit(3)
print(json.dumps({"option":m,"role":"reasoning","mode":"attended"}))
