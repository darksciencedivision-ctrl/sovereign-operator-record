"""F-1 verification: the ceiling as the operator will see it. No frontier probe, no network."""
import sys
sys.path.insert(0, r"D:\producttion software 2\release-worktree\modules\sow")
from adapters import detect
from adapters.local.model_ceiling import classify_local_models, reasons_by_name, CEILING_NAMEPLATE_B
from control_plane.nodes.pane_picker import build_pane_picker
from control_plane.profiles.live_authorization import load_live_authorization

recs = detect.ollama_model_records()
v = classify_local_models(recs)
reasons = reasons_by_name(v)
names = [x.name for x in v]

picker = build_pane_picker(
    load_live_authorization(),
    ollama_models=names,
    residency=None,
    local_ceiling_reasons=reasons,
)
local = next(g for g in picker["providers"] if g["provider"] == "ollama_local")
offered = [o for o in local["options"] if o["available"]]
greyed = [o for o in local["options"] if not o["available"]]

print(f"ceiling            : {CEILING_NAMEPLATE_B}B nameplate (ENTRY 017)")
print(f"local options shown: {len(local['options'])}   offered: {len(offered)}   greyed-with-reason: {len(greyed)}")
print(f"counts             : {picker['counts']}")
print(f"\nOFFERED (selectable, under the ceiling):")
for o in offered:
    print(f"   {o['label']}")
missing = [o for o in greyed if not o["unavailable_reason"]]
print(f"\ngreyed options carrying NO reason (must be 0): {len(missing)}")
print(f"\nsample refusals the operator reads:")
for tag in ("phi4:14b", "deepseek-r1:70b", "deepseek-v4-pro:cloud", "nomic-embed-text:latest"):
    o = next((x for x in local["options"] if x["label"] == tag), None)
    if o:
        print(f"  - {tag}\n      available={o['available']}\n      {o['unavailable_reason']}")
