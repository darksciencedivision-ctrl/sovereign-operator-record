# PARKED · D-1-a — Token Center's `frame-ancestors` is hardcoded to port 5180
## Exception class E-3 (spec contradiction) / S-9 (park, do not improvise)
## Found by: builder claude-code (opus-5) during FIXUP-01 Phase D, 2026-08-30

## The finding

`modules/tokencenter/piggybank.py:36`:

```python
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; "
       "connect-src 'self'; img-src 'self' data:; "
       "frame-ancestors http://127.0.0.1:5180; object-src 'none'; base-uri 'none'")
```

The framing origin is a fixed string. The shell's port is a `--port` argument
(`shell/src/server.py`, `main()`), which merely *defaults* to 5180.

## Why it matters

Run the shell on any other port and the embed is refused for real. Measured, shell on 5191 with
Token Center READY:

```
Framing 'http://127.0.0.1:8765/' violates the following Content Security Policy directive:
"frame-ancestors http://127.0.0.1:5180". The request has been blocked.
```

The panel then goes blank with no fallback, because the shell's fallback triggers on "the module
is not running" and the module *is* running. That is a genuinely reachable instance of the exact
state OP-4 forbids — a silent empty frame — and it is the state N-21 was reported as. N-21 itself
does not reproduce on the default port (Phase D, D-1), but this path does produce the same
symptom on any other port.

## Why it is parked, not fixed

1. **Not in the authorized item set.** ENTRY 014 lists N-21, N-21b, the missing fallback, N-22 and
   OBS-2, N-23, N-27, N-25, and F-6. This is none of them.
2. **F-1 explicitly warns against casual CSP changes**: "The shell's `frame-src` and Token
   Center's `frame-ancestors` are already correct and must not be widened... do not 'fix' it by
   loosening CSP." Any change here is a change to a security policy and deserves a ruling.
3. **The fix is genuinely coupled and cross-module (S-4).** The shell cannot simply inject its own
   origin: `adapter.py:261` restricts `${...}` substitution to `${root}` and raises
   `AdapterError` on any other variable, so the substituter, the adapter schema, `tokencenter.json`,
   `piggybank.py` and the tests for all four move together.
4. **I proved a client-side workaround does not work.** See `F/F-1/NOTES.md`: a browser cannot
   distinguish a CSP-refused frame from a loaded one, because Chromium serves the refusal from an
   opaque origin and both throw identically on the location read. There is no honest client-side
   detection, so the fix has to be the origin agreement itself.

## What would unblock it, and what it would cost

An operator ruling authorizing a scoped CSP change, then one coupled commit:

- `shell/src/adapter.py` — admit one further substitution variable, `${shell_origin}`, resolved
  from the port the shell is actually listening on. Must be resolved *after* argument parsing, so
  `load_all_adapters()` needs the port passed in (`server.py:main` already knows it before it
  loads adapters).
- `shell/modules/tokencenter.json` — `launch.env_set.TOKEN_CENTER_FRAME_ANCESTOR = "${shell_origin}"`.
- `modules/tokencenter/piggybank.py` — read that variable, **validate it against
  `^http://127\.0\.0\.1:\d{1,5}$`**, and fall back to the current literal when unset. Validation is
  the load-bearing part: it keeps the policy at exactly one loopback origin, so this narrows
  nothing and widens nothing. A malformed or multi-origin value must fail closed to the default.
- `shell/src/server.py` — pass the port through.
- Tests: the substituter's new variable and its rejection of anything else; Token Center's
  validator, including that a non-loopback or multi-origin value is refused; and an end-to-end
  render on a non-default port, which is the assertion whose absence allowed this.

Estimated: five files plus tests, roughly 60–90 lines, one commit.

## Interim state

Left as found. The defect is recorded in `D/DIAGNOSIS.md` (D-1-a) and in the release-notes draft
as a known limitation: **the Token Center embed is only functional when the shell runs on its
default port 5180.** The operator runs on 5180, so the shipped configuration works; the limitation
is real but not currently reached.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
