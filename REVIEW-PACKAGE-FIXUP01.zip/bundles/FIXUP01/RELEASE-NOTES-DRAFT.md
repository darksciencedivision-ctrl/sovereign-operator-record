# RELEASE NOTES — DRAFT · Sovereign Workspace 1.0.0-rc.1
## Seal `8d9f5d2415599eeb0b71dc85a25a36469b41641e` (FIXUP-01, parent `50b47326`)
## CANDIDATE. Not a release. No gate is submitted and no PASS is asserted.

Every limitation carried by the parent candidate is carried forward below, unchanged, plus what
FIXUP-01 found. Nothing here is closed by having been fixed in code alone: the items marked
**LV-n** are awaiting confirmation against the running product by the validator seat, per S-17.

---

## Fixed in this release candidate

| id | what changed | confirmation |
|---|---|---|
| **N-23** | The shell's **Open** control now follows what a module can actually do, not merely whether it is running. A module declaring `open.kind: none` no longer presents an enabled Open button. | LV-3 |
| **N-23 (capability)** | New `open.kind: focus_window`. **The Multi-Model Terminal's Open button now raises the running desktop window**, so the operator no longer has to find it on the taskbar. | LV-4 |
| **N-27** | **SOVEREIGN now starts from the shell.** Its readiness probe was giving each request a 0.5 s socket timeout against an endpoint that answers in ~1.25 s, so it could never succeed at any configured timeout. Every module using an HTTP readiness probe was exposed to the same fault. | LV-5 |
| **N-22 / OBS-2** | **llama.cpp is visible again.** The shell renders every module it loads, not a hardcoded list of five. An optional runtime that is not installed now reads as *present and unavailable* and names the path the operator must supply. | LV-2 |
| **N-21b** | The Token Center frame's `sandbox` attribute is resolved with a recorded rationale and pinned by test. | — |
| **N-25 (partial)** | The picker's **Local (Ollama)** provider group now says *why* it is empty — naming the daemon or the runtime — instead of "no options enumerated for this provider". | LV-6 |

## Reported, NOT fixed — findings that did not survive reproduction

- **N-21 — "the Token Center embed never renders" is REFUTED.** Measured on the default port in
  Microsoft Edge with Token Center running, the frame commits to `http://127.0.0.1:8765/`, loads
  its document, stylesheet, script, live API call and image (all HTTP 200, nothing blocked) and
  paints. The original observation was taken through a browser pane rather than a real browser, and
  its own report asked for confirmation in Brave or Edge before the finding was closed. **LV-1**
  asks for that confirmation. The OP-4 fallback panel reported missing also already exists and was
  measured working.
- **N-25 as written — "the Electron picker is frontier-only by construction, no local code path at
  all" is REFUTED.** The local path exists end to end. The report rested on a non-recursive glob
  that could not see `apps/desktop/picker/`.
- **N-22's stated cause is REFUTED.** CLOSEOUT-01's X-4 did not remove llama.cpp from the UI; the
  UI never listed it. The developer-path neutralisation X-4 performed is retained (S-16).

## Known limitations — carried forward, still open

### Operator decisions that gate the product

- **OD-31 — no live model operation.** `modules/sow/config/live_operation.json` is deliberately
  absent, so all 23 frontier options report `live DENIED (fail-closed)`. This is the authorization
  interlock, not a defect. Untouched by this run.
- **OD-32 — the Conductor cannot be typed into from the shell.** The H-10 quota guard forces
  `SOW_CONDUCTOR_AUTOLAUNCH=0`, and the Conductor launches only when that value is not `0`. It is
  dark by design. Untouched by this run.
- **OD-27 — `provenance_cross_hash_check` exits 1.** `module_source_registry.json` is stale for
  debate, distillery and sow. **The candidate must not be promoted while this gate is red.** Note
  that SOW's expected digest has moved with this run's change to
  `modules/sow/control_plane/nodes/pane_picker.py`, so the ruling must be taken against these bytes.
- OD-20, OD-23, OD-28, OD-29, OD-30 remain open, unchanged.

### Engineering limitations

- **E-1 / E-2 — no dependency locks for SOW or Distillery.** SOW carries only unpinned ranges and
  Distillery has no Python lock. Reproducible provisioning is **not achieved**, and SOW's
  `pytest.ini` expected count remains UNVERIFIED. Unchanged; a builder may not invent a lock (S-11).
- **E-3 — no true clean-room install.** Every install proof is a same-host proxy on a machine that
  already has Python, node and Ollama.
- **The Token Center embed only works on the shell's default port 5180.** Token Center's
  `frame-ancestors` is a fixed string naming that origin, while the shell's port is an argument. On
  any other port the panel is refused and goes blank with no fallback. Shipped configuration uses
  5180, so this is not currently reached. Costed at
  `bundles/FIXUP01/PARKED-D-1-a-frame-ancestors-port.md`.
- **SOW writes a readiness receipt into the tracked tree.** Starting SOW creates
  `modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json`, dirtying the release candidate. This
  is N-16 recurring in a lane its fix did not cover. Costed at
  `bundles/FIXUP01/PARKED-N-29-sow-receipt-in-tracked-tree.md`.
- **`build_release.ps1` re-cuts only the two composite archives** and inherits whatever per-module
  ZIPs are already on disk, recording their hashes as authoritative. FIXUP-01 found all six stale
  and re-cut them by hand; the tooling defect remains.
- **`RELEASE-MANIFEST.json` describes the worktree, not the release.** It enumerates two gitignored
  distillery build artifacts and superseded `*.pre-CONVERGE01` records that OD-26 excludes from
  archives, so `release_manifest_check` cannot pass against an extracted archive (12 problems,
  identical at the parent seal). Its specified invocation, `--root .`, passes.
- **Token Center violates its own CSP.** Served standalone it emits 11 `style-src 'self'` inline-style
  violations and one 404. Pre-existing, unrelated to framing.
- **Ollama is not running on this host**, so no local model is offered and Debate reaches no models.
  Host state, not a product defect.
- The 31-hour hang remains an UNREPRODUCED KNOWN OBSERVATION (OD-14).
- Distillery ships as a status-only component (OD-8); Debate Phase-7/8 deferrals stand (OD-9).

### Scope not attempted

**OP-7 model agnosticism** across SOW, Debate and SOVEREIGN is a feature programme, explicitly out
of scope. This run touched only the honesty of the local group's empty state. OP-2 and OP-6 are
likewise untouched.

## Verification status

| suite | measured at the seal |
|---|---|
| SOW desktop | 1104 tests, 1104 pass, 0 fail |
| SOW terminal | 225 tests, 225 pass, 0 fail |
| Token Center | 32 tests, OK |
| shell | 188 tests, OK (166 at the parent, +22 added by this run) |
| tools/release | 84 tests, OK |
| SOW picker units | 59 passed |

| gate | verdict |
|---|---|
| package boundary (archive-bound, sealed bytes) | PASS — 3503 scanned, 0 violations |
| release manifest (`--root .`) | PASS |
| governance BOM | PASS |
| model consistency | PASS |
| innerHTML sink audit | PASS |
| provenance cross-hash | **FAIL — OD-27, blocks promotion** |

Cold-extraction of all 8 release artifacts: 8/8 verified, every zip comment naming the seal.

**No reviewer PASS is asserted anywhere in this document. The 19 CANDIDATE gates and Gate-5/5b have
still not been adjudicated.**
