#!/bin/sh
# S-5: restore the tracked files the SHELL SUITE rewrites as a side effect.
#
# The path list is EXPLICIT and closed. An earlier version of this script restored whatever
# `git diff --name-only` reported, which is wrong in exactly one dangerous way: run between
# editing sources and committing them, it reverts the builder's own work. It did, once
# (FIXUP-01 F-3). Only the suite's own artifacts belong here.
set -e
cd "D:/producttion software 2/release-worktree"
FILES="evidence/gate5/screenshots/shell-grid-rendered.png
evidence/hardening/deps-proof.txt
evidence/hardening/h1-listen.txt
evidence/hardening/h13-assets.txt
evidence/hardening/h14-doclinks.txt
evidence/hardening/h15-distillery-contract.txt
evidence/hardening/h16-contrast.txt
evidence/hardening/h17-dom.txt
evidence/hardening/h3-headers.txt
evidence/hardening/h4-dom.txt
evidence/hardening/h6-jobobject.txt
evidence/hardening/h8-sentinel.txt
shell/BUILD-MANIFEST.txt"

DIRTY=$(git diff --name-only)
echo "--- suite side effects seen dirty ---"
for f in $FILES; do
  case "$DIRTY" in *"$f"*) echo "  dirty: $f"; git checkout -- "$f";; esac
done

echo "--- hash verification against HEAD blobs ---"
BAD=0
for f in $FILES; do
  WANT=$(git rev-parse "HEAD:$f")
  GOT=$(git hash-object "$f")
  if [ "$WANT" = "$GOT" ]; then echo "  OK   $GOT  $f"; else echo "  MISMATCH $f want=$WANT got=$GOT"; BAD=1; fi
done

echo "--- anything still modified is NOT a suite side effect ---"
LEFT=$(git diff --name-only)
if [ -n "$LEFT" ]; then echo "  still modified (builder work, left alone):"; echo "$LEFT" | sed 's/^/    /'; fi
echo "--- porcelain ---"
git status --porcelain
[ "$BAD" = "0" ] && echo "S-5: suite side effects RESTORED AND VERIFIED" || { echo "S-5: FAILED"; exit 1; }
