# PHASE G — deterministic program at final code bytes

Builder seat `claude-code (opus-5)` · bytes under test: `d9c7409` (F-6, the last code commit)
Measured results only. No adjectives, no historical counts.

## Suites

| suite | command | expected | **measured** |
|---|---|---|---|
| SOW desktop | `node --test test/*.test.js` in `modules/sow/apps/desktop` | 1104 | **1104 tests, 1104 pass, 0 fail** |
| SOW terminal | `node --test test/*.test.js` in `modules/sow/terminal` | 225 | **225 tests, 225 pass, 0 fail** |
| Token Center | `py -3.12 -B -m unittest discover -s tests` | 32 | **32 tests, OK** |
| shell | `py -3.12 -B -m unittest discover -s shell/tests` | 166 | **188 tests, OK** |
| tools/release | `py -3.12 -B -m unittest discover -s . -p 'test_*.py'` | 84 | **84 tests, 2 failures** — see below |
| SOW picker units | `py -3.12 -m pytest tests/unit/test_pane_picker.py tests/unit/test_local_admission_visibility.py tests/unit/test_op12_pane_picker.py tests/unit/test_local_group_reason.py` | — | **59 passed** |

### shell 166 → 188: +22, accounted

| file | tests | item |
|---|---|---|
| `test_tokencenter_embed.py` | 2 | F-1 |
| `test_module_visibility.py` | 2 | F-2 |
| `test_open_capability.py` | 10 | F-3 |
| `test_probe_timeouts.py` | 4 | F-4 |
| `test_rendered_control_contract.py` | 4 | F-6 |
| **total** | **+22** | 166 + 22 = **188** |

No test was deleted, skipped, xfailed or loosened (S-6). Two existing assertions changed, both
under the authority of the item that required them and both recorded in their commit:
`test_render.py`'s H-17 card list (five cards → the curated five plus every further loaded adapter,
F-2/N-22) and its H-13 POST-route census (`+/api/open`, F-3/S-4).

### tools/release — 2 failures, both the manifests-last ordering, not a defect

```
FAIL test_release_manifest_check.ManifestValidatorTests.test_real_manifest_passes
FAIL test_release_manifest_check.HandledSectionsStillValidateTests
       .test_real_manifest_still_passes_after_hardening
  batch_files: hash mismatch at shell/src/probe.py
  batch_files: hash mismatch at shell/static/app.js
  batch_files: hash mismatch at shell/tests/test_render.py
```

Exactly the three tracked files in `RELEASE-MANIFEST.json`'s `batch_files` that this run changed.
The manifest is regenerated in **Phase H step 2**, after the last code commit and before the seal —
that ordering is the A-1 fix CLOSEOUT-01 made and it means the manifest is *necessarily* stale
during Phase G. Both tests are re-run against the sealed bytes in Phase H step 7 and must be green
there. Cause named, attributable to this loop, and resolved inside it (S-12).

No other failure in any suite.

### S-5 — suite side effects restored and hash-verified

The shell suite rewrites 13 tracked paths (12 under `evidence/`, plus `shell/BUILD-MANIFEST.txt`).
After every run they were restored from HEAD and hash-verified by comparing `git hash-object`
against `git rev-parse HEAD:<path>` — all 13 VERIFIED, porcelain carrying no ` M ` row afterwards.
Script: `G/s5-restore.sh`.

That script was itself repaired mid-run. Its first version selected its targets from
`git diff --name-only` — everything modified — and, run between editing the F-3 sources and staging
them, it reverted the builder's own work; commit `73f6a39` consequently landed the F-3 test file
without its implementation, and `1d5986f` supplies it. The script now carries an explicit closed
list of the 13 suite-written paths and prints anything else still modified as builder work it
deliberately left alone. Recorded rather than tidied away, because the failure mode is exactly the
kind a successor could repeat.

## Gates

| gate | invocation | verdict |
|---|---|---|
| package boundary | `--root <extracted git archive HEAD> --allowlist <that tree>/tools/release/fixture_allowlist.json` | **PASS** — 3503 scanned, 0 violations, 0 credential hits, 1982 quarantined-historical, 5 allowlisted, exit 0 |
| release manifest | `--root .` | **FAIL (3 problems)** — the three `batch_files` hashes above; regenerated in H, re-run in H step 7 |
| governance BOM | `--root .` | **PASS** |
| model consistency | `--root .` | **PASS** |
| innerHTML sink audit | `--file modules/sow/apps/desktop/renderer/renderer.js --ledger tools/release/innerhtml_audit.json` | **PASS** — 39 templates, 112 interpolations (ESCAPED 73, ESCAPED-BY-CONSTRUCTION 17, STATIC 9, COMPOSITE 9, GUARANTEED 3, GUARANTEED-INTEGER 1) |
| provenance cross-hash | `--root . --registry tools/release/module_source_registry.json` | **FAIL — expected RED, OD-27, not mine to fix** |

The innerHTML target was taken from the ledger's own `scope_file` field, as the directive instructs.

### provenance cross-hash — RED, and still not mine (S-12, §9)

```
debate       UNKNOWN  hash matches no registered identity (expected 1087827b…)
distillery   UNKNOWN  hash matches no registered identity (expected 8448d68a…)
sovereign    OK       hash equals the module's own registered source hash
sow          UNKNOWN  hash matches no registered identity (expected 3ef75c33…)
tokencenter  PENDING  registry entry carries no source_sha256 yet
```

Same three modules, same shape, as at the parent seal. `module_source_registry.json` is stale and
its refresh is **OD-27**, which the directive explicitly tells this seat to expect red and leave
alone. One honest difference to record: SOW's *expected* digest is not the value it had at the
seal, because F-5 changed `modules/sow/control_plane/nodes/pane_picker.py`. The gate was already
red for SOW before this run and remains red; the number the operator will register when OD-27 is
ruled has moved, and the ruling must therefore be taken against these bytes, not against the
parent's.

## Archive delta — 3497 → 3503, +6, accounted item by item

Added, all of them test files, no product bytes:

| path | item |
|---|---|
| `shell/tests/test_tokencenter_embed.py` | F-1 |
| `shell/tests/test_module_visibility.py` | F-2 |
| `shell/tests/test_open_capability.py` | F-3 |
| `shell/tests/test_probe_timeouts.py` | F-4 |
| `shell/tests/test_rendered_control_contract.py` | F-6 |
| `modules/sow/tests/unit/test_local_group_reason.py` | F-5 |

Removed: **none**.

Modified tracked files vs the parent seal (10, excluding the 6 added):
`modules/sow/control_plane/nodes/pane_picker.py` (F-5) ·
`shell/modules/schema.json`, `shell/modules/sow.json`, `shell/src/adapter.py`,
`shell/src/server.py`, `shell/src/supervisor.py` (F-3) ·
`shell/src/states.py` (F-2, F-3) · `shell/src/probe.py` (F-4) ·
`shell/static/app.js` (F-1, F-2, F-3) · `shell/tests/test_render.py` (F-2, F-3).

## S-2 encoding assertion

No tracked file written by this run begins `FF FE`, `FE FF` or `EF BB BF`. Every file was written
UTF-8 without BOM and LF-only, matching the bytes they replaced. Asserted after each commit.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
