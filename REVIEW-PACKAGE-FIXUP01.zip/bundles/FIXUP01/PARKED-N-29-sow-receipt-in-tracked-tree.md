# PARKED · N-29 — SOW writes its readiness receipt into the TRACKED tree
## Exception class E-3 (spec contradiction) / S-9 (park, do not improvise)
## Found by: builder claude-code (opus-5) at FIXUP-01 BOOT, 2026-08-30

## The blocker

BOOT step 2 requires `git status --porcelain` empty. It was not:

```
?? modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json
```

Product-generated, untracked, `bootedAt 2026-08-30T00:44:25.471Z` — written by SOW during the
T-2 attended session. Byte-preserved at `bundles/FIXUP01/D/BOOT-untracked-SHELL-LIVE-READY.json`.

## Why it happens

`shell/modules/sow.json`:

```json
"readiness": { "kind": "receipt_file",
               "path": "${root}/docs/evidence/receipts/SHELL-LIVE-READY.json",
               "timeout_s": 90, "poll_ms": 1000 }
```

`${root}/docs/evidence/receipts/` is a **tracked** directory holding 26 tracked sibling receipts.
SOW writes its live-ready receipt there on every launch, so every start of SOW from the shell
dirties the release candidate.

This is N-16 recurring in a second lane. CONVERGE-01 commit `65bd58f` fixed N-16 by moving the
*shell's* startup-test evidence to the gitignored `.runtime/` lane. SOW's own readiness receipt was
never in scope for that fix and still lands in tracked space.

Confirmed reproducible: starting SOW through the shell during Phase D re-created the file.

## Consequence

Normal product use BOOT-fails every future builder run, exactly as ENTRY 007 recorded for the
earlier instance. Any seat that "cleans" it is deleting product evidence outside its write set.

## Why it is parked and not fixed here

FIXUP-01's authorized item set is N-21, N-21b, N-22/OBS-2, N-23, N-27, N-25 and F-6 (ENTRY 014).
N-29 is none of them. S-9 forbids substituting a different solution for a blocked one, and the
directive's §9 does not list this path. Fixing it means editing `sow.json`'s readiness contract
and/or `.gitignore` — a coupled change (S-4) to a module's launch contract with no ruling behind it.

## What would unblock it

An operator ruling, or an item in a follow-on batch, choosing one of:

1. **Relocate** the receipt to the gitignored `.runtime/` lane and repoint `sow.json`'s
   `readiness.path`. Coupled sites: `shell/modules/sow.json`, whatever writes the receipt inside
   `modules/sow/apps/desktop/`, and any test pinning the path. Cleanest; matches the N-16 precedent.
2. **Ignore the single path** in `.gitignore`. One line, but it leaves product runtime state inside
   a tracked evidence directory, which is the shape N-16 was raised against.
3. **Accept and document** — every builder BOOT then begins by re-deriving that this specific
   untracked file is expected. Not recommended: it trains seats to wave past a dirty tree, which is
   the failure ENTRY 007 was written about.

Recommendation: option 1, in a follow-on batch, together with a package-boundary-gate assertion
that no `runtime-session-state` path is reachable under `modules/*/docs/evidence/`.

## Handling in this run

The file was left exactly where the product wrote it. Nothing was deleted (E-2). Every porcelain
assertion in FIXUP-01 is stated modulo this one named artifact, and every commit stages explicit
paths only — never `git add -A` — so it can never be captured into a commit.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
