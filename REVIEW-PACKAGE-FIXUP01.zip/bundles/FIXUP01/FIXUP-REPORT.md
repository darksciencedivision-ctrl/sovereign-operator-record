# FIXUP-01 — BUILDER REPORT
## Seat `claude-code (opus-5)` · directive `CLAUDE-FIXUP-01-DIRECTIVE-20260830.md` `4ef3dcd8…` · ENTRY 014
## Parent seal `50b47326f91c5abab8b6d5250d59b1dba96a4d46` → **seal `8d9f5d2415599eeb0b71dc85a25a36469b41641e`**

---

## 1 · The headline

The directive's premise was that five defects reached the operator through green suites and that
the acceptance bar is therefore behaviour, not a passing test. Phase D applied that bar to the
findings themselves, from bytes and from the running product, and **four of the six did not survive
reproduction as written**:

- **N-21 (HIGH) — refuted.** The Token Center frame navigates and paints. The OP-4 fallback the
  directive says does not exist, exists, and was measured working.
- **N-25 (HIGH) — refuted as written.** The picker is not frontier-only; a complete local path
  exists. One small, real gap survived and was fixed.
- **N-22's stated cause — refuted.** CLOSEOUT-01's X-4 is exonerated; the UI never listed llamacpp.
- **N-23's state table — wrong**, though the defect is real and was reproduced in the state the
  operator actually hit.

Two were verified and fixed, one of them root-caused for the first time:

- **N-23** — reproduced live and fixed in both halves; neither is parked.
- **N-27** — cause measured, not theorised: the readiness prober gave each request a 0.5 s timeout
  against an endpoint that answers in 1.25 s.

Per §3, refuted findings are reported and **not** fixed.

---

## 2 · Commit chain

| commit | item |
|---|---|
| `c655021` | F-1 · resolve N-21b, guard the Token Center panel against the blank state |
| `7c56b43` | F-2 · render every module the shell loads; an absent optional runtime says so |
| `73f6a39` | F-3 · Open follows capability, third `open.kind` (test file only — see §7) |
| `1d5986f` | F-3 · completing `73f6a39`: the source changes that commit should have carried |
| `8b31258` | F-4 · stop deriving the readiness request timeout from the poll interval |
| `497114a` | F-5 · the local provider group says why it is empty |
| `d9c7409` | F-6 · compare the rendered page with what the shell says about itself |
| `8d9f5d2` | **H · regenerate provenance, identity and release manifest (SEAL)** |

Seat identity set before the first commit; no existing commit was rewritten (S-10).

---

## 3 · Phase D — diagnosis, six checks

Full record with commands and output: `D/DIAGNOSIS.md`.

| check | item | verdict | the measurement that decided it |
|---|---|---|---|
| D-1 | N-21 Token Center frame | **REFUTED** | Reading `contentWindow.location.href` throws a **cross-origin** SecurityError — positive proof the frame navigated; an `about:blank` frame is same-origin and reads back cleanly. Child frame committed to `http://127.0.0.1:8765/`; document, stylesheet, script, `/api/summary?days=14` and image all 200; `netFailed` empty. Screenshot `D/d1-live-5180.png` shows the panel painted. |
| D-1b | N-21b inert sandbox | **VERIFIED** | Console warning present on every run. |
| D-2 | N-22 llamacpp absent | **PARTIAL** | Symptom real (5 cards, string absent from the page). Cause refuted: live startup loads **six** with clean stderr; `bundles/CLOSEOUT01/Y/installed-shell.log`, written *after* X-4, prints the same six; `git log --all -S"llamacpp" -- shell/src shell/static` returns **no commits at all**. |
| D-3 | N-23 Open control | **VERIFIED** | With everything STOPPED every Open is disabled, SOW's included — the validator's table cannot occur. Started SOW: READY in 6 s, Open **ENABLED**, `url: ""`, `can_open: true`. |
| D-4 | N-27 SOVEREIGN readiness | **VERIFIED + ROOT-CAUSED** | `/v1/health` answers **200 in ~1.25 s** five times running; `urlopen(timeout=0.5)` fails at ~0.53 s three times running. `probe.py:32` used `min(5, poll_ms/1000)`. |
| D-5 | N-25 local models | **REFUTED as stated** | The evidence glob `apps/desktop/*.js` is non-recursive; the picker lives in `apps/desktop/picker/`. Live: five provider rows including `ollama_local`. Hermetic, with no `live_operation.json`: `counts.local = 3`. |
| D-6 | baseline | **VERIFIED** | 3497 archive files · boundary gate PASS (0 violations) · `tools/release` 84 OK — identical to the parent seal. |

---

## 4 · Phase F — what was built

| item | outcome |
|---|---|
| **F-1** Token Center frame renders | **REFUTED, not fixed.** Reported with a live demonstration. |
| **F-1** fallback when Token Center is down | **Already present**, measured working. What was missing was any assertion that it appears — now a behavioural test. |
| **F-1b** sandbox resolved | **KEPT** with both tokens and a recorded rationale: the pair still denies forms, popups, top-level navigation, downloads, modals and pointer-lock; the "escape" the console warns about needs the frame to be same-origin with its embedder, which it is not. A test pins that premise. |
| **F-2** llamacpp visible and honestly unavailable | **Done.** The UI renders every module the backend loads. The card reads `Stopped — Runtime not installed: C:/sovereign-workspace/optional-runtimes/llama.cpp/current/llama-server.exe`; Start/Restart/Test disabled, Logs reachable. |
| **F-2** OBS-2 skip visible to a human | **Done** — it is that state line on that card. |
| **F-3** Open honest | **Done.** `can_open()` follows capability; the client uses the server's answer instead of recomputing. |
| **F-3** Open capable | **Done, not parked.** `open.kind: focus_window` + `POST /api/open`, resolving the module's Job Object to its full pid set and raising the window. |
| **F-4** SOVEREIGN readiness | **Done.** Per-request timeout decoupled from `poll_ms`. Product defect, not an environment finding. |
| **F-5** local models in the picker | **Scoped to the measured gap.** Enumeration and display already existed; the local group's empty-state reason is now actionable. |
| **F-5** honest degradation | **Done**, distinguishing "daemon down" from "daemon up, nothing pulled". |
| **F-6** regression tests | **Done**, and verified by injecting each original defect. |

### The S-18 question, answered

The directive told me to watch for local model selection being gated behind `live_operation.json`
and to park if it were. **It is not.** A run with no live-operation config still enumerated three
local options carrying a local-specific reason; the absent file greys the 23 frontier options and
nothing else. No park was required. Neither interlock was created, populated, bypassed, weakened,
stubbed, mocked around or disabled. `sow.json` still sets `SOW_CONDUCTOR_AUTOLAUNCH=0` and
`adapter.py:344` still enforces it.

### Two things I built and then removed or corrected — recorded, because the removal is the point

1. **A client-side embed watchdog (F-1).** I implemented a check that fell back to a status panel
   when the frame had not committed, then measured it against a genuinely CSP-refused frame: it
   reported *"frame committed"*, because Chromium serves the refusal from an opaque origin and the
   location read throws there too. It could not distinguish "loaded" from "refused". Shipping it
   would have been a control that looks like protection and detects nothing — the exact failure
   class this run exists to remove. It was deleted.
2. **A blind spot in F-6's own guard.** The DOM-level capability test passed while N-23 was injected,
   because on a cold shell every module is STOPPED and the defect only appears in READY. Found by
   injection, closed with a state-independent sweep over every shipped adapter.

---

## 5 · Phase G — measured totals

Full record: `G/NOTES.md`.

| suite | expected | **measured** |
|---|---|---|
| SOW desktop `node --test` | 1104 | **1104 pass, 0 fail** |
| SOW terminal `node --test` | 225 | **225 pass, 0 fail** |
| Token Center | 32 | **32, OK** |
| shell | 166 | **188, OK** (+22, itemised in `G/NOTES.md`) |
| `tools/release` | 84 | **84, OK at the seal** (2 failures at `d9c7409`, closed by H — see below) |
| SOW picker units | — | **59 passed** |

No test deleted, skipped, xfailed or loosened (S-6). Two existing assertions changed, each under
the authority of the item requiring it and recorded in its commit: `test_render.py`'s five-card
list (F-2) and its POST-route census (F-3).

| gate | verdict |
|---|---|
| package boundary, archive-bound, sealed bytes | **PASS** — 3503 scanned, 0 violations, 0 credential hits, 1982 quarantined, 5 allowlisted |
| release manifest `--root .` | **PASS (0 problems)** at the seal |
| governance BOM | **PASS** |
| model consistency | **PASS** |
| innerHTML sink audit | **PASS** — 39 templates, 112 interpolations |
| provenance cross-hash | **FAIL — expected RED, OD-27, not mine** |

**Archive delta 3497 → 3503, +6, all test files**, itemised in `G/NOTES.md`. No product file added
or removed.

---

## 6 · Phase H — the seal

Full record: `H/NOTES.md`. Manifests regenerated over tracked bytes only and committed **first**
(`8d9f5d2`); artifacts cut from that commit **afterwards**; artifact hashes live only in the
untracked `release-artifacts/release-build-manifest.json`. 63 path+sha256 pairs, 5 provenance record
hashes, 3 source identities. Zero release-artifact hashes in the tracked manifest. Cold extraction
of all 8 artifacts: **8/8 PASS**, every zip comment naming the seal.

---

## 7 · Deviations and errors in this run, stated plainly

1. **F-3 landed in two commits.** `bundles/FIXUP01/G/s5-restore.sh`, the S-5 helper, chose its
   targets from `git diff --name-only` — everything modified. Run between editing the F-3 sources
   and staging them, it reverted my own work, and `73f6a39` committed the new test file alone; as
   committed, those 10 tests fail. `1d5986f` supplies the implementation. `73f6a39` was **not**
   amended, because S-10 forbids rewriting any existing commit. The script now carries an explicit
   closed list of the 13 suite-written paths.
2. **`tools/release` was red during Phase G** (2 failures) and green at the seal. Cause named at the
   time: the manifests-last ordering guarantees `RELEASE-MANIFEST.json` is stale until H step 2.
3. **The per-module release archives were stale** and would have shipped pre-fix bytes with
   authoritative hashes. Found at H step 4 and re-cut; the underlying tooling defect is reported
   below, not fixed.

---

## 8 · Residual queue — reviewer and operator only

Nothing here is builder-hermetic.

### Operator

| id | item |
|---|---|
| **OD-27** | Refresh `module_source_registry.json`. **Blocks promotion.** SOW's expected digest moved with F-5, so rule against these bytes. |
| **OD-31** | Live model operation — the absent `live_operation.json`. Untouched. |
| **OD-32** | The H-10 quota guard and the dark Conductor. Untouched. |
| OD-20, OD-23, OD-28, OD-29, OD-30 | Unchanged, open. |
| **E-1 / E-2** | SOW and Distillery dependency locks. The largest barrier to an enterprise-production claim. A builder may not invent a lock (S-11). |
| **E-3** | True clean-room install, never performed. |
| **N-29 (new)** | SOW writes its readiness receipt into the tracked tree. Dossier: `PARKED-N-29-sow-receipt-in-tracked-tree.md`. |
| **D-1-a (new)** | Token Center's `frame-ancestors` is pinned to port 5180. Dossier: `PARKED-D-1-a-frame-ancestors-port.md`. |
| **D-1-b (new)** | Token Center violates its own CSP standalone: 11 inline-style violations and one 404. |
| **Release tooling (new)** | `build_release.ps1` cuts only the two composite archives and inherits the six per-module ZIPs, then records their hashes as authoritative. A module changed without a manual re-cut ships stale bytes under a correct-looking hash. |
| **Manifest coverage (new)** | `RELEASE-MANIFEST.json` enumerates two gitignored build artifacts and OD-26-excluded backup records, so `release_manifest_check` cannot pass against an extracted archive (12 problems, identical at the parent seal). |

### Reviewer

- The 19 CANDIDATE gates plus Gate-5/5b — still unadjudicated, all programme.
- All CANDIDATE work from CONVERGE-01, CLOSEOUT-01 and now FIXUP-01.
- OD-23 assertion inventory · OD-28 `shell/BUILD-MANIFEST.txt` staleness.
- The two assertion changes in `test_render.py` made under F-2 and F-3 authority.

---

## 9 · CONSOLIDATED LIVE-VERIFICATION REQUEST

**To the validator seat, which has a browser on this host.** S-17: no item in this run is closed by
a green test. Each row below names exactly what must be observed. Run the shell **on its default
port 5180** — the embed is refused on any other port (D-1-a).

Start: `py -3.12 -m shell.src` from `D:\producttion software 2\release-worktree`, then open
`http://127.0.0.1:5180/` in **Brave or Edge — not the Claude desktop browser pane**, which is where
LV-1's original observation came from.

| id | what to do | what must be observed | if it fails |
|---|---|---|---|
| **LV-1** | Click **Start** on the Token Center card. Wait for Ready. | The panel **paints the Token Center dashboard inside the shell page** — piggy bank, today's processed-token count, the four stat tiles, the 14-day signal band. Compare with `bundles/FIXUP01/D/d1-live-5180.png`. | N-21 is real in your browser and refuted in mine; report the browser and version. |
| **LV-2** | Look at the module list. | **Six cards**, the sixth being **llama.cpp (candidate)**. Its state line reads `Stopped — Runtime not installed: C:/sovereign-workspace/optional-runtimes/llama.cpp/current/llama-server.exe`. Start, Restart and Run Startup Test are **disabled**; Logs is enabled. | N-22 not closed. |
| **LV-3** | With every module stopped, check each card's **Open**. Then hover llama.cpp's. | Every Open **disabled**. llama.cpp's tooltip reads *"This module declares no open action."*; the others read *"Open becomes available when the module is running."* | N-23 honest half not closed. |
| **LV-4** | Start **Multi-Model Terminal (SOW)**. When Ready, click somewhere else so the SOW window loses focus, then click **Open** on its card. | The **SOW desktop window comes to the front without touching the taskbar**. The status line reports either "window raised" or "window restored and brought to front (foreground focus refused by Windows)". Both are honest outcomes; note which you see. | N-23 capable half not closed. |
| **LV-5** | Click **Start** on the **SOVEREIGN** card. | It reaches **Ready** in roughly 5–10 s. It must **not** end at `FAILED: HEALTH_CHECK_FAILED: readiness probe not satisfied`. | N-27 not closed. |
| **LV-6** | Open SOW's model picker with **Ollama not running**. | A **Local (Ollama)** provider group is present, and its reason names Ollama — *"no local pane can be authorized: … ollama daemon unreachable — no planner"* — not "no options enumerated for this provider". | N-25 residue not closed. |
| **LV-7** | *(operator, optional)* Start Ollama, then reopen the picker. | The **Local (Ollama)** group lists the host's local models. This is the one leg I could only prove hermetically. | Report the counts. |
| **LV-8** | Stop every module and close the shell. | No orphaned `electron.exe`, `python.exe` or module process survives; ports 5175, 8700, 8765 and 5180 are free. `git status --porcelain` in the worktree shows **only** `?? modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json` — the parked N-29 artifact. Any other row is a new finding. | Report. |

**LV-1 is the one that matters most.** It is the only row where my measurement and the recorded
finding disagree, and I am asking to be checked rather than believed.

---

## 10 · Convergence checklist (§7)

```
[x] D diagnosis report, six checks, each VERIFIED/REFUTED/PARTIAL   D/DIAGNOSIS.md
[x] F-1 Token Center frame renders            REFUTED and reported (§3); live demo + screenshot
[x] F-1 fallback panel when Token Center down  already present; measured, now guarded by test
[x] F-1b sandbox attribute resolved with rationale   KEPT, rationale in-source, pinned by test
[x] F-2 llamacpp visible and honestly unavailable    6 cards; runtime path named; Start disabled
[x] F-2 OBS-2 skip signal visible to a human         the state line on the llamacpp card
[x] F-3 Open control honest                          can_open follows capability; client uses it
[x] F-3 Open control capable (third open.kind)       focus_window + POST /api/open; NOT parked
[x] F-4 SOVEREIGN readiness fixed                    probe.py timeout decoupled from poll_ms
[x] F-5 local models enumerated in the picker        already present; refuted as written, proven
[x] F-5 honest degradation when Ollama is down       local group reason now names Ollama
[x] F-6 regression tests for all three classes       + verified by injecting each defect
[x] G suites measured                                1104 / 225 / 32 / 188 / 84 / 59
[x] G gates measured (provenance cross-hash RED)     5 PASS, 1 RED per OD-27
[x] G archive delta accounted                        3497 -> 3503, +6, all test files
[x] H manifests regenerated, tracked bytes only      63 pairs, 5 records, 3 identities, 0 artifact hashes
[x] H artifacts cut AFTER the seal commit            8 artifacts, all 8 comments name 8d9f5d2
[x] H build manifest covers all artifacts+sidecars   artifact_count 8, each with its sidecar hash
[x] H cold-extract verification                      8/8 PASS
[x] H review package                                 REVIEW-PACKAGE-FIXUP01.zip + sidecar
[x] H release-notes draft                            RELEASE-NOTES-DRAFT.md
[x] H fixup report with consolidated LIVE-VERIFICATION REQUEST   this file, §9
```

No blank row. No residual item is builder-hermetic: every entry in §8 requires an operator ruling,
a reviewer verdict, or a human at the running product.

---

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
