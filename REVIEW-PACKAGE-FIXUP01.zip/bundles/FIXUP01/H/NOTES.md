# PHASE H — seal, in the acyclic order

Builder seat `claude-code (opus-5)`
**Seal commit: `8d9f5d2415599eeb0b71dc85a25a36469b41641e`**
Parent seal: `50b47326f91c5abab8b6d5250d59b1dba96a4d46`

The order is the point. A tracked manifest enters the archive it would describe, so the archive's
hash cannot live inside it (A-1 / OD-24). Manifests are regenerated and committed first; artifacts
are cut from that commit afterwards; their hashes live only in the untracked build manifest.

| step | done | evidence |
|---|---|---|
| 1 · no further code changes | yes — the last code commit is `d9c7409` (F-6) | `git log` |
| 2 · regenerate provenance, identity, RELEASE-MANIFEST over tracked bytes only | yes | below |
| 3 · commit — **this is the seal** | `8d9f5d2` | `SEAL-COMMITMSG.txt` |
| 4 · `git archive` the seal into all artifacts and sidecars | 8 artifacts + 8 sidecars | `../G/build-release-seal.log` |
| 5 · write `release-build-manifest.json` | 8 artifacts, byte counts and hashes, plus each sidecar's own hash | `release-build-manifest.json` |
| 6 · cold-extract every archive and hash-verify | **8/8 PASS** | `../G/cold-extract-verification.txt` |
| 7 · re-run manifest check and boundary gate on sealed bytes | both **PASS** | below |
| 8 · review package | `REVIEW-PACKAGE-FIXUP01.zip` + sidecar | `../../REVIEW-PACKAGE-FIXUP01.zip.sha256` |
| 9 · release-notes draft | `../RELEASE-NOTES-DRAFT.md` | — |
| 10 · fixup report + consolidated LIVE-VERIFICATION REQUEST | `../FIXUP-REPORT.md` | — |
| 11 · append to LOOP-RUN-REPORT | done | `../LOOP-RUN-REPORT.md` |

## Step 2 — regeneration

- **Module provenance**: `generate_module_provenance.py --root . --write` rewrote debate,
  distillery and sow. sovereign (`archive`) and tokencenter (`copy-based`) carry external source
  identities and are untouched by construction.
- **Release identity**: `generate_release_identity.py --source-commit
  d9c74096d048460cbacfad1c380ccb060021116b --generated-utc 2026-08-30T03:04:06Z`. That is F-6, the
  last product/tooling commit, per the X-5 convention — a tracked file cannot carry the hash of the
  commit that introduces it. Full 40-hex per R2 §9(2); the first attempt used the short form and
  was regenerated.
- **RELEASE-MANIFEST.json**: `H/regenerate_release_manifest.py --generated-utc 2026-08-30T03:04:06Z`
  — **63 path+sha256 pairs rehashed from disk, 5 provenance record hashes, 3 source identities**.
  Matching the parent seal's own counts. Nothing is carried forward from the previous manifest, so
  a stale value cannot survive by being left alone. Each `content_digest_sha256` is taken from the
  regenerated provenance record rather than recomputed, so record and manifest cannot disagree (S-4).
- **Zero release-artifact hashes written.** The only `.zip` strings in the manifest are the frozen
  SYSTEM and RESET baselines of R2 §1 and SOVEREIGN's source archive — inputs, not outputs — plus
  `release_archive_hash_authority: release-artifacts/release-build-manifest.json`.

`release_manifest_check --root .`: **FAIL (3 problems) at `d9c7409` → PASS (0 problems) at the
seal.** The three were `shell/src/probe.py`, `shell/static/app.js` and `shell/tests/test_render.py`
— exactly the tracked files this run changed that `batch_files` enumerates. That failure was the
manifests-last ordering working as designed, and it is closed.

## Step 4 — a stale artifact set, found and corrected

`build_release.ps1` builds **only the two composite ZIPs** from the named commit. It then
enumerates every `*.zip` already sitting in `release-artifacts/` and hashes whatever it finds. The
six per-module archives were therefore **left over from the parent seal**: after the first build
their zip comments still read `50b47326…` and `shell-1.0.0-rc.1-src.zip` was byte-identical to the
parent's despite this run changing six files under `shell/`.

A build manifest naming those hashes would have been perfectly accurate and completely misleading —
an artifact set that looks complete and ships pre-fix bytes. Directive step 4 says *all* release
artifacts are cut after the seal, so all six were re-cut.

The recipe was not guessed. `git archive --format=zip <commit> <subtree>` was verified to reproduce
the parent's `shell-1.0.0-rc.1-src.zip` **byte-identically** (sha256
`6f60b683f19df1b1d3d8f78b96c3574353a463f54505f39021c82d31694c3770`, 79 members, comment
`50b47326…`) before being used at the seal.

All eight archives now carry `8d9f5d2415599eeb0b71dc85a25a36469b41641e` in the zip comment.
debate, distillery, sovereign and tokencenter changed hash despite no content change, because
`git archive` embeds the commit id in the comment — expected, and the reason the comment is a
usable provenance check.

**This is a defect in `build_release.ps1`, not a one-off.** It re-cuts two archives and inherits
six, so any run that changes a module without re-cutting its archive ships a stale one and records
its hash authoritatively. Reported in the fixup report; not fixed here, because no item in this
run's scope covers the release tooling.

## Step 5 — build manifest

`release-artifacts/release-build-manifest.json` — `sovereign.release-build.v2`, version
`1.0.0-rc.1`, `source_commit 8d9f5d2415599eeb0b71dc85a25a36469b41641e`, **artifact_count 8**, each
with `name`, `bytes`, `sha256` and its sidecar's own name, bytes and sha256. Untracked, and it
excludes itself by construction.

| artifact | bytes | sha256 |
|---|---|---|
| debate-v1.2.1-hardening-src.zip | 184,499 | `36b40afb50be02ab24164f8084b267942f84dc4bb031f8e7dd1bc87ed511ec29` |
| distillery-1.1.0rc3-src.zip | 2,202,817 | `be8d37e94a521a59f1b3dd552921f21546a40e1f96ec0aa60ed73621c68fb3c8` |
| shell-1.0.0-rc.1-src.zip | 1,677,399 | `bd2ff2de5e8d56850c07c2b95673928ccd6bcb8ec522babe7ee8c93895636195` |
| sovereign-…-src.zip | 476,636 | `8b9a015fcff7679408b2ec2312bda7a01540261f084eac0fe3396c4ea73417c5` |
| sovereign-workspace-1.0.0-rc.1-install.zip | 29,930,914 | `1f264b0ce3906eac9cd3121d65f1f4576ec511093c5f35efd4171c0fbb70c08a` |
| sovereign-workspace-1.0.0-rc.1-source.zip | 29,762,740 | `de78ff23b28cf6cabaca05573f30bf3580aba05089dbe81b955b50e541a6b406` |
| sow-0.1.0-src.zip | 4,862,986 | `21902ea671fa3c7becae408fc7997208e363e4cee73fe10aa6cca978d014ce26` |
| tokencenter-record-dated-2026-08-26-src.zip | 387,961 | `cd2ff1b2a902cc55b78348b789e21c20ded4008aa5b780601c209cde081fc796` |

## Step 6 — cold extraction, 8/8 PASS

For each: byte count matches the manifest · artifact sha256 matches · the sidecar's own sha256
matches · the sidecar's recorded hash agrees with the measured artifact · `ZipFile.testzip()` finds
no CRC error · extracted file count equals the member count · **the zip comment names the seal**.
Both composite archives extract **3503 files**, matching `git archive HEAD`.

## Step 7 — gates against the sealed bytes

| gate | root | verdict |
|---|---|---|
| package boundary | extracted `sovereign-workspace-1.0.0-rc.1-source.zip` | **PASS** — 3503 scanned, 0 violations, 0 credential hits, 1982 quarantined-historical, 5 allowlisted |
| release manifest | `.` (the specified invocation) | **PASS (0 problems)** |
| release manifest | extracted sealed archive (coverage probe, not the specified invocation) | FAIL (12 problems) — **exactly the parent seal's 12**, so this run introduced none |

`tools/release` at sealed bytes: **84 tests, OK** — the two Phase-G failures are closed.

Porcelain at the seal carries no tracked modification; the single untracked
`modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json` is the parked N-29 artifact, present
before this run began.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
