"""FIXUP-01 Phase H step 2 — regenerate RELEASE-MANIFEST.json over TRACKED BYTES ONLY.

Every hash in the manifest is re-derived from the bytes on disk. Nothing is copied forward from
the previous manifest, so a stale value cannot survive by being left alone.

Three classes of hash are covered, which is the S-15 requirement: no manifest may carry a
path+sha256 pair its checker does not verify, and `release_manifest_check` verifies all three.

  1. every {"path": ..., "sha256": ...} object anywhere in the document
     (batch_files, identity_documents, ui_assets, and each module's locks /
     module_manifests / artifacts)
  2. modules.<m>.provenance_record_sha256  — the hash of that module's INSTALL-PROVENANCE.json
  3. modules.<m>.source_identity.content_digest_sha256 and content_file_count — taken from the
     regenerated provenance record itself rather than recomputed here, so the manifest and the
     record cannot disagree (S-4: coupled values move together)

NO release-artifact hash is written. Archives are cut after the seal commit and their hashes live
in release-artifacts/release-build-manifest.json, which RELEASE-MANIFEST.json names through
release_archive_hash_authority. That ordering is the A-1 fix and this script must not undo it.

Refuses to run against an untracked path, and reports every file it could not find rather than
silently dropping the entry.
"""
import hashlib
import json
import os
import subprocess
import sys

ROOT = r"D:\producttion software 2\release-worktree"
MANIFEST = os.path.join(ROOT, "RELEASE-MANIFEST.json")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def tracked_paths():
    out = subprocess.run(["git", "ls-files"], cwd=ROOT, capture_output=True, text=True, check=True)
    return {line.strip() for line in out.stdout.splitlines() if line.strip()}


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--generated-utc":
        generated_utc = sys.argv[2]
    else:
        raise SystemExit("usage: regenerate_release_manifest.py --generated-utc <ISO8601Z>")

    tracked = tracked_paths()
    with open(MANIFEST, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    problems = []
    untracked = []
    rehashed = 0

    def rehash_pairs(node):
        nonlocal rehashed
        if isinstance(node, dict):
            if "path" in node and "sha256" in node and isinstance(node["path"], str):
                rel = node["path"]
                full = os.path.join(ROOT, rel.replace("/", os.sep))
                if rel not in tracked:
                    # Pre-existing at the parent seal: the manifest enumerates two gitignored
                    # distillery build artifacts under dist/. They are rehashed from disk exactly
                    # as the parent did - narrowing the manifest's coverage is a policy change and
                    # is not this run's to make - but they are reported, because a manifest entry
                    # that is absent from `git archive` cannot be verified from the release bytes.
                    untracked.append(rel)
                if not os.path.isfile(full):
                    problems.append("missing on disk: " + rel)
                else:
                    node["sha256"] = sha256_file(full)
                    rehashed += 1
            for v in node.values():
                rehash_pairs(v)
        elif isinstance(node, list):
            for v in node:
                rehash_pairs(v)

    rehash_pairs(manifest)

    # 2 + 3: each module's provenance record hash, and the source identity that must agree with it.
    records = 0
    identities = 0
    for name, entry in manifest.get("modules", {}).items():
        cur = entry.get("current_provenance_path")
        if not cur:
            problems.append("{}: no current_provenance_path".format(name))
            continue
        full = os.path.join(ROOT, cur.replace("/", os.sep))
        if cur not in tracked:
            problems.append("{}: provenance record not tracked: {}".format(name, cur))
            continue
        if not os.path.isfile(full):
            problems.append("{}: provenance record missing at {}".format(name, cur))
            continue
        entry["provenance_record_sha256"] = sha256_file(full)
        records += 1

        with open(full, "r", encoding="utf-8-sig") as f:
            record = json.load(f)
        ident = entry.get("source_identity") or {}
        # Only candidate_tree_module identities are derived from the tree. `archive` and
        # `copy-based` identities describe an external source and are left exactly as they are.
        if "content_digest_sha256" in ident:
            record_digest = record.get("source_sha256")
            if not record_digest:
                problems.append("{}: record carries no source_sha256".format(name))
            else:
                ident["content_digest_sha256"] = record_digest
                identities += 1
            for key in ("content_file_count", "file_count"):
                if key in ident and key.replace("content_", "") in record:
                    ident[key] = record[key.replace("content_", "")]
                elif key in ident and key in record:
                    ident[key] = record[key]

    manifest["generated_utc"] = generated_utc
    manifest["producer"] = ("builder claude-code (opus-5) via "
                            "bundles/FIXUP01/H/regenerate_release_manifest.py (FIXUP-01 Phase H)")

    if problems:
        print("REFUSING TO WRITE — problems:")
        for p in problems:
            print("  " + p)
        return 1

    with open(MANIFEST, "w", encoding="utf-8", newline="\n") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        f.write("\n")

    for rel in untracked:
        print("WARNING enumerated but NOT git-tracked (absent from git archive): " + rel)
    print("rehashed path+sha256 pairs : {}".format(rehashed))
    print("provenance record hashes   : {}".format(records))
    print("source identities updated  : {}".format(identities))
    print("release-artifact hashes written: 0 (authority is "
          + str(manifest.get("release_archive_hash_authority")) + ")")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
