(() => {
  const f = document.querySelector("iframe.tokencenter-frame");
  const fb = document.querySelector(".tokencenter-fallback");
  if (!f || !fb) return { error: "embed not found" };
  let loc = "<cross-origin: COMMITTED>";
  try { loc = f.contentWindow.location.href; } catch (e) {}
  let kids = "<cross-origin>";
  try { kids = f.contentDocument.body.children.length; } catch (e) {}
  return {
    frameHidden: f.hasAttribute("hidden"),
    srcAttr: f.getAttribute("src"),
    contentWindowLocation: loc,
    innerBodyChildren: kids,
    fallbackHidden: fb.hasAttribute("hidden"),
    fallbackText: fb.innerText.replace(/\s+/g, " ").trim(),
    sandbox: f.getAttribute("sandbox"),
    verdict: (loc === "about:blank" && fb.hasAttribute("hidden"))
      ? "BLANK FRAME, NO FALLBACK (OP-4 forbidden state)"
      : (loc === "about:blank" ? "not committed, fallback shown" : "frame committed"),
  };
})()
