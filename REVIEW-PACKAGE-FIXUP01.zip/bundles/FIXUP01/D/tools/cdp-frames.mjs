// FIXUP-01 evidence tool: frame-level inspection via CDP. Reads INSIDE cross-origin
// child frames using their own execution context, records network activity, screenshots.
// Usage: node cdp-frames.mjs <url> [waitMs] [width] [height] [screenshotPath]
import { spawn } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const url = process.argv[2];
const waitMs = Number(process.argv[3] || 9000);
const width = Number(process.argv[4] || 1400);
const height = Number(process.argv[5] || 1000);
const shot = process.argv[6] || "";

const profile = mkdtempSync(join(tmpdir(), "fixup01-edge-"));
const port = 9222 + Math.floor(Math.random() * 500);
const edge = spawn(EDGE, [...(process.env.HEADED ? [] : ["--headless=new"]), `--remote-debugging-port=${port}`,
  `--user-data-dir=${profile}`, "--no-first-run", "--no-default-browser-check",
  "--disable-extensions", `--window-size=${width},${height}`, "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function httpJson(p) {
  for (let i = 0; i < 80; i++) {
    try { const r = await fetch(`http://127.0.0.1:${port}${p}`); if (r.ok) return await r.json(); }
    catch {} await sleep(250);
  }
  throw new Error("devtools endpoint never came up");
}
const version = await httpJson("/json/version");
const ws = new WebSocket(version.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });

let nextId = 1; const pending = new Map(); const events = [];
ws.onmessage = (m) => {
  const msg = JSON.parse(m.data);
  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id); pending.delete(msg.id);
    msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result);
  } else if (msg.method) events.push(msg);
};
const send = (method, params = {}, sessionId) => new Promise((resolve, reject) => {
  const id = nextId++; pending.set(id, { resolve, reject });
  ws.send(JSON.stringify({ id, method, params, sessionId }));
});

const { targetId } = await send("Target.createTarget", { url: "about:blank" });
const { sessionId } = await send("Target.attachToTarget", { targetId, flatten: true });
for (const d of ["Runtime", "Log", "Page", "Network"]) await send(`${d}.enable`, {}, sessionId);
await send("Emulation.setDeviceMetricsOverride",
  { width, height, deviceScaleFactor: 1, mobile: false }, sessionId);

await send("Page.navigate", { url }, sessionId);
await sleep(waitMs);

const tree = await send("Page.getFrameTree", {}, sessionId);
const contexts = events.filter(e => e.method === "Runtime.executionContextCreated")
  .map(e => ({ id: e.params.context.id, origin: e.params.context.origin,
               name: e.params.context.name, frameId: e.params.context.auxData?.frameId,
               isDefault: e.params.context.auxData?.isDefault }));

const frames = [];
const walk = (n) => { frames.push({ id: n.frame.id, url: n.frame.url,
  unreachableUrl: n.frame.unreachableUrl, parent: n.frame.parentId });
  (n.childFrames || []).forEach(walk); };
walk(tree.frameTree);

// Evaluate inside every frame using its own default execution context.
const perFrame = [];
for (const f of frames) {
  const ctx = contexts.find(c => c.frameId === f.id && c.isDefault);
  let val = { note: "no execution context for this frame" };
  if (ctx) {
    try {
      const r = await send("Runtime.evaluate", {
        expression: `({ href: location.href, title: document.title,
          bodyChildren: document.body ? document.body.children.length : -1,
          textLen: document.body ? document.body.innerText.length : -1,
          textHead: document.body ? document.body.innerText.slice(0,180) : "" })`,
        contextId: ctx.id, returnByValue: true }, sessionId);
      val = r.result.value ?? { error: JSON.stringify(r) };
    } catch (e) { val = { evalError: String(e.message).slice(0, 200) }; }
  }
  perFrame.push({ frameUrl: f.url, contextOrigin: ctx?.origin, ...val });
}

const netTo8765 = events.filter(e => e.method === "Network.responseReceived" &&
  e.params.response.url.includes("8765"))
  .map(e => ({ url: e.params.response.url, status: e.params.response.status,
               type: e.params.type }));
const netFailed = events.filter(e => e.method === "Network.loadingFailed")
  .map(e => ({ err: e.params.errorText, blocked: e.params.blockedReason, type: e.params.type }));

if (shot) {
  const { data } = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: true }, sessionId);
  writeFileSync(shot, Buffer.from(data, "base64"));
}

console.log(JSON.stringify({ frames, perFrame, netTo8765, netFailed,
  consoleErrors: events.filter(e => e.method === "Log.entryAdded")
    .map(e => `[${e.params.entry.level}] ${e.params.entry.text}`.slice(0, 200))
    .filter((v, i, a) => a.indexOf(v) === i).slice(0, 12) }, null, 2));
ws.close(); edge.kill(); process.exit(0);
