(async () => {
  await new Promise(r => setTimeout(r, 1500));
  const f = document.querySelector("iframe.tokencenter-frame");
  if (!f) return { found: false, bodyHasLlamacpp: document.body.innerHTML.includes("llamacpp") };
  let inner = {};
  try {
    inner = {
      href: f.contentWindow.location.href,
      readyState: f.contentDocument ? f.contentDocument.readyState : null,
      title: f.contentDocument ? f.contentDocument.title : null,
      bodyChildren: f.contentDocument ? f.contentDocument.body.children.length : null,
      innerTextLen: f.contentDocument ? f.contentDocument.body.innerText.length : null,
    };
  } catch (e) { inner = { crossOriginBlocked: String(e) }; }
  const rect = f.getBoundingClientRect();
  return {
    found: true,
    srcAttr: f.getAttribute("src"),
    srcProp: f.src,
    loadingAttr: f.getAttribute("loading"),
    sandboxAttr: f.getAttribute("sandbox"),
    hiddenAttr: f.hasAttribute("hidden"),
    computedDisplay: getComputedStyle(f).display,
    rect: { w: Math.round(rect.width), h: Math.round(rect.height), top: Math.round(rect.top) },
    inner,
    fallbackHidden: document.querySelector(".tokencenter-fallback").hasAttribute("hidden"),
    moduleCards: [...document.querySelectorAll(".module-card")].map(c => c.dataset.module),
    bodyHasLlamacpp: document.body.innerHTML.includes("llamacpp"),
  };
})()
