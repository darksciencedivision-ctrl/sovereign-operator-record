(() => {
  const f = document.querySelector("iframe.tokencenter-frame");
  const fb = document.querySelector(".tokencenter-fallback");
  if (!f || !fb) return { error: "embed elements not found", haveFrame: !!f, haveFallback: !!fb };
  const r = f.getBoundingClientRect();
  let loc = "<cross-origin: frame navigated away from about:blank>";
  try { loc = f.contentWindow.location.href; } catch (e) { /* cross-origin == navigated */ }
  let kids = "<cross-origin>";
  try { kids = f.contentDocument.body.children.length; } catch (e) { /* cross-origin */ }
  return {
    srcAttr: f.getAttribute("src"),
    hidden: f.hasAttribute("hidden"),
    loading: f.getAttribute("loading"),
    contentWindowLocation: loc,
    innerBodyChildren: kids,
    rectTop: Math.round(r.top),
    viewportH: window.innerHeight,
    belowFold: r.top > window.innerHeight,
    fallbackHidden: fb.hasAttribute("hidden"),
    fallbackText: fb.innerText.trim().split(String.fromCharCode(10))[0],
    scrollY: Math.round(window.scrollY),
  };
})()
