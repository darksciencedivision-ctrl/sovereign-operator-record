// FIXUP-01 D-1: does the Token Center frame navigate when it is unhidden below the fold?
// Headed Edge (real lazy-load heuristics; headless Chromium disables them).
import { spawn } from "node:child_process";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const SHELL = "http://127.0.0.1:5180/";
const profile = mkdtempSync(join(tmpdir(), "fixup01-edge-"));
const port = 9700 + Math.floor(Math.random() * 200);
const edge = spawn(EDGE, [`--remote-debugging-port=${port}`, `--user-data-dir=${profile}`,
  "--no-first-run", "--no-default-browser-check", "--disable-extensions",
  "--window-size=900,600", "--window-position=0,0", "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function httpJson(p) { for (let i=0;i<80;i++){ try{const r=await fetch(`http://127.0.0.1:${port}${p}`); if(r.ok) return r.json();}catch{} await sleep(250);} throw new Error("no devtools"); }
const v = await httpJson("/json/version");
const ws = new WebSocket(v.webSocketDebuggerUrl);
await new Promise((res,rej)=>{ws.onopen=res;ws.onerror=rej;});
let nid=1; const pend=new Map(); const evs=[];
ws.onmessage=(m)=>{const x=JSON.parse(m.data);
  if(x.id&&pend.has(x.id)){const{resolve,reject}=pend.get(x.id);pend.delete(x.id);x.error?reject(new Error(JSON.stringify(x.error))):resolve(x.result);}
  else if(x.method) evs.push(x);};
const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{const id=nid++;pend.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params,sessionId}));});
const {targetId}=await send("Target.createTarget",{url:"about:blank"});
const {sessionId}=await send("Target.attachToTarget",{targetId,flatten:true});
for(const d of ["Runtime","Page","Network","Log"]) await send(`${d}.enable`,{},sessionId);

const ev=async(expr)=>{const r=await send("Runtime.evaluate",{expression:expr,awaitPromise:true,returnByValue:true},sessionId);
  return r.exceptionDetails? {err:r.exceptionDetails.text, detail:String((r.exceptionDetails.exception||{}).description||"").slice(0,400)}: r.result.value;};

const probe = readFileSync("d1-probe.js", "utf8");

await send("Page.navigate",{url:SHELL},sessionId);
await sleep(4000);
const s1 = await ev(probe);

// Start Token Center by CLICKING the control the UI offers (S-17: the product path).
const started = await ev(`(()=>{const b=document.querySelector(".tokencenter-fallback button");
  if(!b) return "no button"; if(b.disabled) return "button DISABLED"; b.click(); return "clicked";})()`);
await sleep(20000);
const s2 = await ev(probe);
const net2 = evs.filter(e=>e.method==="Network.responseReceived"&&e.params.response.url.includes("8765")).length;
await sleep(25000);                       // past the 30 s settled-poll interval
const s2b = await ev(probe);
const net2b = evs.filter(e=>e.method==="Network.responseReceived"&&e.params.response.url.includes("8765")).length;
await ev(`document.querySelector("iframe.tokencenter-frame").scrollIntoView({block:"center"})`);
await sleep(8000);
const s3 = await ev(probe);
const net3 = evs.filter(e=>e.method==="Network.responseReceived"&&e.params.response.url.includes("8765")).length;

console.log(JSON.stringify({
  "1_page_loaded_TC_stopped": s1,
  "start_response": started,
  "2_20s_after_click": s2, "req_8765": net2,
  "2b_45s_after_click": s2b, "req_8765_2b": net2b,
  "3_after_scrollIntoView": s3, "requests_to_8765_after_scroll": net3,
}, null, 2));
ws.close(); edge.kill(); process.exit(0);
