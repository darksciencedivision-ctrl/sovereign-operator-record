(() => {
  const out = [];
  for (const card of document.querySelectorAll(".module-card")) {
    const b = card.querySelector('button[data-action="open"]');
    out.push({
      module: card.dataset.module,
      state: card.querySelector(".badge").textContent,
      open: b ? (b.disabled ? "disabled" : "ENABLED") : "(no Open button)",
      tooltip: b ? b.getAttribute("title") : null,
    });
  }
  return out;
})()
