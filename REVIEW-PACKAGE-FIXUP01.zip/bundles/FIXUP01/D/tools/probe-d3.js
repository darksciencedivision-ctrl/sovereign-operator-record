(() => {
  const out = [];
  for (const card of document.querySelectorAll(".module-card")) {
    const btns = {};
    for (const b of card.querySelectorAll("button[data-action]")) {
      btns[b.dataset.action] = b.disabled ? "disabled" : "ENABLED";
    }
    out.push({
      module: card.dataset.module,
      state: (card.querySelector(".badge") || {}).textContent,
      buttons: btns,
    });
  }
  return { cards: out, cardCount: out.length, hasLlamacpp: document.body.innerHTML.includes("llamacpp") };
})()
