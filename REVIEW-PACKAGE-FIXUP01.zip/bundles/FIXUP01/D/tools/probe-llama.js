(() => {
  const card = document.querySelector('.module-card[data-module="llamacpp"]');
  if (!card) return { error: "no llamacpp card" };
  const btn = card.querySelector('button[data-action="start"]');
  return {
    title: card.querySelector(".module-name").textContent,
    visibleText: card.innerText.replace(/\s+/g, " ").trim().slice(0, 300),
    startDisabled: btn.disabled,
    startTooltip: btn.getAttribute("title"),
  };
})()
