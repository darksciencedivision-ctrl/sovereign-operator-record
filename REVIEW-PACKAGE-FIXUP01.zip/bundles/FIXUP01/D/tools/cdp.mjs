// FIXUP-01 evidence tool: dependency-free CDP driver for Microsoft Edge.
// Node 24 ships a global WebSocket, so nothing is installed to run this.
// Usage: node cdp.mjs <url> <probe.js file> [waitMs]
import { spawn } from "node:child_process";
import { readFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const url = process.argv[2];
const probePath = process.argv[3];
const waitMs = Number(process.argv[4] || 6000);
const probe = readFileSync(probePath, "utf8");

const profile = mkdtempSync(join(tmpdir(), "fixup01-edge-"));
const port = 9222 + Math.floor(Math.random() * 500);
const edge = spawn(EDGE, [
  "--headless=new", `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`,
  "--no-first-run", "--no-default-browser-check", "--disable-extensions",
  "--window-size=1400,1000", "about:blank",
], { stdio: "ignore" });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function httpJson(path) {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}${path}`);
      if (r.ok) return await r.json();
    } catch { /* not up yet */ }
    await sleep(250);
  }
  throw new Error("Edge devtools endpoint never came up");
}

const version = await httpJson("/json/version");
const ws = new WebSocket(version.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });

let nextId = 1;
const pending = new Map();
const events = [];
ws.onmessage = (m) => {
  const msg = JSON.parse(m.data);
  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id);
    pending.delete(msg.id);
    msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result);
  } else if (msg.method) {
    events.push(msg);
  }
};
const send = (method, params = {}, sessionId) =>
  new Promise((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params, sessionId }));
  });

const { targetId } = await send("Target.createTarget", { url: "about:blank" });
const { sessionId } = await send("Target.attachToTarget", { targetId, flatten: true });

await send("Runtime.enable", {}, sessionId);
await send("Log.enable", {}, sessionId);
await send("Page.enable", {}, sessionId);
await send("Network.enable", {}, sessionId);

await send("Page.navigate", { url }, sessionId);
await sleep(waitMs);

const { result, exceptionDetails } = await send("Runtime.evaluate", {
  expression: probe, awaitPromise: true, returnByValue: true,
}, sessionId);

const consoleLines = events
  .filter((e) => e.method === "Log.entryAdded" || e.method === "Runtime.consoleAPICalled")
  .map((e) => e.method === "Log.entryAdded"
    ? `[${e.params.entry.level}] ${e.params.entry.text}`
    : `[console.${e.params.type}] ${(e.params.args || []).map((a) => a.value ?? a.description).join(" ")}`);

console.log(JSON.stringify({
  probe: exceptionDetails ? { error: exceptionDetails.text, detail: exceptionDetails.exception?.description } : result.value,
  console: consoleLines,
}, null, 2));

ws.close();
edge.kill();
process.exit(0);
