(() => {
  const card = document.querySelector('.module-card[data-module="llamacpp"]');
  const line = card.querySelector(".state-line");
  return {
    stateLineText: line ? line.innerText.replace(/\s+/g, " ").trim() : null,
    fullCardTail: card.innerText.replace(/\s+/g, " ").trim().slice(-260),
  };
})()
