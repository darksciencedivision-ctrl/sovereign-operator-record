# FIXUP-01 · PHASE D — DIAGNOSIS
## Builder seat `claude-code (opus-5)` · parent seal `50b47326f91c5abab8b6d5250d59b1dba96a4d46`
## Method: every finding reproduced from bytes and from the running product before any change.

The validator's `VALIDATOR-LIVE-OBSERVATIONS-01.md` is treated as an input, not an authority
(directive §3). Four of its six findings do not survive independent reproduction as stated.
Per §3, **a refuted finding is reported and NOT fixed.**

Live rig used throughout: the shell started from the worktree on the port named per check,
Microsoft Edge driven over the DevTools Protocol by `D/tools/cdp*.mjs` (dependency-free; Node 24
ships a global `WebSocket`, so nothing was installed). No model was loaded, no provider was called,
no interlock was touched.

---

## Summary table

| check | item | verdict |
|---|---|---|
| D-1 | N-21 Token Center frame never navigates | **REFUTED** — the frame navigates and paints |
| D-2 | N-22 llamacpp dropped or filtered by the shell | **PARTIAL** — symptom real, stated cause REFUTED |
| D-3 | N-23 Open enabled where it cannot act | **VERIFIED** — reproduced live; validator's state table is wrong |
| D-4 | N-27 SOVEREIGN readiness, cause undetermined | **VERIFIED + ROOT-CAUSED** — cause measured, not theorised |
| D-5 | N-25 no local models in the picker | **REFUTED as stated** — PARTIAL residue is real and small |
| D-6 | CLOSEOUT-01 baseline re-measure | **VERIFIED** — reproduces the seal exactly |

---

## D-1 · N-21 — Token Center embed · REFUTED

**Claim under test:** "the frame sits at `about:blank` and never navigates", with both CSP halves
correct and no CSP violation.

**Reproduction.** Shell started on **5180** (the validator's own port — required, see D-1-a below),
Token Center started through the shell's own `/api/start`, both CSP headers measured on the wire and
identical to the validator's table.

Command: `node D/tools/cdp-frames.mjs http://127.0.0.1:5180/ 10000 1400 1000 D/d1-live-5180.png`

Measured frame tree:

```
frames: [ http://127.0.0.1:5180/ , http://127.0.0.1:8765/  (child of the shell frame) ]
netTo8765: 200 http://127.0.0.1:8765/                  Document
           200 http://127.0.0.1:8765/styles.css        Stylesheet
           200 http://127.0.0.1:8765/app.js            Script
           200 http://127.0.0.1:8765/api/summary?days=14   Fetch
           200 http://127.0.0.1:8765/assets/gold-drop-sam.png  Image
netFailed: []            <- zero blocked, zero failed
```

The child frame's committed URL is `http://127.0.0.1:8765/`, not `about:blank`, and the module's
full resource set — document, stylesheet, script, its live API call and its image — loaded 200.
`D/d1-live-5180.png` is a screenshot of the shell with the Token Center panel **fully painted**
inside the embed: the piggy bank, "115,164,795 PROCESSED TOKENS", the stat tiles and the 14-day
signal band.

**The measurement that decides it.** Reading `iframe.contentWindow.location.href` from the shell
page throws:

```
SecurityError: Failed to read a named property 'href' from 'Location':
Blocked a frame with origin "http://127.0.0.1:5180" from accessing a cross-origin frame.
```

A cross-origin SecurityError is **positive proof that the frame navigated.** An iframe still at its
initial `about:blank` is same-origin with its parent and reads back cleanly — which is precisely
what the validator recorded (`about:blank`, `readyState complete`, `title ""`, `body.children 0`).
Those five readings are mutually consistent only with a frame that never left `about:blank`, and
they are not reproducible here.

**Product-path test (S-17).** Headed Edge at 900x600, Token Center STOPPED at page load, then the
operator's actual gesture — clicking the panel's own **Start Token Center** button
(`D/tools/d1-lazy-test.mjs`):

| stage | src attr | frame hidden | contentWindow.location | fallback |
|---|---|---|---|---|
| page loaded, TC stopped | `null` | true | `about:blank` | visible: "Token Center is stopped." |
| 20 s after clicking Start | `http://127.0.0.1:8765/` | false | **cross-origin (navigated)** | hidden |
| 45 s after clicking Start | `http://127.0.0.1:8765/` | false | **cross-origin (navigated)** | hidden |

The frame committed even though `belowFold: true` (`rectTop 715` vs `viewportH 509`) — so
`loading="lazy"` did not defer it, and the leading hypothesis the directive named for me to confirm
or eliminate (`src` and `sandbox` applied in an order that re-initialises the element) is
**eliminated**: `sandbox` is set at construction before insertion, `src` only after insertion, and
the navigation commits.

**The OP-4 fallback already exists and works.** The directive states the fallback "does not exist".
It does: `app.js:463-472` builds it and `refreshTokenCenterEmbed` (`app.js:550-568`) shows a status
line and a Start control whenever the module is not running. It is measured above doing exactly
that, and the operator's click on it started the module. This part of the directive is refuted too.

**Why the validator saw what it saw.** Its own Method limitation section says the observation was
taken "through the Claude desktop browser pane, not the operator's own browser", and it asked for
confirmation in Brave or Edge before the finding is treated as closed. That confirmation has now
been performed in Edge and the finding does not reproduce. N-21 is a browser-pane artefact, not a
product defect. It is reported, not fixed (§3). **LV-1 asks the validator to re-confirm.**

### Real findings surfaced while refuting N-21 (none of them is N-21)

- **D-1-a · Token Center's `frame-ancestors` is hardcoded to port 5180**
  (`modules/tokencenter/piggybank.py:36`). The shell's port is a `--port` argument that merely
  *defaults* to 5180. Run the shell on any other port and the embed is blocked for real — measured:
  starting the shell on 5191 leaves `frame-ancestors http://127.0.0.1:5180` unchanged. Not in any
  F-item; recorded for the operator.
- **D-1-b · Token Center violates its own CSP, standalone.** Loading `http://127.0.0.1:8765/`
  directly, with no shell and no iframe, emits 11 `Applying inline style violates ... style-src
  'self'` errors plus one 404. Pre-existing, unrelated to framing, outside this run's items.
- **D-1-c · the fallback status text goes stale.** After the frame comes up, the (hidden) fallback
  still reads "Token Center is starting....". Not visible to the operator; cosmetic.

## D-1b · N-21b — `sandbox="allow-scripts allow-same-origin"` · VERIFIED

Console, on every run: *"An iframe which has both allow-scripts and allow-same-origin for its
sandbox attribute can escape its sandboxing."* The attribute is inert as written. Addressed in F-1b.

---

## D-2 · N-22 — llamacpp absent from the shell · PARTIAL

**Symptom VERIFIED.** Live DOM at 5180: 5 cards (`sovereign, sow, tokencenter, debate, distillery`),
`document.body.innerHTML.includes("llamacpp") === false`. Served bytes agree: `curl /` and
`curl /static/app.js` both contain zero occurrences of the string.

**Stated cause REFUTED.** The validator attributes this to its own CLOSEOUT-01 item X-4 step 4 and
states "Before CLOSEOUT-01 the shell loaded six". Three independent measurements say otherwise:

1. **The shell does not drop it and does not filter it.** `load_all_adapters` (`adapter.py:396`)
   walks every `*.json` in `shell/modules/` except `schema.json`. Live startup output, captured at
   `D/shell-startup-5180.log`, is clean — no error, no skip — and prints:
   `Modules loaded: ['debate','distillery','llamacpp','sovereign','sow','tokencenter']` — **six**.
   `/api/state` serves a complete `llamacpp` record.
2. **The post-X-4 evidence already showed six.** `bundles/CLOSEOUT01/Y/installed-shell.log`, written
   *after* commit `9110390` (X-4), prints the same six-module line. Had X-4 removed llamacpp from
   the shell, that log could not exist.
3. **The UI never had it.** `git log --all -S"llamacpp" -- shell/src shell/static` returns **no
   commits at all**. The string has never appeared in the shell frontend in this repo's history.

**Actual cause.** `shell/static/app.js:32-63` hardcodes a five-entry `MODULES` array, and
`renderCards` iterates that array rather than `/api/state`. The backend's sixth module has no card
to render into. The "six" in the install logs is the *backend loader's* line; the UI has always
shown five. This is a frontend/backend divergence that predates CLOSEOUT-01 entirely.

X-4 is exonerated. Reverting X-4's path neutralisation — which the directive already forbids under
S-16 — would not have restored the module either.

**OBS-2** follows from the same line: the optional-adapter skip signal has no human-visible surface
because the module it describes has no card. Addressed in F-2.

---

## D-3 · N-23 — Open enabled where it cannot act · VERIFIED

**Reproduced live, and the validator's state table is wrong.**

Probe with every module STOPPED (`D/tools/probe-d3.js`): **every** Open button is `disabled`,
SOW's included. The validator's table reports "All four modules were Stopped at the time of
measurement" with SOW's Open **ENABLED**. That combination cannot occur in this code.

Started SOW through the shell; it reached READY in 6 s. Probe again:

```
sow | Ready | {start: disabled, stop: ENABLED, restart: ENABLED,
               open: ENABLED, test: disabled, logs: ENABLED}
/api/state sow: state READY | url '' | can_open True
```

So the defect is real and the operator's report is exactly right — but it manifests when SOW is
**running**, not when it is stopped. That matches the operator's own words ("the app comes up, but
the Open button does nothing"): they had SOW up at the time.

**The guard, by line.** Enablement is driven by module *state* alone; `open.kind` is never consulted
at either site:

- `shell/src/states.py:348-350` — `can_open()` returns `self.state in (READY, EXTERNAL)`. A module
  declaring `open.kind: none` is therefore reported `can_open: true`.
- `shell/src/states.py:362` — the same record carries
  `"url": self.adapter.get("open", {}).get("url", "")`, i.e. `""` for SOW.
- `shell/static/app.js:602` — `enabled = (ACTION_STATES[action] || []).indexOf(st) !== -1`, with
  `ACTION_STATES.open = ["READY","EXTERNAL"]` (`app.js:85`). The client **ignores the server's
  `can_open` field entirely** and recomputes enablement from state.
- `shell/static/app.js:700-708` — the click handler then finds `rec._url` empty and falls through to
  `announce(name + ": no URL available")`, an aria-live message with no visible surface. To the
  operator the button is simply dead.

Two modules declare `open.kind: none`: `sow.json` and `llamacpp.json`. The second is invisible today
(D-2), so SOW is the only one an operator can reach.

**Adapter schema.** `adapter.py:199` admits only `browser` and `none`, so there is no declarable way
to raise SOW's existing native window. Addressed in F-3.

---

## D-4 · N-27 — SOVEREIGN readiness · VERIFIED, ROOT CAUSE MEASURED

The directive requires this one measured rather than theorised. It is.

**Reproduced live through the shell.** Start SOVEREIGN, then poll `/api/state`:

```
t=6s .. t=54s   STARTING
t=60s           FAILED | 'HEALTH_CHECK_FAILED: readiness probe not satisfied'
```

— the operator's exact error string.

**The endpoint is healthy the whole time.** Launching the adapter's argv by hand
(`.venv/Scripts/python.exe -m sovereign_product.server --root ... --port 5175 --workers 1`) produces
no error, binds 5175, and serves:

```
curl -w '%{time_total} %{http_code}' http://127.0.0.1:5175/v1/health
1.252393s 200   1.241784s 200   1.246385s 200   1.268237s 200   1.242194s 200
```

**HTTP 200, in ~1.25 s, every time.** `expect_status` is 200, and `identity.required_keys`
(`status`, `product_version`) are both present in the body. So readiness *should* pass.

**The cause.** `shell/src/probe.py:32`:

```python
resp = urllib.request.urlopen(req, timeout=min(5, poll_ms / 1000))
```

The **poll interval is reused as the per-request socket timeout.** `sovereign.json` sets
`poll_ms: 500`, so every probe request is given **0.5 s** to complete an endpoint that needs 1.25 s.
Reproduced directly, against the live healthy server:

```
0.5s-timeout attempt 0: FAILED after 0.532s -> TimeoutError: timed out
0.5s-timeout attempt 1: FAILED after 0.528s -> TimeoutError: timed out
0.5s-timeout attempt 2: FAILED after 0.511s -> TimeoutError: timed out
```

Every one of the ~90 attempts inside the 45 s window times out at ~0.53 s. SOVEREIGN can **never**
satisfy this probe, on any host, at any value of `timeout_s`.

This is exactly why the obvious causes were correctly eliminated: the venv, the `sovereign_product`
package and the `/v1/health` route at `server.py:1906` are all genuinely fine. The defect is in the
prober, not in the probed.

It also disposes of the tempting non-fix: **raising `timeout_s` cannot help**, because the failure
is per-request, not cumulative. Doing so would be precisely the S-12 error the directive forbids.

Why `/v1/health` costs 1.25 s: it reports `model_service_reachable: false` and
`detail: "loopback model service is unavailable"` — it waits on the local Ollama daemon, which is
down on this host. Ollama being down is host state (N-28) and is not itself a defect; a health
endpoint that answers 200 in 1.25 s is entitled to be probed with a timeout greater than 0.5 s.

Every http-readiness adapter is exposed to this: `tokencenter` poll_ms 250 (a 0.25 s budget),
`llamacpp` 400, `sovereign` 500. Token Center passes only because it answers in milliseconds.

Addressed in F-4. This is a product defect, not an environment finding.

---

## D-5 · N-25 — local models in the picker · REFUTED as stated

**Claim under test:** "`grep ollama apps/desktop/*.js` -> nothing. The Electron picker is
frontier-only by construction... There is no local option of any kind... no local code path at all."

**The grep is the error.** `apps/desktop/*.js` is a non-recursive glob; it matches only files
directly in `apps/desktop`. The picker lives in `apps/desktop/picker/`. Run recursively, `ollama`
appears in:

```
apps/desktop/picker/source.js          apps/desktop/picker/launch-source.js
apps/desktop/picker/worker-spawn.js    apps/desktop/renderer/renderer.js
apps/desktop/conductor/launch-source.js  (+4 selfcheck files)
```

This is the same class of error the validator self-corrected once already in its own N-27 entry
("the grep ran from the wrong directory"). It recurred here and produced a HIGH finding.

**Measured: a full local path exists, end to end.**

`tools/live/enumerate_pane_picker.py` — the enumerator that `apps/desktop/picker/source.js` invokes
via `--emit-picker` — carries `detect.ollama_models()`, `detect.ollama_executable()`,
`local_admission_reason()` and a `counts.local` field. Running it on this host, live:

```
counts    : {'total': 23, 'available': 0, 'frontier': 23, 'local': 0}
providers : ['claude_code','openai_codex_cli','grok_build','google_antigravity','ollama_local']
```

There are **five** provider rows and the fifth is `ollama_local`, displayed as "Local (Ollama)".
`local` is 0 because Ollama is not running on this host, not because the path is absent.

**Hermetic proof that local options appear when Ollama is up** — no model loaded, no daemon
contacted, no provider CLI probed, `live_operation.json` still absent:

```
counts: {'total': 10, 'available': 0, 'frontier': 7, 'local': 3}
ollama_local: option_count 3
   LOCAL: qwen3:8b                available False
   LOCAL: qwen2.5-coder:7b        available False
   LOCAL: nomic-embed-text:latest available False
   reason: "no local pane can be authorized: this host's VRAM admission budget could not be
            established - ollama daemon unreachable - no planner"
```

**S-18 question answered: local is NOT gated behind `live_operation.json`.** That run had no
live-operation config and still enumerated three local options carrying a local-specific reason. The
absent file greys the 23 *frontier* options and nothing else. **No park is required here**, and the
design flaw the directive anticipated — local gated behind the spend switch — does not exist.

**The renderer displays zero-option groups.** `renderer/renderer.js:936-941` maps every provider row
through `PickerChrome.providerGroupHtml(g, opts, esc)`, with a comment recording that a provider
enumerating nothing "used to render the bare words 'no options' ... which is the silent gap §14
forbids". The N-22 failure mode is already guarded at this site.

**PARTIAL residue — the one real, small gap.** With Ollama fully down, the `ollama_local` row's
reason degrades from the specific `local_admission_reason` text to the generic
`"no options enumerated for this provider"`, which names neither Ollama nor what the operator should
do about it. That is the honest-degradation requirement F-5 states, and it is the only part of N-25
that survives reproduction. Addressed in F-5 at its measured size, not at the size the punch list
claimed.

---

## D-6 · CLOSEOUT-01 baseline · VERIFIED — reproduces the seal exactly

| measurement | value |
|---|---|
| `git archive HEAD` file count | **3497** |
| archive-bound package boundary gate | **PASS** — scanned 3497, violations 0, credential hits 0, quarantined-historical 1982, allowlisted 5, exit 0 |
| `tools/release/test_*.py` | **84 tests, OK** |

Identical to `bundles/CLOSEOUT01/Z/gates-at-seal.txt`.

**Invocation note (S-3).** The gate is archive-bound: `--root` must point at an *extracted*
`git archive HEAD` tree, and `--allowlist` must be the copy **inside that tree**. Passing the
worktree's allowlist path while scanning the extracted tree makes the gate flag the archive's own
`fixture_allowlist.json` as `credential-pattern / openai-style-key` and report FAIL with 1 credential
hit — a false FAIL of the same family as the omitted-flag trap the directive warns about. Recorded
so Phase G and any successor reproduce the number rather than a near miss.

For completeness: invoked against the live worktree (`--root .`) the gate reports FAIL with 19,618
violations, because it then walks `modules/*/.venv/` and `.runtime/`. That is the filesystem mode,
not the release boundary, and is not the baseline.

---

## Boot obstruction, recorded (not a hash mismatch, so no BOOT-FAILURE.md — ENTRY 011 §5)

`git status --porcelain` at BOOT was not empty (exit status 0 captured):

```
?? modules/sow/docs/evidence/receipts/SHELL-LIVE-READY.json
```

Untracked, product-generated, `bootedAt 2026-08-30T00:44:25.471Z` — written by SOW during the T-2
attended session. Preserved byte-for-byte at `D/BOOT-untracked-SHELL-LIVE-READY.json`.

**This is a live recurrence of N-16 in a second lane.** `sow.json` declares
`readiness.kind: receipt_file` at `${root}/docs/evidence/receipts/SHELL-LIVE-READY.json` — inside a
**tracked** directory (26 tracked siblings). CONVERGE-01's N-16 fix moved the *shell's* startup-test
evidence to the gitignored `.runtime/` lane; SOW's own readiness receipt was not covered, so normal
product use still dirties the release candidate and will BOOT-fail every future builder run.

Filed as **N-29**. Not in this run's authorized item set, so it is parked rather than improvised
(S-9); dossier at `bundles/FIXUP01/PARKED-N-29-sow-receipt-in-tracked-tree.md`. The file was left
exactly where the product wrote it — nothing outside the write set was deleted (E-2) — and every
porcelain assertion in this run is stated modulo this one named artifact.

---

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
