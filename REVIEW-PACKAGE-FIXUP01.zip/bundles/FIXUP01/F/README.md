# PHASE F — bundle index

One item, one commit. Each item's full rationale — what the directive asked for, what the bytes
actually needed, the fail-before and pass-after evidence, and anything carried to the operator —
is the commit message itself, preserved here verbatim as `COMMITMSG.txt`. It is not duplicated
into a second prose file: two copies of the same record is the drift the A-3 finding was about.

| dir | item | commit |
|---|---|---|
| `F-1/` | N-21 (refuted) · N-21b resolved · Token Center panel guarded | `c655021` |
| `F-2/` | N-22 / OBS-2 — every loaded module rendered; absent runtime named | `7c56b43` |
| `F-3/` | N-23 — Open follows capability; `open.kind: focus_window` | `73f6a39` + `1d5986f` |
| `F-4/` | N-27 — readiness request timeout decoupled from the poll interval | `8b31258` |
| `F-5/` | N-25 — the local provider group says why it is empty | `497114a` |
| `F-6/` | the regression guard for the whole class | `d9c7409` |

`F-1/NOTES.md` carries extra narrative because that item ends in a refutation plus a removed
guard, and both needed more room than a commit message.

`F-3` has two commits. The second exists because the S-5 restore helper reverted the first's
source changes before they were staged; the cause is recorded in `F-3/COMMITMSG-part2.txt` and in
the fixup report §7. `73f6a39` was not amended — S-10 forbids rewriting any existing commit.

Patches for all eight commits: `../H/patches/`.
