# F-1 · N-21 / N-21b — Token Center panel
## Outcome: N-21 REFUTED (reported, not fixed) · N-21b RESOLVED · fallback ALREADY PRESENT, now guarded

## What the directive asked for, and what the bytes actually needed

| directive clause | finding | action |
|---|---|---|
| "Fix the cause D-1 established" (frame never navigates) | **REFUTED** — the frame navigates, loads all five resources 200, and paints (D/DIAGNOSIS.md D-1; screenshot D/d1-live-5180.png) | reported, **not fixed** (§3) |
| "implement the fallback the OP-4 spec required and that does not exist" | **it exists** — `app.js:463-472` plus `refreshTokenCenterEmbed`; measured showing "Token Center is stopped." with a working Start control | no new fallback; a **behavioural guard** added so it cannot silently regress |
| N-21b inert sandbox | **VERIFIED** | resolved: kept, with the reasoning recorded in-source |

## Changed files

- `shell/static/app.js` (+14/-0)
- `shell/tests/test_tokencenter_embed.py` (new, 2 tests)

## N-21b — the decision, and why

The sandbox attribute is **KEPT**, both tokens, with a rationale block recorded at the construction
site.

Why not drop it, the other option the directive allowed: the pair is not inert. It still denies form
submission, popups, top-level navigation, downloads, modals and pointer-lock. Dropping the attribute
surrenders all six for no gain.

Why the browser warning does not apply here: "can escape its sandboxing" describes a frame that is
same-origin with its EMBEDDER, which can then reach out and delete its own sandbox attribute. This
frame is 127.0.0.1:8765 inside a 127.0.0.1:5180 document. `allow-same-origin` grants the frame ITS
OWN origin, not the shell's, so it cannot script the shell and the escape is unreachable. Both
tokens are load-bearing: Token Center's own CSP is `default-src 'self'` and its dashboard is
script-rendered and fetches `/api/summary`; under an opaque origin both of those fail.

`test_sandbox_is_the_recorded_combination_and_the_frame_is_cross_origin` pins exactly the premise
that makes this safe — it fails if Token Center is ever moved onto the shell's own origin, which is
the one change that would invalidate the rationale.

## Also fixed (D-1-c)

The fallback's status text and button label went stale after the frame came up, so a later fall back
to the panel could show "Token Center is starting...." for a module that had since stopped. The
label is now reset alongside the status.

## A guard I built, measured, and REMOVED — recorded because the removal is the point

I first implemented a client-side commit watchdog: after setting `src`, check whether
`frame.contentWindow.location.href` throws (cross-origin = committed) and fall back to a status
panel if it still read `about:blank`.

Then I measured it against a genuinely blocked frame (shell on 5191, Token Center's
`frame-ancestors` fixed at 5180). The console confirmed the block:

    Framing 'http://127.0.0.1:8765/' violates the following Content Security Policy
    directive: "frame-ancestors http://127.0.0.1:5180". The request has been blocked.

and my probe reported **"frame committed"** — because Chromium serves the CSP refusal from an
opaque-origin error document, which also throws on the location read. The discriminator cannot
distinguish "loaded" from "refused". A connection-reset frame behaves the same way.

So the watchdog would have shipped as a control that looks like protection and detects nothing — the
exact failure class S-17 exists to eliminate, and the reason five defects reached the operator
through green suites. It was removed rather than shipped. What replaced it is the behavioural test
above, which asserts what can actually be asserted.

## Fail-before / pass-after (S-8)

**Fail-before**, for the blank-panel guard. Injected the OP-4 forbidden state into
`refreshTokenCenterEmbed` (fallback hidden unconditionally) and ran the new test:

    AssertionError: 'hidden' unexpectedly found in
    {'class': 'tokencenter-fallback', 'hidden': ''}
    : OP-4 forbidden state: frame hidden AND fallback hidden - a blank panel
    1 failed, 1 passed

**Pass-after** (defect removed): `2 passed in 14.04s`.

**Live pass-after for the refutation** (S-17), shell on 5180 with Token Center READY: the child
frame committed to `http://127.0.0.1:8765/`; Document, styles.css, app.js, `/api/summary?days=14`
and the image all 200; `netFailed` empty; screenshot `D/d1-live-5180.png` shows the panel painted
inside the shell.

## Carried to the operator, NOT fixed here

**D-1-a — Token Center's `frame-ancestors` is hardcoded to port 5180**
(`modules/tokencenter/piggybank.py:36`), while the shell's port is a `--port` argument that merely
defaults to 5180. On any other port the embed is refused for real and the panel goes blank with no
fallback — a genuinely reachable instance of the state OP-4 forbids.

Not fixed here deliberately: it is not in the ENTRY 014 item set; the fix is a coupled cross-module
change (adapter substitution is restricted to `${root}` at `adapter.py:261`, so the shell cannot
inject its own origin without extending the substituter, the adapter, Token Center's header and
their tests); and it is a CSP change, which F-1 is explicitly told not to make casually. Parked with
full costing in `bundles/FIXUP01/PARKED-D-1-a-frame-ancestors-port.md`.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
