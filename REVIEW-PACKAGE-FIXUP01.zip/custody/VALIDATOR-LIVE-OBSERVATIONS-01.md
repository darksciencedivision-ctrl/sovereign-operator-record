# T-2 · VALIDATOR LIVE OBSERVATIONS (partial, pre-empting the T-2 run)
## Seat: validator (claude, cowork) via the desktop browser pane · 2026-08-30T00:35:28Z
## Shell running at 127.0.0.1:5180 from seal `50b47326`, operator present

Measured against the LIVE running product, not the tree. These are observations for the
T-2 seat to absorb and extend, not a substitute for its run.

---

## N-21 · OP-4 Token Center embed does not render — CONFIRMED DEFECT, HIGH

**Both security halves are exactly as specified. The frame simply never navigates.**

Measured from the running pages:

| thing | measured | verdict |
|---|---|---|
| Shell CSP | `... frame-src http://127.0.0.1:8765; frame-ancestors 'none' ...` | correct per OP-4 |
| Token Center CSP | `... frame-ancestors http://127.0.0.1:5180 ...`, no `X-Frame-Options` | correct per OP-4 |
| Token Center standalone | HTTP 200, page fully populated (111,642,778 tokens today, 14-day chart, collector matrix, model attribution) | module is healthy |
| iframe element | present, `src` property = `http://127.0.0.1:8765/`, 887x461, `sandbox="allow-scripts allow-same-origin"` | element exists |
| **iframe contentWindow.location** | **`about:blank`** | **the navigation never happened** |
| iframe document | `readyState: "complete"`, `title: ""`, `body.children.length: 0`, `innerText.length: 0` | empty initial document |
| console | one warning only: sandbox with both allow-scripts and allow-same-origin can escape sandboxing. **No CSP violation reported.** | not a policy block |

**Interpretation.** The OP-4 tests asserted the *policy* — header diffs on both sides, a new
framing test, the 31-test Token Center suite, the 166-test shell suite — and every one of them
passed and still passes. None of them asserted that the frame actually paints. The panel the
operator sees is the exact failure mode the OP-4 spec named as forbidden: a silent empty frame,
with no fallback panel and no error.

Leading hypothesis for the builder, NOT established: the frame is left at its initial
`about:blank` because `src` and `sandbox` are applied in an order that re-initialises the
element, rather than because anything blocked it. The correct-on-both-sides CSP and the absent
violation both point away from a policy block. **Diagnosis is builder work; this record only
establishes that it does not render.**

**Secondary, for the reviewer:** `sandbox="allow-scripts allow-same-origin"` together is an
effectively inert sandbox — the console says so itself. Loopback content the shell already trusts,
so not a vulnerability, but it undercuts the "scoped exception" framing of OP-4's security case
and should be looked at when the render is fixed.

---

## N-22 · llamacpp has disappeared from the shell entirely — CONFIRMED REGRESSION, MEDIUM
## Cause is validator-authored. Owned here.

The running shell lists **five** modules: sovereign, sow, tokencenter, debate, distillery.
`document.body.innerHTML.includes('llamacpp')` is **false** — the string appears nowhere in the
page. Before CLOSEOUT-01 the shell loaded six; the CONVERGE-01 C4 install log records
"Modules loaded: debate, distillery, llamacpp, sovereign, sow, tokencenter".

The likely cause is CLOSEOUT-01 item **X-4 step 4**, which the validator authored: it instructed
the builder to neutralise llamacpp's three foreign absolute paths to a documented placeholder.
The builder executed it as written and verified all six adapters still *compile* — which they do.
Compiling is not appearing. **The validator's item specified a byte change without specifying the
observable behaviour that had to survive it**, and no hermetic gate covers "the module is visible
in the UI."

This also converts **OBS-2** from a question into a finding, and enlarges it: the concern was that
the optional-adapter SKIPPED-WITH-RECORD signal had gone quiet. What actually went quiet is the
whole module. An optional runtime that is not installed should present as *present and
unavailable*, never as absent — the operator cannot act on a module they cannot see.

Not yet established: whether the shell drops the adapter at load with an error, or filters it
deliberately. The shell's own console output in the operator's PowerShell window will say.

---

## OBS-1 · the port tile — APPEARS RESOLVED

The pre-flight band reads `port 5175 free` / `port 8700 free` / `port 5180 shell`. The tile
now names the shell as the holder of its own port rather than reporting it free-and-red. Recorded
as apparently resolved; the T-2 seat should confirm against the original report before closing it.

## Also observed

- **Ollama is not running** — the pre-flight band shows it red with a `urlopen error`, and it is
  the "1 unavailable" of "6/7 available". Expected if the operator has not started it, and it is
  why the cold VRAM baseline is low. Any model-dependent leg is unavailable until it is up.
- **N-14 visual work is live**: the workspace background renders, the dark surface matches the
  target treatment, and the layout is intact at this viewport.
- Distillery reports its snapshot and nine open questions in-card, status only, no compute on
  open — as designed.

## Method limitation

All of the above was observed through the Claude desktop browser pane, not the operator's own
browser. The CSP headers, the iframe's `about:blank` location and the module-id enumeration are
facts about the served pages and are not pane-specific. The operator should still confirm the
blank Token Center panel in Brave or Edge before the finding is treated as closed.

VALIDATOR CLAIM: observations only; no gate submitted; no PASS asserted; no product bytes written.

---

## N-23 · The shell's "Open" is enabled only for the one module that has no open action
## Reported by the operator; root-caused here · CONFIRMED DEFECT, MEDIUM · 2026-08-30T00:46:34Z

**Operator report (verbatim intent):** opening the Multi-Model Terminal from the main UI works —
the app comes up — but the **Open** button does nothing. The operator has to go to the taskbar at
the bottom of the screen and click the window there to bring it forward.

**Measured, live DOM, all four Open buttons:**

| module | `open.kind` in its adapter | Open button state |
|---|---|---|
| SOVEREIGN | `browser` → `http://127.0.0.1:5175/` | **disabled** |
| Debate Table | `browser` → `http://127.0.0.1:8700/` | **disabled** |
| Sovereign Distillery | `browser` → `http://127.0.0.1:5184/console` | **disabled** |
| **Multi-Model Terminal (SOW)** | **`none`** — no URL | **ENABLED** |

All four modules were Stopped at the time of measurement.

**The one module whose adapter declares no open action is the only one whose Open button is
clickable.** `shell/modules/sow.json` sets `"open": {"kind": "none"}`, and `shell/src/states.py:362`
resolves the button's target as `self.adapter.get("open", {}).get("url", "")` — the empty string.
The operator clicks a live button wired to nothing.

**Leading hypothesis, NOT established — builder to confirm.** The enable/disable guard appears to
be driven by the open URL and/or module readiness. A module carrying no open action has no URL for
the guard to evaluate, so it falls through to enabled rather than being excluded. Every module that
*does* have a URL is correctly gated; the one with none escapes the gate entirely.

**This is two defects, and the second is the real one.**

1. **Presentation.** A module with `open.kind: none` must not present an enabled Open control. It
   should be absent or disabled. This is the small half.
2. **Capability.** SOW is an Electron desktop application, not a web surface. The adapter schema
   permits only `browser` or `none` (`shell/src/adapter.py:199`), so even a correctly wired
   button would have nothing to do — there is no mechanism anywhere in the shell to raise or focus
   an existing native window. Making Open genuinely work for SOW requires a **third open kind**
   (focus/raise the launched window), which is adapter-schema plus shell-backend work, not a UI
   tweak. Until then, disabling the button is honest but leaves the operator raising the window
   from the taskbar by hand — which is the workaround they are already performing.

**Why no gate caught it.** Same shape as N-21 and N-22. The adapter schema validates that
`open.kind` is one of two permitted values, and `none` is permitted, so `sow.json` is valid.
Nothing asserts that a control the UI renders is one the shell can actually perform. Three
findings in one session, all of the form *the policy is correct and the product does not do
the thing*.

---

# OPERATOR SESSION 2 — model access, Conductor, SOVEREIGN · 2026-08-30T01:06:27Z

**The headline: three of these five are not defects. They are safety interlocks working exactly as
designed, and the operator has never opened them.** Treating them as bugs would send a builder to
"fix" a deliberate fail-closed guard. Each needs an operator ruling instead.

---

## N-24 · Model picker "0/21 available", every provider DENIED — WORKING AS DESIGNED

The picker reports `live DENIED (fail-closed) — no live-operation config at
...modules\sow\config\live_operation.json (enforcement-by-absence)`.

**That file is deliberately absent and is the operator's authorization switch.** From
`config/live_operation.example.json`, which ships as the template: *"The real file is DELIBERATELY
absent from the repo: a fresh clone is DENIED-by-absence (directive s10.1)."* Every provider row —
claude_code, openai_codex_cli, grok_build, google_antigravity — fails closed until it exists.

**This is not a bug and must not be handed to a builder as one.** It is the interlock that stops
the product spawning billed CLI sessions without the operator personally saying so. Turning it on
is a spend act and collides with **OD-5, currently DENY**.

What the operator needs to know to rule:
- The config cites **exactly one** authorizing register row and receives exactly that row's
  provider set. `OP-6` = claude_code + openai_codex_cli. `OP-12` = those two **plus** grok_build
  and google_antigravity. Naming a Grok provider under row OP-6 **fails closed** — rows do not lend
  each other scope.
- A config may **narrow** (fewer providers, 1 terminal). Any **widening fails closed** — the loader
  raises.
- `terminals_per_subscription` is a global ceiling of 1..2; grok_build and google_antigravity are
  each capped at 1 in code regardless.
- The template warns that naming the OP-12 pair is **not inert**: since 18B the picker offers them,
  the authorizer dispatches them, and they become spawnable and lease-taking.
- The template states the loop itself MAY create/maintain the real file under OP-6 — so this CAN be
  delegated to a builder, but only with the register row named in the operator's ruling.

**Ruling required: OD-31.** Which register row, which providers, how many terminals.

---

## N-25 · No local models anywhere in the picker — GENUINE FEATURE GAP, HIGH

Separate from N-24 and **not fixed by authorizing live operation.** The picker enumerates only
frontier CLI providers. There is no local option of any kind, and local models cost nothing to run.

Measured: `grep -rn "ollama" apps/desktop/*.js` returns **nothing**. The Electron picker has no
local code path at all. Meanwhile `adapters/roster.py` — the Python control plane — has full local
support already: `local_reasoning` (Ollama qwen3:8b/14b, else mock), `coding_node`
(qwen2.5-coder, else mock), with `detect.ollama_models()` doing the enumeration.

**Two subsystems, one of which knows about local models and one of which does not.** The desktop
picker is frontier-only by construction.

The template confirms the wiring was never done: `node.schema@1.1.json` admits `ollama_local`
alongside the frozen eight, but *"no node record for either provider EXISTS, because nothing is
wired to create one yet."*

This is the operator's stated requirement — the picker must be **agnostic**: local models AND
frontier. It is real engineering work in `apps/desktop/picker/`, not a config change.

---

## N-26 · The Conductor cannot be typed in — INTERLOCK, NOT A BUG. ROOT-CAUSED.

Long-standing operator complaint, raised three times, never diagnosed until now.

`shell/src/adapter.py:344-346` — the shell **refuses to load the SOW adapter at all** unless it
sets `SOW_CONDUCTOR_AUTOLAUNCH=0`:
```
if adapter["id"] == "sow":
    if launch["env_set"].get("SOW_CONDUCTOR_AUTOLAUNCH") != "0":
        raise AdapterError("SOW adapter must set SOW_CONDUCTOR_AUTOLAUNCH=0 (H-10)")
```
`modules/sow/apps/desktop/main.js:2942` — the Conductor launches **only when that value is not
"0"**:
```
if (!process.env.SHELL_SELFCHECK && process.env.SOW_CONDUCTOR_AUTOLAUNCH !== "0") { ... }
```
with the comment: *"the pane stays honestly dark."*

**Therefore: whenever SOW is launched from the Sovereign shell, the Conductor is guaranteed not to
start.** It is dark because H-10 — a quota guard — mandates it be dark. The operator has been
trying to type into a pane the shell is required to leave unlaunched.

H-10 exists to stop the Conductor auto-spawning model sessions and burning subscription quota.
Removing it is an operator amendment, not a builder fix; a builder cannot weaken a guard the
adapter schema enforces.

**Ruling required: OD-32.** Amend or scope H-10 so the Conductor can launch under the shell, and
say what quota protection replaces it.

---

## N-27 · SOVEREIGN start fails — readiness probe not satisfied. CAUSE UNDETERMINED.

Operator reports Start and Run Startup Test both fail with health check failed / readiness probe
not satisfied.

Established: `.venv/Scripts/python.exe` **exists**; the `sovereign_product` package **exists**;
the probe target `/v1/health` **exists** at `server.py:1906`, with 45s timeout and 500ms poll.
So the obvious explanations are all eliminated.

**Cause not determined and not guessed.** The next evidence is the shell's own **Logs** button on
the SOVEREIGN card, which will carry the server's stderr. Recorded as open with a named next step.

*Validator note: an earlier draft of this entry stated that `/v1/health` did not exist in the
server source. That was wrong — the grep ran from the wrong directory — and was retracted before
it was recorded. Noted here because a false root cause sends a builder somewhere real defects are
not.*

---

## N-28 · Debate has no model access — HOST STATE, then the N-25 gap

Debate opens and starts on command but reaches no models. **Ollama is not running on this host** —
the shell's pre-flight band shows it red with a `urlopen error` and it is the "1 unavailable" of
"6/7 available". Local model access cannot work until Ollama is up; that is host state, not a
product defect.

Beyond that, the operator requires Debate to reach frontier providers too. That is the same
capability gap as N-25, in a second module.

---

## OP-7 (NEW FEATURE REQUIREMENT, operator-stated) · model agnosticism across modules

> "it needs to be agnostic where it has local accessibility and our frontier access, our grok, our
> Claude, ChatGPT... and also that needs to be the same for sovereign."

SOW, Debate **and** SOVEREIGN must each offer local models and frontier models from one selector.
Today: SOW's picker is frontier-only and fail-closed; Debate is Ollama-only; SOVEREIGN carries its
own model list under SYSTEM_MANIFEST authority (M-6) with a loopback-only Ollama client. This is a
cross-module capability, it overlaps the existing **OP-2** frontier-provider dossier, and it is
gated by the same spend and key-custody rulings.

**This is a feature program, not a punch-list item.** It should be scoped and costed before any
builder touches it.

---

## The pattern across this whole session

Six findings, three shapes:

1. **The policy is correct and the product does not do the thing** — N-21 (frame never paints),
   N-22 (adapter compiles but vanishes), N-23 (control rendered that the shell cannot perform).
   Every gate green.
2. **The interlock is working and nobody opened it** — N-24, N-26. Not defects. Operator rulings.
3. **Genuinely unbuilt** — N-25 and OP-7: local models were never wired into the desktop picker.

Only category 1 is a defect in the ordinary sense. Category 2 would be actively damaged by
"fixing" it.

---

## N-25 · VALIDATOR SELF-CORRECTION · 2026-08-30T02:47:34Z

My N-25 entry said: *"the Electron picker has no local code path at all."* **That was too strong
and is corrected here.** The evidence I cited — `grep ollama apps/desktop/*.js` returning nothing
— was true but did not mean what I claimed. The picker's option list is not built in JavaScript.

`modules/sow/control_plane/nodes/pane_picker.py` is the picker's data layer, and it does have a
full local path: *"the operator's entire local model list enumerated live from `ollama list` …
Local models route through the VRAM residency planner; the picker shows residency state
(resident / loading / awaiting-eviction)."* The Electron surface renders the JSON this module
produces; it was never supposed to contain enumeration logic.

Further, local availability is an **authorization gate**, not just display. Per that module's own
docstring: *"17B promoted the residency planner from a display chip into an AUTHORIZATION gate:
when this host's VRAM budget cannot be established, `worker_pane_spawn` refuses every local pane."*

**Revised reading.** The symptom stands — the operator saw no local options. The likely causes are
now (a) Ollama is not running, so `ollama list` enumerates nothing and there is nothing to offer
or grey out, and/or (b) the VRAM residency budget could not be established, so the admission gate
covers every local pane. Both are consistent with what was on screen. **N-25 may substantially
resolve once Ollama is running**, and the remaining gap may be far smaller than "no local support."

**Effect on FIXUP-01: none required.** Directive item D-5 already instructs the builder to
establish whether local enumeration is *absent entirely or present-but-gated* before F-5 changes
anything, and F-5 is explicitly scoped by D-5's finding. The directive was written correctly
despite my diagnosis being partly wrong — because it told the builder to measure rather than to
accept my reading. Recorded so the builder does not chase a gap that is not there.

**Related, and verified:** the product has VRAM awareness in seven modules but **no GPU device
pinning anywhere** — no `CUDA_VISIBLE_DEVICES`, `main_gpu`, `tensor_split` or `num_gpu` in
any product file. On a multi-GPU host the residency planner would see one aggregate budget and
placement would fall to the Ollama daemon. Not a defect on this single-GPU host; a real design gap
for any larger machine. Filed as **OBS-3**, forward-looking, no action this run.
