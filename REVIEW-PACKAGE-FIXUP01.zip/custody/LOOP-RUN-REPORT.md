# LOOP-RUN REPORT — SWS-REM-DIR-20260828 R2
## RUN 01 + RUN 02 · 2026-08-28

**Authorization:** OPERATOR-INSTRUCTIONS.log ENTRY 001 (2026-08-28T01:36:53Z)
+ ENTRY 002 (2026-08-28T04:52:46Z; log SHA-256
`2744f341eac4b6fa73c259388843d1cad54d1c49e8e48479cd8eab9dcc0ea095`).
Directive `9061c2e8…` · Annex A `acae8fb8…` · candidate SYSTEM `75e4be07…`
· rollback RESET `00ae9eef…`.

**Seats:** RUN 01 BUILDER qwen3.8-max (deepseek) · RUN 02 BUILDER grok-4.6
(opencode harness) · REVIEWER chatgpt · VALIDATOR claude (cowork) ·
OPERATOR sam.

**Worktree:** `D:\producttion software 2\release-worktree` HEAD `5a52946`.
All product work **CANDIDATE**. No reviewer PASS. No gate submitted.

---

## 1. Commit chain (21 commits)

```
cf50cde  P0-2 initial worktree from SOVEREIGN_SYSTEM_BASELINE_20260827.zip
cbaabe7  B1-1 (C-1): remove packaged runtime state; packaging allow-list gate
29f4dc9  B1-2 (H-3, M-1 Option A): per-process CSRF token
3ad0720  B1-3 (H-4): import FAILED; start-worker failure regression
f1d9304  B2-1 (C-2): correct sovereign source hash; preserve defective record
66e43b5  B2-2 (C-3): current provenance debate/sow/distillery + RELEASE-MANIFEST
10679bf  B2-3 (M-1 full): exact-origin, bodyless mutation guard, security headers
d7441dd  B2-4 (M-3): renderer.js innerHTML classification + esc() + audit gate
9567d48  B2-5 (M-5): strip BOMs from six governance JSONs; fix re-BOM writer
5b29a2e  B2-6 (M-6): README_PRODUCTION + model_hierarchy → SYSTEM_MANIFEST
7b7431f  B2-8 (M-9): Distillery serve.py Host + CSP + nosniff
bf855e7  B3-1 (H-1): session-manager admission-before-spawn
274bb2f  B3-2 (H-2): Electron ^31.0.0 → ^43.4.1
ef47226  B3-3 (M-4): bounded pids() polling teardown
6c7ec99  B3-4 (M-7): fail-on-undeclared ok:false; waiver kinds
73862d0  R-1 (AUD-1): server.py UTF-16 LE → UTF-8 no BOM
e7bd97e  B3-5 (M-8): T2 harness-config-injection tests + THREAT_MODEL status
613811d  B3-6 (L-2): pytest.ini 2382/0/1 host-coupled
1c023c9  B3-6 (L-3): README Debate v1.2.1-hardening
22f8328  B3-6 (L-6): strip BOMs from 15 active .py
5a52946  B3-6 (L-1): .cmd-shim metacharacter refusal
```

B2-7 = OD-20 dossier only, correctly uncommitted. Run 01 halted at `6c7ec99`
on harness quota (HTTP 429), not an E-class exception.

---

## 2. Item register (CANDIDATE / PARKED)

### Phase 0
| Item | Status | Notes |
|---|---|---|
| P0-2 worktree | CANDIDATE | `cf50cde` from SYSTEM ZIP 75e4be07… |

### Batch 1
| Item | Punch | Status | Commit |
|---|---|---|---|
| B1-1 | C-1 a/b/c | CANDIDATE | `cbaabe7` |
| B1-2 | H-3 + M-1 Option A | CANDIDATE | `29f4dc9` |
| B1-3 | H-4 | CANDIDATE | `3ad0720` (encoding later repaired by R-1) |

### Batch 2
| Item | Punch | Status | Commit |
|---|---|---|---|
| B2-1 | C-2 | CANDIDATE | `f1d9304` |
| B2-2 | C-3 | CANDIDATE | `66e43b5` |
| B2-3 | M-1 full | CANDIDATE | `10679bf` |
| B2-4 | M-3 | CANDIDATE | `d7441dd` |
| B2-5 | M-5 | CANDIDATE | `9567d48` |
| B2-6 | M-6 | CANDIDATE | `5b29a2e` |
| B2-7 | H-5 / OD-20 dossier | CANDIDATE (bundle only) | no commit |
| B2-8 | M-9 | CANDIDATE | `7b7431f` |

### Batch 3 + resume
| Item | Punch | Status | Commit |
|---|---|---|---|
| B3-1 | H-1 | CANDIDATE | `bf855e7` |
| B3-2 | H-2 | CANDIDATE | `274bb2f` |
| B3-3 | M-4 | CANDIDATE | `ef47226` |
| B3-4 | M-7 | CANDIDATE | `6c7ec99` |
| R-1 | AUD-1 | CANDIDATE | `73862d0` |
| B3-5 | M-8 / T2 | CANDIDATE | `e7bd97e` |
| B3-6 L-2 | L-2 | CANDIDATE | `613811d` |
| B3-6 L-3 | L-3 | CANDIDATE | `1c023c9` |
| B3-6 L-6 | L-6 | CANDIDATE | `22f8328` |
| B3-6 L-1 | L-1 | CANDIDATE | `5a52946` |

### Held / not in this loop's implementation queue
| Item | Status | Why |
|---|---|---|
| H-5 implementation | PARKED | OD-20 cannot default; dossier at `bundles\BATCH2\OD-20-LINEAGE-DOSSIER.md` |
| H-6 composed-system proof | PARKED | live combination; Phase-8 / T-2 |
| H-2 live UI band | PARKED | E-5 display |
| Service-launch legs | PARKED | E-5 / OD-4 → T-2 |
| Punch §5 closed set | CLOSED | not reopened |

---

## 3. Measured totals (bytes / this-loop runs)

**Run 01 (validator-audited):** C-1 removals + packaging gate 29/29; CSRF 6/6 +
piggybank 5/5; H-4 3/3 then AUD-1 encoding defect; provenance 7/7 + 13/13;
tokencenter hardening 26/26 / full 31/31; innerHTML 12/12 + desktop 1104/1104;
BOM guard 5/5; model consistency 5/5; Distillery 12/12; H-1 23/23 + 1104/1104
+ U186 37/37; Electron 43.4.1 ABI 148 + 1104/1104; M-4 15.122 s → 0.120 s;
M-7 8/8. OD-20 diff: 1511 matching / 167 differing / 1902 SYSTEM-only /
234 RESET-only.

**Run 02 (this seat, measured):**
- R-1: encoding FF FE + 18781 NUL → UTF-8 18785 B, 0 NUL, ast.parse OK;
  H-4 **3/3**; states 16 tests 1 pre-existing FAIL; B1-3 subset **79 tests,
  13F+6E, 0 server.py import errors**.
- B3-5: host 3.14 **3 passed / 1 skipped**; py -3.12 **4 passed**.
- L-2: ini loads; 2382/0/1 HOST-COUPLED comment; full-suite rerun **[U]**.
- L-3: one README cell.
- L-6: 15 BOM strips; 13 imports OK; `cycle_runner_v3` missing `research`
  (pre-existing).
- L-1: **17/17** cmd-shim tests (3.14 and 3.12).

---

## 4. Files written (run 02 product + bundles)

Worktree commits as §1. Bundles under `release-planning\bundles\`:
`BATCH3\R-1-AUD-1\`, `BATCH3\B3-5\`, `BATCH3\B3-6-L1\` `L2\` `L3\` `L6\`,
`BATCH3\BATCH-REPORT.md`, this file. Custody directive/log/punch/audit
files not mutated. Frozen ZIPs not re-cut. `D:\Product Software\` untouched.

---

## 5. Consolidated T-2 operator queue

Physical / attended / environment items accumulated for the single T-2
session. Not builder work.

1. **Live Electron UI band** (B3-2 remainder) — sandbox, context-isolation,
   navigation (`will-navigate`, `setWindowOpenHandler`), window-on-display.
   Headless 1104/1104 already green; live BrowserWindow needs the operator
   display (E-5).
2. **Service-launch legs** G34 / G35 / G53 / 9d / 9f — SOW, Distillery,
   Token Center start/open (OD-4 / E-5). Stay NOT_RUN-with-cause until T-2.
3. **MT-09 signature** (OD-3) — physical act.
4. **G26 attended debug** (OD-16c) — physical act.
5. **OD-20 ruling** on `bundles\BATCH2\OD-20-LINEAGE-DOSSIER.md` — H-5
   canonical lineage; implementation waits on this ruling.
6. **jsonschema-gated security legs** — B3-5 profile-loader leg skips on
   host Python 3.14 (`importorskip`); **4/4 on py -3.12**. Host-python
   parity needs sow venv provisioning (E-6 environment). No pip-install
   into host Python (write boundary).
7. **OD-21** already defaulted prospectively (BOM-free at re-cut); L-6
   applied that default to the 15 active worktree `.py` files. Frozen
   Debate ZIP not re-cut. Staging duplicate under
   `dev/v1.2.1-hardening/release/staging/` still BOM'd (not in the 15).
8. Standing reviewer backlog (not T-2 physical, but still open): 19
   CANDIDATE gates + Gate-5/5b unadjudicated. Builder wrote no PASS.

Punch List v2.1 §5 closed items remain closed.

---

## 6. Defects found and repaired mid-loop

**AUD-1 (HIGH, validator run-01):** `shell/src/server.py` committed UTF-16
LE at `3ad0720` via PowerShell 5.1 redirection. Repaired R-1 `73862d0`.
Content including H-4 `FAILED` import intact. Discipline: never restore
source via PowerShell redirection / Set-Content.

---

## 7. Loop exit

Queue R-1 → R-5 exhausted. Annex A E-6 (queue exhausted / authorized
batches complete) except T-2 physical/parked items above. No E-1 money,
no E-2 out-of-bound writes, no E-3 halt, no E-4 security regression.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.

---

# BATCH 4-E — 2026-08-28

Queue completed in the mandated order through terminal item P-D3. Nine commits advance `5a52946` to `a945d99`: P-D2, N-15, N-11, P-D4, P-D5, P-D6, N-13, N-14, P-D3.

Candidate closures: P-D2, N-11, P-D4, P-D5, P-D6, P-D3. Parked with measured dossiers: N-15 (two unrelated targeted shell failures), N-13 (three absent llama.cpp targets caused atomic refusal), and N-14 (full shell suite cross-component drift; screenshot parity queued T-2).

The terminal staged tree `0a1f60b4e2a454ce332e90a558becc427e6c1d13` produced a 3,530-file clean archive. Package boundary measured 0 violations and 0 credential hits; provenance, release-manifest, governance-BOM, model-consistency, and innerHTML gates all returned zero failures; the full release-tool aggregate passed 68/68. Final product commit: `a945d997617b43251d600ef63ac459d2f72e01fb`.

Any batch that changes module bytes ends with provenance/manifest regeneration and a full gate re-run; a manifest generated before the last byte change is stale by definition.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.

---

# CONVERGE-01 — 2026-08-29

Seat: grok-4.6 (opencode) under ENTRIES 006-009. Independently verified C0-C4 prior work, finished the interrupted C4 proxy cycle, ran C5 hermetic suites/gates, and sealed C6.

Worktree commits added this seat: annotated tag rel/shell/1.0.0-rc.1 on a45fb98; product commit 32f191e (C6 provenance/identity/manifest). C4 proxy cycle produced no tracked-byte change.

Measured: SOW desktop 1104/1104; terminal 225/225; Token Center 32/32; shell 166/166; C4 uninstall exact-set 24468 paths; C6 release-manifest check problem_count 0.

Parked: SOW pytest (unpinned ranges); Distillery Python lock missing; Debate/SOVEREIGN/Distillery live/Ollama legs; clean-room VM.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.


---

# CLOSEOUT-01 — 2026-08-29

Seat: claude-code (opus-5) under ENTRY 010, envelope corrected by ENTRY 011. Directive
`CLAUDE-CLOSEOUT-01-DIRECTIVE-20260829.md` sha256 `67753c34…1537c5`. Re-derived the CONVERGE-01
seal audit from bytes in PHASE W before fixing anything, then ran X → Y → Z to convergence.

Seven commits advance `32f191e` to the new seal `50b47326f91c5abab8b6d5250d59b1dba96a4d46`:
X-1 (`e5cd39d`), X-2 (`3d298c4`, `a3fed64`), X-3 (`6daed6d`), X-4 (`9110390`), X-5 (`be8dcb0`),
Z seal (`50b4732`). First commits in this program attributed to this seat (A-5 remedied at BOOT;
no existing commit's authorship was rewritten).

**Phase W did not rubber-stamp the audit.** A-1, A-3, A-4 and the mechanism behind N-18 reproduced
exactly. Three corrections were issued against inputs: A-2's "69 entries each" is not reproducible
(measured 33 members / 28 files per root — the finding stands, the number does not); A-1's gate
blindness is wider than reported (three unchecked sections, 25 of 80 hash objects, not one section
and 17); and N-18's population is far larger than its five named files (107 files carry the
username, 264 carry `Product Software`, overwhelmingly historical evidence that R2 §4/§8 forbid
rewriting), which makes X-4's pass-after criterion 5 unsatisfiable as written. Two directive
defects were caught before they produced a false "done": the pattern `*.pre-add08` matches nothing
(the target file carries it as an infix), and `llamacpp.json`'s `argv[0]` is a native server binary,
not an interpreter, so the blanket `/launch/argv/0` rule would have broken that adapter.

Candidate closures: X-1 (manifest circularity broken, checker hardened per S-15 and proven to fail
on four tamper classes), X-2 (spike excluded — 0 archive entries, closing
C2-RISK-SPIKE-ELECTRON-LOCK-HELD-NONPRODUCT mechanically), X-3 (13 backups excluded, all still
tracked), X-4 steps 1/2/4, X-5 (identity convention recorded and tested).

Parked with dossiers: X-4 step 3 — every Python 3.12 on the build host lives under a per-user
`C:\Users\<user>\` path, so no username-free path is also a working interpreter, and the only
workaround would reopen the N-16 defect; the SBOM/spike over-declaration; and the module release
tags, which no longer identify the archives now cut from the seal.

Measured at the seal: SOW desktop 1104/1104; terminal 225/225; Token Center 32/32; shell 166/166
with S-5 restoration hash-verified; tools/release 84/84 (72 at `32f191e`, +12 this loop). Package
boundary PASS on a cold extract of the sealed source archive (3497 scanned, 0 violations, 0
credential hits); release-manifest, governance-BOM, model-consistency and innerHTML gates all PASS.
Archive delta 3565 → 3497 accounted item by item with zero unexplained entries. C4 proxy cycle
re-run end to end: install 24,402 paths, verify 21,633 hashes, HTTP 200 on loopback, clean stop,
uninstall with 0 remaining. All 8 artifacts and 8 sidecars cut AFTER the seal and cold-extract
verified against the untracked build manifest.

**Two new findings, both raised against the inherited seal, neither fixed:** N-19,
`shell/BUILD-MANIFEST.txt` is stale (19 of 67 hashes wrong, 8 files omitted); and N-20,
`provenance_cross_hash_check` FAILS at `32f191e` because that commit added
`INSTALL-PROVENANCE.json.pre-CONVERGE01` *inside* three of the directories its own provenance
records digest — A-1's mechanism a third time. Phase Z repaired the half within scope: provenance
is now reproducible from the commit it names. Refreshing the stale registry declares three modules'
source identity and is an operator act.

Lesson for the next seat, the same one three findings now share: a record must not live inside the
set it describes. A tracked manifest cannot carry the hash of an archive it enters; a provenance
record cannot digest a directory it is backed up into; a build manifest cannot enumerate itself.
Cut the artifact after the seal, and keep the hash in a file that is not an input to the thing
hashed.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.

---

# FIXUP-01 — builder `claude-code (opus-5)` · ENTRY 014
## Parent seal `50b47326` → seal `8d9f5d2415599eeb0b71dc85a25a36469b41641e` · 8 commits

The directive's premise was that five defects reached the operator through fully green suites, so
the acceptance bar is behaviour and not a passing test. Phase D applied that bar to the findings
themselves. **Four of six did not survive independent reproduction as written.**

N-21, the HIGH item — "the Token Center embed never renders, the frame sits at `about:blank`" — is
**REFUTED**. Driven from a real browser over CDP with Token Center running on the default port, the
child frame commits to `http://127.0.0.1:8765/` and loads its document, stylesheet, script,
`/api/summary?days=14` and image, all 200, nothing blocked, and the panel paints. The measurement
that settles it: reading `contentWindow.location.href` throws a **cross-origin** SecurityError,
which is positive proof of navigation — a frame still on `about:blank` is same-origin with its
parent and reads back cleanly, which is exactly what the original observation recorded. That
observation was taken through a browser pane rather than a browser, and its own report asked for
confirmation in Brave or Edge first. The OP-4 fallback the directive said did not exist also
exists, and was measured working.

N-25, the other HIGH — "the Electron picker is frontier-only by construction, no local code path at
all" — is **REFUTED as written**. Its evidence was `grep ollama apps/desktop/*.js`, a non-recursive
glob that cannot see `apps/desktop/picker/`. A complete local path exists: `ollama_local` is a
provider row, `counts.local` is a field, and hermetically — with **no `live_operation.json`** — the
picker enumerates three local options. That also answers the directive's S-18 question: local
selection is **not** gated behind the spend switch, so no park was needed.

N-22's stated cause is **REFUTED** — CLOSEOUT-01's X-4 is exonerated. `git log --all -S"llamacpp"`
over `shell/src` and `shell/static` returns no commits at all: the UI never listed it, while the
backend has always loaded six. N-23's state table is wrong (with everything stopped, every Open is
disabled), though the defect is real and was reproduced in the state the operator actually hit.

**Two were verified and fixed.** N-23 in both halves, neither parked: `can_open()` now follows
capability, and a third `open.kind: focus_window` with `POST /api/open` raises SOW's desktop window
by resolving its Job Object to the full pid set — the operator no longer uses the taskbar. N-27 was
root-caused for the first time: `probe.py` set each readiness request's socket timeout to
`min(5, poll_ms/1000)`, giving SOVEREIGN's `/v1/health` 0.5 s to answer something that takes 1.25 s.
It could never pass at any `timeout_s`, which is why lengthening the timeout — the S-12 error the
directive forbids — would also not have worked. SOVEREIGN now reaches READY in about 5 s.

Measured at the seal: SOW desktop 1104/1104; terminal 225/225; Token Center 32/32; shell **188**
(166 + 22 added, itemised) with S-5 restoration hash-verified; tools/release 84/84. Package
boundary PASS on a cold extract of the sealed source archive (3503 scanned, 0 violations);
release-manifest, governance-BOM, model-consistency and innerHTML gates PASS; provenance cross-hash
RED per OD-27, expected and untouched. Archive delta 3497 → 3503, +6, every one a test file. All 8
artifacts and 8 sidecars cut AFTER the seal, cold-extract verified 8/8, every zip comment naming
the seal.

**Four new findings, none fixed:** N-29, SOW writes its readiness receipt into the *tracked* tree,
so normal use dirties the candidate — N-16 recurring in a lane its fix did not cover. D-1-a, Token
Center's `frame-ancestors` is hardcoded to port 5180, so the embed is genuinely refused on any
other port and goes blank with no fallback. `build_release.ps1` re-cuts only the two composite
archives and inherits the six per-module ZIPs, then records their inherited hashes as
authoritative — all six were found stale at this seal and re-cut by hand. And
`RELEASE-MANIFEST.json` describes the worktree rather than the release: it enumerates two gitignored
build artifacts and OD-26-excluded backups, so its checker cannot pass against an extracted archive
(12 problems, identical at the parent seal).

Two things this seat built and then removed, recorded because the removal is the point. A
client-side watchdog meant to catch a non-rendering embed reported "committed" against a frame the
console showed was CSP-refused — Chromium serves the refusal from an opaque origin, so the location
read throws there too and the check cannot tell loaded from refused. It would have shipped as a
control that looks like protection and detects nothing. And F-6's own DOM-level capability guard
passed while N-23 was injected, because on a cold shell every module is STOPPED and the defect only
appears in READY; found by injection, closed with a state-independent sweep.

Lesson for the next seat: **the finding is evidence, not a verdict.** Four of six here were wrong in
the part that told a builder where to look, and two of the four were wrong because of how the
evidence was gathered — a non-recursive glob, and a browser pane standing in for a browser. Every
one was cheap to check and expensive to have believed. Reproduce from bytes and from the running
product before changing anything, and when the reproduction disagrees, say so.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
