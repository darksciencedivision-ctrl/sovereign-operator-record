# V-9 assertion inventory — commit e2e8e55 (OD-23)

Subject: every assertion `e2e8e55` changed across the seven shell test files.
Status: recorded for reviewer under OD-23. Neither extended nor reverted (S-13).
HEAD examined: `a45fb98`. Parent of inventory commit: `e2e8e55^`.

| file | old | new |
|---|---|---|
| shell/tests/test_failure_classes.py | no wait-after-terminate in `test_health_check_induction` finally | added `fx.wait(timeout=10)` with kill fallback on `TimeoutExpired` (cleanup, not a product assertion) |
| shell/tests/test_failure_classes.py | `unittest.main()` with no trailing newline | `unittest.main()` with trailing newline |
| shell/tests/test_hardening.py | `raw = json.load(open(os.path.join(..., "modules", "sow.json"), encoding="utf-8"))` | `with open(path, encoding="utf-8") as f: raw = json.load(f)` (resource hygiene; assertion body unchanged) |
| shell/tests/test_render.py | H-17 header: "the disabled Distillery controls" | "the runnable Distillery controls" |
| shell/tests/test_render.py | `for act in ("start", "stop", "open", "test"): self.assertTrue(dist.get(act, False), "distillery {} not disabled")` | `self.assertFalse(dist.get("start", True), ...)`; `self.assertFalse(dist.get("test", True), ...)`; `for act in ("stop", "restart", "open"): self.assertTrue(dist.get(act, False), "distillery {} unexpectedly enabled while STOPPED")` |
| shell/tests/test_render.py | RESULT text: "Distillery controls disabled" | "Distillery STOPPED controls are state-correct" |
| shell/tests/test_shell.py | `body = {"id": "distillery", "pad": "x" * 8000}` then `self.assertIn("no runtime", text.lower())` | `body = {"id": "nope", "pad": "x" * 8000}` then `self.assertIn("unknown module", text.lower())` |
| shell/tests/test_shell.py | `test_start_distillery_refused`: POST start distillery → 400 / "no runtime" | replaced by `test_distillery_is_declared_runnable`: `adapter["state_class"] == "runnable"` |
| shell/tests/test_states.py | `test_distillery_is_not_started`: `r.state == "NOT_STARTED"`; `can_start()` allowed False / status 400 | `test_distillery_is_stopped_and_startable`: `r.state == "STOPPED"`; `can_start()` allowed True / status 200 |
| shell/tests/test_tokencenter_loopback_and_csrf.py | `self.assertIn("Origin required", self.t)` | `self.assertIn("Origin must exactly match the serving origin", self.t)` |
| shell/tests/test_zz_evidence.py | `ok = n in stdlib or n == "shell"` | `ok = n in stdlib or n in {"shell", "modules"}` |
| shell/tests/test_zz_evidence.py | "non-stdlib, non-shell import(s)" | "non-stdlib, non-first-party import(s)" |

HELD product bytes (byte-identical to frozen RESET baseline ZIP, not acted on):

- `modules/sow/control_plane/canonical_registry.py` sha256 `88c2362ad731d2e433beabc65329ab75f44349a70e2493671903bcc5b6df4161`
- `modules/sow/adapters/local/llamacpp.py` sha256 `b2484b887ca4087070ffbdbb8abc86b88fe58d63c5c2aa4ae5d15009ce418b29`

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
