# C0 notes

ENTRY 007's inventory matched exactly. UI work product, generated manifests, and runtime output were kept as separate classes. The two manifest artifacts are restored from `a945d997` and will be regenerated only in C6. The four Token Center startup records are preserved byte-exact under `runtime-evidence-preserved/` before their worktree copies are removed.

N-16 relocates future startup-test records to `.runtime/evidence/startup-tests/`, a gitignored runtime lane. The package-boundary policy rejects `.runtime/` if it is ever present in an archive, and regression coverage proves both the destination and archive boundary.

The mandated full shell suite exposed the previously recorded 134/31 split. The failures were not caused by C0: shell tests referenced CP-M1 implementations absent from `modules/sow`, while the protected `D:/Product Software/Production Workspace/modules/sow` tree retained the matching implementation bytes. C0 reconciles only the ten files named by those failures. `main.js` source hash `1bb351ee013e4404d0e086437d3ad351ea60d1779da2460e85b294ab6ff39b9f` also matches the already-tracked frozen proof `evidence/cpm1/8c/frozen/main.js`. Later candidate hardening from commits `bf855e7` (admission-before-spawn note) and `d7441dd` (escaped renderer sinks) is reapplied after the source reconciliation and reverified by its existing gates.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
