# C0 N-14b constraint verification

- Full tracked diff read: the UI product changes are confined to `shell/static/app.css` and `shell/static/workspace-bg.svg`; `shell/static/workspace-bg-v2.png` is the new local bitmap. The other tracked diffs were generated manifests and are not adopted.
- Served PNG: 1,524,053 bytes; SHA-256 `145bed188ab2402899b108f3599001737c4e1d88546710e172fcfbf06822c1eb`.
- Asset references: `app.css` has one asset URL, `/static/workspace-bg-v2.png`. The SVG uses only internal `url(#...)` paint/filter references. Its `http://www.w3.org/2000/svg` string is the XML namespace identifier, not a fetched asset. The PNG contains no pullable references.
- Header-emitting code: `shell/src/server.py` worktree and HEAD blob IDs both equal `06d0e409ada542a03cc0e1c8d3d7b7e03e357b94`; the CSP and all security-header bytes are unchanged in C0.
- Behavior surface: `shell/static/app.js` worktree and HEAD blob IDs both equal `90bdbe89358373b7488e37a12ff08c3a89ae9833`; `shell/static/index.html` both equal `c43bd8bba64331d28e25690c3890cafae619052e`. No backend, route, template, or JavaScript behavior change is hidden in the adopted diff.
- Presentation: the CSS changes only sizing, spacing, background presentation, and responsive layout. Existing focus/keyboard markup and behavior are untouched. Contrast and rendered-DOM assertions are exercised by the shell suite before C0 closes.

Status: candidate adoption, subject to the measured shell-suite record.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
