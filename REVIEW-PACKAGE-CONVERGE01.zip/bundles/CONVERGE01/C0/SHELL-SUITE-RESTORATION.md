# C0 shell-suite restoration inventory

Source root (read-only): `D:/Product Software/Production Workspace/modules/sow`

| Path | Candidate before SHA-256 | Reconciled source SHA-256 |
|---|---|---|
| `apps/desktop/main.js` | `e334706c543d7b7c1bc9b88443d87fa218edc7dbb5fbe1702517e9382aa30ba7` | `1bb351ee013e4404d0e086437d3ad351ea60d1779da2460e85b294ab6ff39b9f` before reapplying B3-1 comment coupling |
| `apps/desktop/preload.js` | `fbd8c053a1bb323ac2fdca22523e74457dfbf695737b881c5a082b4ab19af83a` | `ac21ced569683d479390141c3366f736ad4c76dc44bb90d1d6058e31eb50561e` |
| `apps/desktop/renderer/index.html` | `bcb30769491a928f74ace92519cd97848a387f7efa09e39434b01b934f9ba4a3` | `da94fb60d999dbae07a2b267c217b6b7a7b208442ce7f857e363f1a28aec0a7e` |
| `apps/desktop/renderer/renderer.js` | `cb3cbe03bef755f8826b2e1143ceebe602b6c94d8a6d5de83b4e2eea7d55b1f3` | `75d88bc5e8c774991170e6dc2dbe1a3bff4619b763da97db5d2d82c5001c84d4` before reapplying B2-4 sink escapes |
| `apps/desktop/picker/worker-spawn.js` | `b1c22f94cd204d20834e2593735e6806fad89ad380a4212929ad4c4385849beb` | `f3b405126424d1a0b55cb3d95e03ccf5fc3cfcdf78218f7432eded6238a90c55` |
| `apps/desktop/control/operational-state.js` | `0b57c358f14b32fe3f485719d0a8ab70e862a9c5344ac00f590bf6d6c4965ac5` | `1ae8e8616448c8d23a9169dbce357af945c9f0664eac00e32d06dc9b4621bc059` |
| `control_plane/canonical_registry.py` | missing | `88c2362ad731d2e433beabc65329ab75f44349a70e2493671903bcc5b6df4161` |
| `schemas/deployment-manifest.schema.json` | missing | `1bd1311402907c8429cd5f4d416fa2fba8ab78f964b57a132b0497872b482f2c` |
| `adapters/local/llamacpp.py` | missing | `b2484b887ca4087070ffbdbb8abc86b88fe58d63c5c2aa4ae5d15009ce418b29` |
| `adapters/base/backend.py` | `92383aa3fc8795da1b5c5d5caea05f85bda7b2a42ed10a358b0a79f33056c242` | `83609dfb9dcab042bb87edb0bc0a276a5aedea9695e61fc4bf7ad26f6bcf2cec` |

The protected source is read only. No service, provider, model, or package manager is invoked by this reconciliation.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
