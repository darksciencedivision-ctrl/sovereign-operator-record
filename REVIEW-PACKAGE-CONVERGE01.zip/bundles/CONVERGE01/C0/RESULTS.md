# C0 measured results

- UI adoption commit: `1f0a59cd8b32c0bcea2296fe6c2a3bb91a63b020`.
- N-16 commit: `65bd58fd9ff5ecf0992d98f134fb48abc89966a0`.
- Shell-suite source reconciliation commit: `e2e8e550425f303a6d8789ef7a6cbda92ade2a87`.
- N-16 plus package-boundary focused suite: 32/32.
- Previously failing shell subset after reconciliation: 32/32.
- Full shell suite at final C0 bytes: 165/165 in 94.154 seconds; no warnings.
- InnerHTML sink audit after renderer reconciliation: 112 interpolations classified, zero unjustified.
- Pane-input mutation harness: clean baseline green, all 37 mutations caught, `main.js` restored byte-identical at SHA-256 `8b6ea9a678dbe7f6a19c03761c8cd41978d933ec865978081171fd0cdce425ea`.
- R-5 restoration applied after every shell-suite/render invocation; final worktree porcelain empty.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
