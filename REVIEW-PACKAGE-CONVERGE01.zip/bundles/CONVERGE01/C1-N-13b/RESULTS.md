# C1 N-13b — Candidate Adapter Rebase

Date: 2026-08-29

## Result

- `llamacpp` is declared in `shell/config/install.json` as an optional adapter.
- Missing mapped targets remain a hard, atomic refusal for every non-optional adapter.
- A missing optional adapter is excluded as a unit and emits `SKIPPED-WITH-RECORD` with all missing targets.
- The candidate rebase updated Debate, Distillery, SOVEREIGN, SOW, and Token Center.
- llama.cpp retained its original paths because its three mapped targets are absent.
- The second candidate execution returned exit 0 and ended with `NO-OP`.
- No service or model was launched.

## Candidate skip record

```text
SKIPPED-WITH-RECORD llamacpp: missing target(s): D:\producttion software 2\release-worktree\runtime\llama.cpp; D:\producttion software 2\release-worktree\runtime\llama.cpp\current\llama-server.exe; D:\producttion software 2\release-worktree\runtime\llama.cpp\test-models
```

## Verification

```text
py -3.12 -B -m unittest tools.release.test_rebase_adapters -v
Ran 4 tests in 0.651s
OK

rg (excluding *.pre-rebase) found old roots only in shell/modules/llamacpp.json at lines 6, 13, and 19.
git diff --check: clean
```

## Preserved pre-rebase SHA-256

```text
5f57918f7785e25282a276d27569f602812eb74b857ba4e27107f44f67c4537e  shell/modules/debate.json.pre-rebase
661d36050de163ffd6a0558d32aa0977110c4e25c8bc6e29d78fe5a5a10e5c05  shell/modules/distillery.json.pre-rebase
28d83596d006d1c92115b999fe7fbca17400533e83ad3aea18f245cde7e5de80  shell/modules/sovereign.json.pre-rebase
b2419a9f10afac0e258195498864221eea6aae09783203a87cc4465c0eefdc21  shell/modules/sow.json.pre-rebase
94678a9688586a797c2295017181de49ae7840ac2df4d2fd475ec2404a6f7efb  shell/modules/tokencenter.json.pre-rebase
```
