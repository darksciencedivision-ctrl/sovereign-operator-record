# CONVERGE-01 C5 — deterministic program at final bytes

Builder seat: grok-4.6 (opencode)
HEAD: `a45fb98cfa6d3619f6ea405044e3b76e87add24a`
S-12: a suite is satisfied when every failure traces to a named pre-existing baseline or parked cause, and no failure is attributable to this loop.

## Must-run (deterministic-hermetic) — MEASURED

| suite | label | measured |
|---|---|---|
| SOW desktop `node --test test/*.test.js` | hermetic-deterministic | tests 1104; pass 1104; fail 0; skipped 0; duration_ms 98711.9097 |
| SOW terminal `node --test test/*.test.js` | hermetic-deterministic | tests 225; pass 225; fail 0; skipped 0; duration_ms 506.2032 |
| Token Center `py -3.12 -B -m unittest discover -s tests` | hermetic-deterministic | Ran 32 tests in 3.759s OK |
| shell `py -3.12 -B -m unittest discover -s shell/tests` | hermetic-deterministic | Ran 166 tests in 93.020s OK; S-5 restored 13 evidence/manifest paths byte-exact to HEAD |
| `tools/release/test_*.py` | hermetic-deterministic | Ran 72 tests in 34.145s; **71 pass, 1 fail** |

The one tools/release failure is `test_real_manifest_passes`: RELEASE-MANIFEST.json `batch_files` hashes lag C0/C1 bytes (app.css, workspace-bg.svg, app.js, install.json, rebase_adapters, fixture_allowlist, test_render.py, two release tests). V-8 required those manifests stay untouched until C6. **Pre-existing by design, not caused by this loop.** C6 regenerates the manifest.

## Gates — MEASURED

| gate | exit | notes |
|---|---|---|
| package boundary vs clean `git archive` extract | 0 | `package-boundary-archive.log` |
| provenance cross-hash | 0 | `provenance-cross-hash.log` |
| release-manifest check | 1 | same 9 pre-existing batch_files mismatches; C6 closes |
| governance BOM | 0 | |
| model consistency | 0 | |
| innerHTML sink audit | 0 | renderer.js + innerhtml_audit.json |

## Parked

- **SOW full pytest:** PARKED(SOW-PY-LOCK-PARTIAL). `modules/sow/requirements-dev.txt` is unpinned ranges (`jsonschema>=3.2`, `pytest>=7`). No lock synthesized (S-11, S-9). `pytest.ini` `2382/0/1` contract remains UNVERIFIED this loop.
- **Debate / SOVEREIGN / Distillery live legs:** PARKED(require Ollama models or a live service). Not run. No model loaded.
- True clean-room install: not a C5 suite; residual.

No unexplained orphan processes observed after suite/gate runs. Shell-suite evidence rewrites restored. Product-tree `__pycache__` from this phase removed.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
