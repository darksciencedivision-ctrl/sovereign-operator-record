# C4-FINISH — shell release object + proxy install cycle

Builder seat: grok-4.6 (opencode)
HEAD at cycle: `a45fb98cfa6d3619f6ea405044e3b76e87add24a`
Status: DONE-CANDIDATE

## Shell release object

V-12 confirmed no `rel/shell/...` tag and no shell archive. Version identity taken from `VERSION.json` system version `1.0.0-rc.1` (shell is not in the modules map).

Created (gitignored `release-artifacts/` per `.gitignore:55`, same convention as C3 module archives):

- `release-artifacts/shell-1.0.0-rc.1-src.zip` 1,660,535 bytes
- sha256 `2c362a39f253edea70afbdf0148f6d0ce48f3d440293c7523d3287f1aa95cc66`
- sidecar UTF-8 no BOM, `git archive --format=zip HEAD shell` (prefix `shell/`, 84 entries, no `shell/shell` duplication)

Annotated tag `rel/shell/1.0.0-rc.1` created on this HEAD. No tracked product-byte change was required (archives are gitignored; producers already had the prior-session `-c` quoting and Debate `DEBATE_LOG_DIR` temp fixes). No empty commit.

## Proxy destination

Interrupted residue listing captured to `proxy-dest-residue-listing.txt` (24,462 entries). Destination then removed entirely so the cycle started empty.

## Cycle (captured)

1. `build_release.ps1` exit 0 — `build-release.log`
   - source `e4b3e3da9bc4ec6e7f1448dc0d3a87b5d0268fe5796bbfb04a2c65e2914ef329` 29820189
   - install `baebaafe8ce103dff0640885491a99c2255d3f7a3bf17cc2cbca761ac96d1349` 29990963
2. `install.ps1 -Dest "D:\producttion software 2\install test area" -TargetDir "D:\producttion software 2\install test area\shortcut targets"` exit 0 — `install.log`
   - recorded 24468 created paths
3. `verify_install.ps1 -Dest` exit 0 — `verify-install.log`
   - 21689 file hashes and exact path set verified
   - sovereign/debate/SOW desktop imports OK; Debate logs stayed in temp
4. Documented launcher `Start-Shell.ps1 -Port 5199 -NoBrowser` from the install root — `installed-shell.log`
   - GET `http://127.0.0.1:5199/` → HTTP 200, shell HTML
   - Modules loaded: debate, distillery, llamacpp, sovereign, sow, tokencenter
   - clean stop via taskkill of the listener
5. Post-boot exact-set: expected 24462 install-scope paths, extra 0, missing 0. No product-tree `__pycache__`, no `modules/debate/logs`.
6. `uninstall.ps1 -Dest` exit 0 — `uninstall.log`
   - `{"claim":"removed exactly the recorded paths","removed_recorded_paths":24468,"remaining_recorded_paths":0}`
   - destination directory gone

No Desktop or Start Menu `Sovereign Workspace.lnk` after the cycle.

## Limitation (required)

This host already has Python, node, and Ollama. The cycle proves install/verify/uninstall MECHANICS and layout. It does NOT prove clean-room independence. A fresh-VM clean-room install remains a residual operator/reviewer item.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
