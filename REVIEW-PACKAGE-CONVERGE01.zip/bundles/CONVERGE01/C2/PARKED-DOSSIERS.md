# C2 parked dossiers

## SOW-PY-LOCK-PARTIAL

Observed input: `modules/sow/requirements-dev.txt` contains only two unpinned lower bounds, `jsonschema>=3.2` and `pytest>=7`. It is not sufficient to reproduce an environment and cannot support the directive's version-versus-lock comparison. The builder did not invent pins, copy an environment, or modify the file. Consequence: the promised SOW full-pytest environment remains unavailable from candidate-owned locks and the C5 SOW Python leg must compare against/park on the recorded baseline under Amendment A unless a resolved lock arrives through a separately authorized action.

## DISTILLERY-PY-LOCK-MISSING

Observed input: `modules/distillery/pyproject.toml` has no runtime dependencies and only an unpinned build requirement; `modules/distillery/INSTALL-PROVENANCE.json` records `lockfiles: []`. A `.venv` cannot be truthfully represented as lock-driven. No environment was created. C5 may run only a no-install path that is genuinely supported by an available interpreter and must not use that as evidence of a provisioned release environment.

## C2-RISK-NANOID-LOCK-HELD

The retained SOVEREIGN UI lock resolves `nanoid@3.3.16`; the registry audit reports GHSA-2v37-7h3g-55p8 at high severity. Changing it requires changing the read-only lock. This is a named release-note risk, not silently accepted remediation debt.

## C2-RISK-SPIKE-ELECTRON-LOCK-HELD-NONPRODUCT

The retained non-product spike lock resolves `electron@31.7.7` and `extract-zip@2.0.1`; the registry audit aggregates them as two high package findings. The package calls itself a throwaway spike and is not the product desktop package, whose audit is clean. The lock remains unchanged; exclusion from release artifacts must be verified by C6 manifests/archive contents or the risk remains release-blocking.

## C2-RISK-PYTHON-VULNERABILITY-AUDITOR-NOT-LOCKED

No retained Python lock contains `pip-audit` or an equivalent vulnerability database client. Installing one would itself violate the lock-only grant. Exact-version reconciliation and `pip check` are clean, but CVE disposition remains unknown and must be named in release notes/reviewer review.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
