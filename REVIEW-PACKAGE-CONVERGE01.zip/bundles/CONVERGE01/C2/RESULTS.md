# CONVERGE-01 C2 — Environment provisioning results

Status: **PARKED(partial: SOW and Distillery lack usable resolved Python locks; named audit risks retained)**  
Candidate HEAD: `0a638260`  
Disk preflight: **376.418 GiB free** on `D:`; threshold 12 GiB  
Tracked-byte result: **no tracked change; porcelain clean**

## Lock disposition

| Environment | Lock input and measured SHA-256 | Disposition |
|---|---|---|
| SOVEREIGN Python 3.12 | `modules/sovereign/WORKSPACE-RESOLVED-LOCK.txt`, `1a850957d1c19cc936ff89d4f96d151ac910b451b7eaf43d22a87b3ef1ca0b3f` | Complete exact pins, no hashes. Provisioned with `--only-binary=:all: --no-deps`; 85 lock pins = 85 installed pins, zero missing/extra/version drift. Bootstrap `pip==25.0.1` excluded from lock comparison. `pip check`: no broken requirements. |
| Debate Python 3.14 | `modules/debate/requirements.lock.txt`, `2ff25bb523a3f6593d1969cb0ac1ba87f6c3f14ebe70bf596a33c406ec1d03b2` | Complete exact pins, no hashes. Provisioned with `--only-binary=:all: --no-deps`; 22 lock pins = 22 installed pins, zero missing/extra/version drift. Bootstrap `pip==26.1.2` excluded. `pip check`: no broken requirements. |
| SOW Python | `modules/sow/requirements-dev.txt`, `08097053a114dccff57bb11a8711c4274327492babb7c9fe42fd8cbc0a44ae91` | **PARKED(SOW-PY-LOCK-PARTIAL):** only `jsonschema>=3.2` and `pytest>=7`; not a resolved lock and carries neither exact versions nor hashes. No `.venv` created. |
| Distillery Python | `modules/distillery/pyproject.toml`, `da91123ae4c290a45d5e8fb075fcb5bab4dc8bf76d155b5d27ebe74e3cbbbd10` | **PARKED(DISTILLERY-PY-LOCK-MISSING):** build metadata has `setuptools>=77`, but no resolved dependency lock exists (`INSTALL-PROVENANCE.json` also records an empty lock list). No `.venv` created. |
| Token Center | stdlib-only by current source/readme | Verified with Python 3.12 import self-check; no environment or package install needed. |
| SOVEREIGN UI Node | lock v3, `f7308ea1c1039497e9c9bb6c111e3366337894c6cdd4b0f4b75a28c9678e2386` | `npm ci`; `npm ls --all` exit 0. 90 required name/version pairs present, 2 applicable optional pairs present, 34 other-platform optional pairs omitted, zero installed pairs outside lock. |
| SOW desktop Node | lock v3, `6a79bbcc8bdc249ddd75d711965eb6620b7499063997e51d0512081f627a87fa` | `npm ci`; `npm ls --all` exit 0. 17 required + 1 optional name/version pairs present, zero drift. Electron and node-pty import self-check succeeded. |
| SOW spike compositor Node | lock v3, `15f14a4ed8b028e1ac0204983ce511d2893db548c39cc9bd0776a30aee790248` | `npm ci`; `npm ls --all` exit 0. 52 required + 22 optional name/version pairs present, zero drift. This package declares itself a non-product throwaway spike. npm 11 warned that Electron/node-pty install scripts are not covered by this package's `allowScripts`; node-pty import succeeded. |

All seven inputs above were re-hashed after installation and remained byte-identical. `.venv/` and every installed `node_modules/` path are covered by existing module/root ignore rules; `.gitignore` required no extension.

## Import/self-checks (no service or model launched)

- SOVEREIGN: Flask, requests, ChromaDB, NumPy, Pydantic, `system_manifest`, and `sovereign_product.model_client` imported from the new venv.
- Debate: FastAPI, HTTPX, Pydantic, Uvicorn, and `app` imported from the new venv.
- Token Center: `piggybank` imported under Python 3.12 and its stdlib data contract was checked.
- SOVEREIGN UI: React and Vite ESM imports succeeded.
- SOW desktop: `ws`, `node-pty`, and Electron imports succeeded. Electron completed its lock-authorized binary acquisition from its package distribution host during the import check.
- SOW Python and Distillery Python self-checks are parked with their provisioning blockers; no host interpreter was substituted for the missing venvs.

## Supply-chain disposition

`npm audit --json` results:

- SOW desktop: 0 vulnerabilities.
- SOVEREIGN UI: 1 high package-level finding — `nanoid` `<3.3.18`, GHSA-2v37-7h3g-55p8 (custom generator zero-size loop). It is transitive and fixed only by changing the retained lock; **PARKED(C2-RISK-NANOID-LOCK-HELD)**.
- SOW spike compositor: 2 high package-level findings — legacy `electron@31.7.7` aggregates Electron advisories and `extract-zip@2.0.1` is affected by GHSA-jmr9-qjv8-65gv. Remediation requires breaking/lock changes and the tree labels this rig non-product; **PARKED(C2-RISK-SPIKE-ELECTRON-LOCK-HELD-NONPRODUCT)**.

Neither complete Python lock includes `pip-audit`, and installing an unpinned audit tool would violate lock-only provisioning. `pip check` was run instead for dependency consistency, but it is not a vulnerability database. **PARKED(C2-RISK-PYTHON-VULNERABILITY-AUDITOR-NOT-LOCKED)** for reviewer/operator disposition.

The allowlisted tree-wide package-boundary scan examined 23,217 files. It reported 19,603 expected live-tree boundary violations (19,601 runtime/session-state files from the newly provisioned and pre-existing ignored lanes, one pre-existing Debate log, and one pre-existing Token Center SQLite database), 2,059 quarantined historical files, 5 exact-hash allowlisted fixtures, and **zero credential hits**. The unallowlisted companion capture demonstrates that eight apparent key hits are the already-declared synthetic test fixtures. Release packaging remains bound to a clean archive scan in C5/C6, not this operational live-tree result.

## Evidence files

- `sovereign-pip-install.log`, `sovereign-pip-freeze.txt`
- `debate-pip-install.log`, `debate-pip-freeze.txt`
- `{sovereign-ui,sow-desktop,sow-spike}-npm-ci.log`
- `{sovereign-ui,sow-desktop,sow-spike}-npm-ls.json`
- `{sovereign-ui,sow-desktop,sow-spike}-npm-audit.json`
- `tree-wide-package-boundary.json`
- `tree-wide-package-boundary-allowlisted.json`

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
