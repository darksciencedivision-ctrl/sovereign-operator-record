# C1 OP-2 — Frontier-provider design dossier

Status: **DONE-CANDIDATE (design only; implementation DEFERRED(operator))**  
Recorded: 2026-08-29T15:02:09Z  
Candidate HEAD examined: `ad8c4c72`  
Authority: CONVERGE-01 R4 / OPERATOR-INSTRUCTIONS.log Entries 005, 006, and 008  
Product-byte delta: **zero**

## Executive disposition

SOVEREIGN is model-configurable today, but it is not provider-agnostic. `SYSTEM_MANIFEST.json` is the configuration authority for role assignments, while every configured generation model is validated against and executed through one loopback-only Ollama inventory/client. Adding Claude, Codex, or Grok is therefore not a model-name-list extension. It is a new remote-execution, credential, spend, availability, evidence, and telemetry boundary.

The least-duplicative future mechanism is a SOVEREIGN provider abstraction that preserves `SYSTEM_MANIFEST.json` as the role-assignment authority and bridges to the already-governed SOW provider-CLI subprocess backends. It must not import SOW's orchestration control plane wholesale. Direct provider APIs remain a possible alternative, but they create a new key-custody and HTTP-client surface and should not be selected without an explicit operator ruling.

Under OD-5, provider spend is currently DENY. This design is therefore intentionally inert: no provider process was spawned, no provider endpoint was called, no credential was read, and no implementation is authorized by this dossier.

## 1. Current state and the boundary that would change

### Configuration and model-list authority

- `modules/sovereign/SYSTEM_MANIFEST.json` assigns five exact model strings under `MODELS` and pins `RUNTIME.OLLAMA_BASE_URL` to `http://127.0.0.1:11434`.
- `modules/sovereign/system_manifest.py:13-27,52-80,127-149` defines the required roles, validates every role as a non-empty string, and rejects an Ollama URL unless it is unambiguous loopback HTTP.
- `modules/sovereign/sovereign_product/server.py:78-83,539-566,603-632` loads that manifest, constructs the default Ollama client from it, and maps the four configurable generation roles into the deep executor. `EMBEDDING_MODEL` is deliberately outside `CONFIGURABLE_MODEL_ROLES`.
- `modules/sovereign/sovereign_product/server.py:1694-1710` publishes the profile with source `sovereign://SYSTEM_MANIFEST.json`. Lines 1712-1790 accept only the four configured generation roles, require each assigned model to appear in the local Ollama inventory, then atomically update `SYSTEM_MANIFEST.json`. Lines 1737-1742 explicitly keep the embedding role read-only because the local registry lacks reliable embedding-compatibility metadata.

This is the M-6 result in operational form: the model UI/profile is a view and editor of `SYSTEM_MANIFEST.json`; it is not an independent provider registry.

### Execution boundary

`modules/sovereign/sovereign_product/model_client.py:1-5,105-175` is explicitly a local-only Ollama client. It accepts only loopback HTTP, forbids credentials in the URL, disables redirect-following at requests such as `/api/show`, and has no remote-provider fallback. Its generation contract returns Ollama-specific raw stream events and telemetry (`GenerationResponse`, lines 57-83).

A frontier provider breaks that boundary in six concrete ways:

1. **Transport:** execution becomes a hosted CLI subprocess or remote HTTPS API instead of loopback Ollama HTTP.
2. **Identity:** `modelId` alone is no longer globally meaningful; assignment needs a provider-qualified identity and a recorded executing-model result.
3. **Inventory:** the present save path proves membership in `ollama.installed_models`. Hosted CLI inventories can be partial, unavailable, or resolved only during an authorized call.
4. **Credentials:** local Ollama needs no hosted credential. Frontier execution relies on provider authentication whose custody must remain outside product logs, artifacts, and install manifests.
5. **Spend and network:** a successful generation can create billed or subscription-metered activity and requires a non-loopback network path.
6. **Telemetry/evidence:** Ollama stream events do not have the same usage, model-reporting, error, or provenance shapes as the three CLIs.

Treating provider names as additional Ollama model strings would fail at the current inventory check and, if that check were bypassed, would still route the call to Ollama. That is why a list-only implementation would be false agnosticism.

## 2. Candidate mechanism

### Recommended shape: provider-qualified role assignments plus a narrow CLI bridge

Keep `SYSTEM_MANIFEST.json` as the sole role-assignment authority, but evolve each generation assignment from a bare local tag to a validated provider-qualified record, conceptually:

```json
{
  "provider": "ollama_local | claude_code | openai_codex_cli | grok_build",
  "model": "provider-specific verified-or-recorded identifier",
  "execution": "local | hosted_cli"
}
```

Compatibility parsing should continue to interpret existing string values as `ollama_local`, so migration does not silently change the current candidate. The embedding assignment should remain local and read-only unless the operator separately authorizes an embedding-provider design.

Introduce a small SOVEREIGN-owned `ProviderClient` result contract for exact text, executing model, usage fields when known, raw provider evidence pointer, timestamps, and a normalized error class. The existing Ollama client becomes one implementation. Hosted implementations bridge to the provider-specific command/env/probe logic already present in:

- `modules/sow/adapters/frontier/claude_code.py`: `ClaudeCliBackend`, fail-closed auth handling, credential/endpoint environment scrubbing, forbidden-argument checks, model-report reconciliation, and a `ModelWorkerAdapter` binding at lines 830-838.
- `modules/sow/adapters/frontier/codex.py`: `CodexCliBackend`, equivalent credential scrubbing/argument containment, reasoning and coding role mappings, and the frontier binding at lines 751-763.
- `modules/sow/adapters/frontier/grok_build.py`: `GrokCliBackend` and the shared provider-CLI safety layer, with a deliberate `_LIVE_SPAWN_PATH_WIRED = False` at lines 128-142 and a frontier binding at lines 263-271.

The bridge should reuse or extract their provider-specific primitives; it should not pretend that SOVEREIGN has SOW's supervisor, MCP context compiler, node registry, subscription governor, or `ModelWorkerAdapter` lifecycle. In particular, Grok must remain unavailable while its own adapter's live-spawn gate is false. Any shared extraction must preserve the current SOW call sites and tests.

### CLI subprocess versus direct API

| Dimension | Reused provider CLI subprocess | Direct provider API |
|---|---|---|
| Credential custody | Reuses already-authenticated CLI, with the existing code designed not to read or transmit host-native credentials | Requires a new secret acquisition/storage/injection design and redaction tests |
| Existing governance | Reuses mature argv guards, environment scrubbing, model-report parsing, auth-pause classes, mocks, and process containment | Requires new HTTP clients, endpoint allow-lists, retry/rate-limit policy, response validation, and provider mocks |
| Model discovery | Uses each installed CLI's supported probe/fallback semantics; can be incomplete | API catalogs may be richer, but are network-, account-, region-, and authority-dependent |
| Spend control | Can reuse subscription-aware provider semantics, but still needs an explicit SOVEREIGN launch/spend gate | Can meter per API request more directly, but every request is an explicitly billed boundary |
| Packaging | Adds no keys; depends on compatible provider CLIs being installed and authenticated on the host | Adds SDK/HTTP dependency and key-custody obligations; may change locks/SBOM/notices |
| Evidence | Provider CLI envelopes and local ledgers already have parsers, though shapes differ and coverage can be partial | API response usage can be structured, but raw response retention/redaction rules must be designed |
| Coupling risk | Direct imports from SOW internals would be brittle; prefer a shared provider primitive or a deliberately narrow bridge | SOVEREIGN owns the integration, but duplicates policy already exercised in SOW |

Recommendation: use the CLI mechanism first, after the rulings below. Keep a direct-API transport as a separately authorized future option, not a fallback. Never silently fall back between local, CLI, and API transports.

## 3. Operator-only decisions

### D1 — Spend and network authority (OD-5)

Current ruling: **DENY**. `LOOP-PROTOCOL-20260828.md:50` records no provider spend for this release, and `SWS-REM-DIR-20260828-CANDIDATE-R2.md:72-76` requires an explicit bounded OD-5 grant before billed/provider sessions. OP-2 remains inert without a new ruling.

A grant must name provider(s), account/subscription class, allowed tests or product routes, request/token or currency ceiling, expiry/completion condition, and UTC. It must also decide whether provider catalog probes that could authenticate or meter usage are allowed. No grant should be inferred from a CLI already being logged in.

### D2 — Key and credential custody

Choose one custody model:

1. **Recommended for the CLI design:** host-native provider CLI stores only. SOVEREIGN may ask the CLI for sanitized auth state but never opens, copies, logs, packages, or backs up the credential store. Credential-bearing environment keys are scrubbed before child launch, following the existing SOW adapters.
2. **Required before direct API:** a separately specified OS-native secret-store workflow with redaction at process, evidence, crash, diagnostic, install, and uninstall boundaries. Plaintext config, repository `.env`, command-line secret flags, and artifact-carried keys remain forbidden.

`tools/release/package_boundary_gate.py:37-79,84-107,195-215,253-279` supplies the packaging classes this design must satisfy: `.env*` and private-key/key-store files; logs; runtime/session-state directories including `.venv`, `node_modules`, `.runtime`, and recovery/run lanes; plus value-based AWS access keys, private-key blocks, GitHub tokens, Slack tokens, and OpenAI-style `sk-...` keys. A future implementation must add provider-specific high-confidence patterns only when they can be defined without creating noisy false positives, and must prove sanitized fixtures do not leak values.

### D3 — Role eligibility and locality

The operator must rule separately on `PRIMARY_REASONER`, `ADVERSARIAL_CHALLENGER`, `CRITIC`, and `SYNTHESIZER`:

- hosted eligible, with an allowed-provider set;
- local required; or
- hosted eligible only for an explicitly selected route/session.

Recommended default pending a ruling: all four remain local. `EMBEDDING_MODEL` remains local-required and non-editable because it participates in semantic matching and currently has an explicit compatibility/inventory constraint. The ruling must also address whether one deep run may mix providers, whether sensitive/local-only inputs can ever leave the host, and whether a hosted provider may synthesize the canonical final answer.

### D4 — Evidence and telemetry routing

`modules/tokencenter/piggybank.py` already has the relevant collector matrix:

| Provider path | Collector | Current evidence quality |
|---|---|---|
| OpenAI / Codex | `collect_codex` (`~/.codex/sessions`) | provider-returned per-response totals; complete for retained local Codex sessions when observed |
| Anthropic / Claude | `collect_claude` (`~/.claude/projects`) | message-ID deduplication with input/cache/output metadata |
| OpenCode-hosted providers | `collect_opencode` | provider-labelled hosted events, including OpenAI, Anthropic, and xAI mappings when numeric ledger data exists |
| xAI / Grok | `collect_grok` (`~/.grok/logs/unified.jsonl`) | explicitly partial; numeric usage appears only in retained `promptUsage` diagnostics and successful calls may remain unknown |

The collector orchestration is at `piggybank.py:581-606`; its summary rule at lines 686-699 correctly treats missing or partial telemetry as unknown, never zero.

The operator must choose whether SOVEREIGN (a) relies only on those existing provider ledgers, (b) writes a new sanitized SOVEREIGN usage ledger consumed by Token Center, or (c) correlates both. Recommendation: correlate both using stable invocation IDs and deduplicate, while storing no prompts, responses, account identifiers, auth output, or credentials in Token Center. Provider raw evidence should remain in SOVEREIGN's governed evidence lane with redaction and a pointer from normalized telemetry; unknown cost/token fields stay `null`/UNKNOWN, never estimated as zero.

## 4. Future authorized implementation plan

The following is a seven-commit batch, not authority to execute it:

1. **Manifest schema + compatibility:** add provider-qualified generation assignments, retain bare-string `ollama_local` compatibility, reject unknown provider/role combinations, and preserve the embedding restriction. Tests cover migration and fail-closed validation.
2. **Neutral provider contract:** introduce SOVEREIGN's normalized generation/inventory/auth-pause result types; adapt `OllamaClient` without changing current output or locality.
3. **Shared CLI safety extraction:** move only stable provider-specific argv/env/result primitives from SOW into a shared package or build narrow wrappers with import-boundary tests. No live spawn.
4. **Hosted CLI implementations:** wire Claude and Codex behind injected process runners and mocks; wire Grok only if its upstream `_LIVE_SPAWN_PATH_WIRED` authority/state has separately closed. Add kill-tree, cancellation, timeout, no-shell, credential-scrub, and executing-model tests.
5. **Role router + spend gate:** select transport from the manifest, enforce per-role/locality/provider eligibility and an explicit default-deny launch grant, forbid silent fallback, and preserve current Ollama behavior byte-for-behavior in the default configuration.
6. **Profile/UI and inventory:** expose provider-qualified models, availability/auth state, locality, executing-model truth, and unavailable/fallback reasons; save only operator-eligible assignments. No catalog call occurs merely by opening the UI.
7. **Telemetry, packaging, and acceptance:** correlate sanitized invocation records with Token Center, extend credential gates, locks/SBOM/notices if needed, run deterministic mock suites, then perform separately authorized bounded live legs with measured spend and provider-disabled proofs.

Each commit must include fail-before/pass-after evidence, must not edit an existing assertion merely to fit observed behavior, and must park any conflict with a held item. Direct API support, if selected, is a separate batch after a key-custody design and provider-specific network/spend grant.

## Files read for this dossier

The builder read the complete current contents of every product file cited above:

- `modules/sovereign/SYSTEM_MANIFEST.json`
- `modules/sovereign/system_manifest.py`
- `modules/sovereign/sovereign_product/model_client.py`
- `modules/sovereign/sovereign_product/server.py`
- `modules/sow/adapters/frontier/claude_code.py`
- `modules/sow/adapters/frontier/codex.py`
- `modules/sow/adapters/frontier/grok_build.py`
- `modules/tokencenter/piggybank.py`
- `tools/release/package_boundary_gate.py`

Custody authorities read: `CODEX-BUILD-DIRECTIVE-BATCH5-20260828.md`, `LOOP-PROTOCOL-20260828.md`, `SWS-REM-DIR-20260828-CANDIDATE-R2.md`, `OPERATOR-INSTRUCTIONS.log`, and the CONVERGE-01 R3/R4 directives.

## Residual disposition

- OP-2 implementation — **DEFERRED(operator)** pending D1–D4.
- OD-5 provider spend — **DEFERRED(operator), current state DENY**.
- No Entry 009 exists at dossier time; OD-20 and OD-23 remain residual under R4 and are not modified by this item.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
