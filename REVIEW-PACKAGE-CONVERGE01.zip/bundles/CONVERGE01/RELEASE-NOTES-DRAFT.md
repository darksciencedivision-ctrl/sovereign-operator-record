# CONVERGE-01 release notes draft (CANDIDATE)

System: `sovereign-workspace` `1.0.0-rc.1`
Seal commit: `32f191e988e4690f5d68c83d541ca8668445dd03`
Product/tooling head pinned in VERSION.json: `a45fb98cfa6d3619f6ea405044e3b76e87add24a`
Rollback of record: `SOVEREIGN_RESET_BASELINE_20260827T193540Z.zip` sha256 `00ae9eefc7dada37943bb08a305020c73e2c029a6398858e8bba27078c349a7c`

## Module versions

| module | version |
|---|---|
| debate | v1.2.1-hardening |
| distillery | 1.1.0rc3 |
| sovereign | SOVEREIGN_ENTERPRISE_PRODUCTION_20260813_142520 |
| sow | 0.1.0 |
| tokencenter | record-dated 2026-08-26 |
| shell | 1.0.0-rc.1 (`rel/shell/1.0.0-rc.1`) |

## Changes since baseline `a945d99` (this loop)

- C0 N-14b: local UI baseline (`app.css`, `workspace-bg.svg`, `workspace-bg-v2.png`)
- C0 N-16: startup-test evidence isolated to gitignored `.runtime/`
- C0 suite: CP-M1 source/assertion reconciliation (`e2e8e55`, HELD)
- C1 N-13b: adapter rebase with optional llamacpp skip
- C1 OP-3: SOW visible terminal cap 8
- C1 OP-4: Token Center iframe scoped to `http://127.0.0.1:8765` / ancestor `http://127.0.0.1:5180`
- C1 OP-1: Windows shortcut installer + local `sovereign.ico`
- C1 OP-2: frontier-provider design dossier only (zero product bytes)
- C2: lock-driven SOVEREIGN/Debate venvs and Node `npm ci`; SOW/Distillery Python parks
- C3: LICENSE, notices, VERSION `1.0.0-rc.1`, SBOM, module archives + annotated tags
- C4: manifest-driven build/install/verify/uninstall; shell archive + tag; proxy cycle completed
- C6: provenance, identity, RELEASE-MANIFEST regenerated; candidate ZIPs re-cut from `32f191e`

## Accepted limitations and parks BY NAME

- **SOW Python dependencies are unpinned ranges and Distillery has no Python lock — reproducible provisioning is not achieved for those two modules**
- SOW full pytest contract unverified this loop (`pytest.ini` 2382/0/1) — parked on SOW-PY-LOCK-PARTIAL
- OD-20 lineage ruling outstanding (`e2e8e55` HELD)
- OD-23 assertion-inversion adjudication (inventory in `V/assertion-inventory.md`)
- Pre-existing shell-suite baseline disposition (this loop measured 166/166 OK)
- C2 supply-chain accepted risks: nanoid lock-held; spike Electron/extract-zip nonproduct; Python vulnerability auditor not locked
- No-spend limitations (Grok registry leg, G28)
- Distillery status-only plus deferred live testing plus deferred UI (OP-6)
- H-6 composed-system proof
- MT-09 signature
- G26 attended debug
- Live-acceptance and display legs
- OP-2 awaiting rulings (dossier only)
- Upstream Distillery W-4 tagging (outside write boundary)
- Canonical license text pending
- True clean-room install pending (C4 proxy proves mechanics/layout only; host already has Python, node, Ollama)
- Debate / SOVEREIGN / Distillery legs requiring Ollama or a live service not run

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
