# CONVERGE-01 report (CANDIDATE)

Builder seat this run: grok-4.6 (opencode)
Directive: SWS-REM-DIR-20260828 R2 · ENTRIES 006–009
Seal HEAD: `32f191e988e4690f5d68c83d541ca8668445dd03`

## Commit chain from `a945d99`

```
1f0a59c C0 N-14b: adopt in-progress visual baseline work
65bd58f C0 N-16: isolate runtime startup-test evidence
e2e8e55 C0 suite: reconcile CP-M1 source and assertions
e03811e C1 N-13b: rebase installed adapters with optional skip
1397a14 C1 OP-3: raise SOW visible terminal cap to eight
e55cde9 C1 OP-4: embed scoped Token Center in shell
ad8c4c7 C1 OP-1: add proper Windows shortcut installer
0a63826 C1 OP-2: record frontier provider design dossier
0722692 C3: add release identity, notices, and SBOM
a45fb98 C4: add manifest-driven release install tooling
32f191e C6: regenerate provenance, identity, and release manifest
```

C2 produced no tracked commit (environments gitignored; parks recorded).
Shell release object: gitignored archive `release-artifacts/shell-1.0.0-rc.1-src.zip` + annotated tag `rel/shell/1.0.0-rc.1` on `a45fb98`.

## Per-phase results (three builder sessions)

| phase | seats | result |
|---|---|---|
| C0 | codex | UI adopt, N-16, HELD `e2e8e55` |
| C1 | codex + prior grok | N-13b, OP-3, OP-4, OP-1, OP-2 dossier |
| C2 | prior grok | SOVEREIGN/Debate/Node provisioned; SOW+Distillery Python parks real |
| C3 | prior grok | identity docs, five module tags/archives |
| C4 | prior grok tooling; this seat cycle | tooling committed `a45fb98`; this seat completed proxy cycle + shell object |
| V | this seat | independent re-derivation; see `V/VERIFICATION-REPORT.md` |
| C5 | this seat | hermetic suites + gates; parks named |
| C6 | this seat | manifests last; ZIPs recut; review package |

## Measured totals (this seat)

- SOW desktop: 1104/1104
- SOW terminal: 225/225
- Token Center: 32/32
- shell: 166/166 (S-5 restored)
- tools/release tests at C5: 71/72; the 1 fail was stale RELEASE-MANIFEST (pre-C6). After C6 regeneration, `release_manifest_check` exit 0 / problem_count 0
- C4 proxy: 24468 recorded paths; verify 21689 hashes; GET / 200; uninstall consumed exact set; dest gone
- Recut workspace source zip sha256 `27de97cda3875d375f0d799bb482c56a1a6d593d0debec624d3a99669eefe10d`

## §7 checklist

| row | status |
|---|---|
| V verification report | DONE-CANDIDATE |
| V-9 assertion inventory | DONE-CANDIDATE |
| V-11 C2 parks confirmed real | DONE-CANDIDATE |
| C4 shell release object | DONE-CANDIDATE |
| C4 full proxy cycle | DONE-CANDIDATE |
| C4 test area cleaned | DONE-CANDIDATE |
| C5 deterministic suites | DONE-CANDIDATE |
| C5 gates | DONE-CANDIDATE |
| C5 SOW full pytest (run or parked) | PARKED(SOW-PY-LOCK-PARTIAL; pytest.ini 2382/0/1 UNVERIFIED) |
| C6 manifests regenerated | DONE-CANDIDATE |
| C6 ZIPs re-cut + cold-verified | DONE-CANDIDATE |
| C6 review package | DONE-CANDIDATE |
| C6 release-notes draft | DONE-CANDIDATE |
| C6 converge report | DONE-CANDIDATE |

## RESIDUAL QUEUE

- OD-20 ruling on the e2e8e55 lineage import
- OD-23 assertion-inversion adjudication
- SOW + Distillery dependency-lock defects
- pre-existing shell-suite baseline disposition
- 19 CANDIDATE gates + Gate-5/5b reviewer backlog
- reviewer verdicts on all CANDIDATE work
- operator physical acts and rulings (OP-2, OP-6, H-6, MT-09, G26, live-acceptance, clean-room VM, canonical license, Distillery W-4)

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
