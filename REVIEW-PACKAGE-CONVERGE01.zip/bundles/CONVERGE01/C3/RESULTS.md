# CONVERGE-01 C3 — Release identity results

Status: **DONE-CANDIDATE with named interim-license/SBOM limitations**  
Commit: `07226921ab82ab8fb8e4ab7ec19e0cfb244c334b`  
System version: `1.0.0-rc.1`  
Porcelain after commit/archive/tag work: clean

## Identity documents

- Root and all five module `LICENSE` files carry the exact interim operator text required by C3. Canonical license text remains an external-distribution blocker.
- `VERSION.json` records system `sovereign-workspace`, version `1.0.0-rc.1`, and the five module versions from the retained `RELEASE-MANIFEST.json`. `source_commit` is deliberately `PENDING-C6` until the final code/tooling commit exists.
- `THIRD-PARTY-NOTICES.md` lists 304 distinct locked package/version components and their declared license metadata. Ten Python distributions expose no usable license value in their installed metadata and are explicitly `UNKNOWN`; canonical notice review remains required.
- `SBOM.json` is CycloneDX-style 1.6 with 477 components: 304 dependency libraries and 173 native files. Every inventoried `.exe`, `.node`, `.pyd`, and `.dll` under the two provisioned Python venvs and three Node dependency trees has a measured SHA-256 and an explicit ignored-C2-environment scope.
- `tools/release/generate_release_identity.py` reproducibly generates VERSION/SBOM/notices from retained locks and C2 metadata. Its new deterministic fixture test is 1/1. Re-running the generator with identical inputs yielded byte-identical hashes for all three outputs.

## Source archives and annotated tags

All archives were created with `git archive` from C3 commit `07226921`; ignored environments/runtime state are absent, each archive contains its module `LICENSE`, and every sidecar was independently remeasured.

| Module | Archive | Bytes | SHA-256 | Annotated tag |
|---|---|---:|---|---|
| Debate | `debate-v1.2.1-hardening-src.zip` | 184,500 | `dee5f4469726a7e46de7c8f83d9bcd914f6d4f010d583614b9d739f95a115e66` | `rel/debate/v1.2.1-hardening` |
| Distillery | `distillery-1.1.0rc3-src.zip` | 2,202,821 | `60d433c77fd5f6aaf27b3cac0d14287ca2bca5755e3eefa8599d6ffc5d83fd00` | `rel/distillery/1.1.0rc3` |
| SOVEREIGN | `sovereign-SOVEREIGN_ENTERPRISE_PRODUCTION_20260813_142520-src.zip` | 476,636 | `5425438580dd416df89c819af9f82960b5d6417aeb315904fb14da46cc043363` | `rel/sovereign/SOVEREIGN_ENTERPRISE_PRODUCTION_20260813_142520` |
| SOW | `sow-0.1.0-src.zip` | 4,902,246 | `d28612dc02cf69b0ebf028258b20fbe5a191325ab721d3397dafd7e527ebdc37` | `rel/sow/0.1.0` |
| Token Center | `tokencenter-record-dated-2026-08-26-src.zip` | 387,961 | `a36e7dec02600e950a525c961db44aa622cfcc556bb88773696bacfb3eb1effe` | `rel/tokencenter/record-dated-2026-08-26` |

The existing Debate upstream release artifact was only read and re-hashed: `D:\Product Software\Production Workspace\dev\v1.2.1-hardening\release\Debate_Table_v1.2.1_Hardening_20260823_143520.zip` measured `d03ba417914e1465898f5144cc5735afb92f7f6da5e846e0a968fe48c531d265`, exactly the retained pin. It was not re-cut or modified. The table above is a candidate-tree source archive, not a replacement for that upstream artifact.

## Rollback of record

The previous-baseline rollback artifact remains the frozen `D:\producttion software 2\SOVEREIGN_RESET_BASELINE_20260827T193540Z.zip`, measured SHA-256 `00ae9eefc7dada37943bb08a305020c73e2c029a6398858e8bba27078c349a7c`. C3 did not manufacture or alter a rollback artifact.

## Limitations carried forward

- Canonical license text pending operator.
- Ten dependency-license metadata values remain UNKNOWN pending canonical notice review.
- SOW Python closure partial and Distillery Python closure missing; their absent dependencies cannot appear as resolved SBOM components.
- Python vulnerability-audit tool absent from retained locks.
- C2 lock-held audit risks: SOVEREIGN UI nanoid; non-product spike Electron/extract-zip.
- C6 must regenerate VERSION/SBOM/notices at the final content commit, regenerate provenance/manifest last, and re-cut/cold-verify final candidate archives.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
