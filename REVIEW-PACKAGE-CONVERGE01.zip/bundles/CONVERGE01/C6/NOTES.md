# C6 seal notes

HEAD: `32f191e988e4690f5d68c83d541ca8668445dd03`
VERSION.json `source_commit`: `a45fb98cfa6d3619f6ea405044e3b76e87add24a` (last product/tooling commit; C6 commit is the seal)

Provenance regenerated with `generate_module_provenance.py --write` for debate/sow/distillery. Prior current records preserved as `*.pre-CONVERGE01`. Identity regenerated with `generate_release_identity.py`. RELEASE-MANIFEST rebuilt; previous preserved as `RELEASE-MANIFEST.json.pre-CONVERGE01`. `release_manifest_check` problem_count 0.

Candidate ZIPs recut from `git archive` of `32f191e` into gitignored `release-artifacts/`; cold-extracted; sidecar hashes match. See `zip-recut.json`.

Review package: `release-planning/REVIEW-PACKAGE-CONVERGE01.zip` sha256 `ca319032c57a1e02a2b24699168b6ba63af66304ce5b1ff3cc252ecba09cbf2b` (3,855,261 bytes; 105 entries; 0 files excluded for >5 MB). Patches `a945d99..HEAD` (11), CONVERGE01 bundles, custody docs.

Limitation: VERSION.json pins tooling head `a45fb98` rather than the seal commit so identity/SBOM hashes stay coupled inside `32f191e`.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
