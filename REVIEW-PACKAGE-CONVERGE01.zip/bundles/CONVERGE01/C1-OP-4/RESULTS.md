# C1 OP-4 — Embedded Live Token Center

Date: 2026-08-29

## Fail-before

- The Token Center card received the generic `Open` action, whose handler used `window.open(..., "_blank", "noopener")`; there was no iframe or stopped fallback.
- Shell CSP had no `frame-src` directive.
- Token Center emitted `frame-ancestors 'none'` and `X-Frame-Options: DENY` on every response.

## Candidate behavior

- The Token Center card embeds exactly `http://127.0.0.1:8765/` when module state is `READY` or `EXTERNAL`.
- The iframe is sandboxed with `allow-scripts allow-same-origin`, sufficient for Token Center's own same-origin client and no broader capability.
- When not running, the iframe has no `src` and is hidden; the card shows module status plus a local Start button. The generic click-out Open action is absent from this card.
- No shell backend route was added or changed.

## Header deltas

Shell CSP changed by one directive only:

```text
before: default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; object-src 'none'; base-uri 'none'
after:  default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-src http://127.0.0.1:8765; frame-ancestors 'none'; object-src 'none'; base-uri 'none'
```

Token Center CSP changed only its frame ancestor:

```text
before: ...; frame-ancestors 'none'; object-src 'none'; base-uri 'none'
after:  ...; frame-ancestors http://127.0.0.1:5180; object-src 'none'; base-uri 'none'
```

`X-Frame-Options: DENY` was removed because it would override/prevent the scoped CSP framing grant. `X-Content-Type-Options: nosniff` and `Referrer-Policy: no-referrer` remain on successful and error responses.

## Framed CSRF/token path

The new test fetches the document as an iframe whose parent referrer is `http://127.0.0.1:5180/`, verifies the scoped `frame-ancestors` response, fetches the process token at Token Center's own 8765 origin, and completes the bodyless refresh POST with the exact 8765 `Origin`. The top-level shell origin is never substituted for the framed document's same origin.

## Verification

```text
py -3.12 -B -m unittest discover -s tests -v  (modules/tokencenter)
Ran 32 tests in 3.413s
OK

py -3.12 -B -m unittest discover -s shell/tests -v
Ran 166 tests in 94.011s
OK

node --check shell/static/app.js
exit 0

R-5 restoration applied after shell/browser runs:
shell/BUILD-MANIFEST.txt, evidence/hardening/*, and evidence/gate5/screenshots/shell-grid-rendered.png restored to HEAD.

git diff --check: clean
```

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
