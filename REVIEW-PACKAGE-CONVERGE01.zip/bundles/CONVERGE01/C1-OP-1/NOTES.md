# C1 OP-1 — Shortcut Installer Notes

Operator usage: from the candidate root, run `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\release\install_shortcut.ps1`.

The builder did not run the installer against user folders. Verification used `-TargetDir D:\producttion software 2\release-worktree\.runtime\shortcut-test`, which redirects the Desktop and Start Menu layouts below that worktree-only directory.

The local icon was deterministically derived from `shell/static/icon.svg` using its shipped rounded-square geometry, `S` glyph, and exact colors. `shell/static/sovereign.ico` SHA-256: `a8df12c0b0f14c91ea981b8f394b77447122b3445c83e8f69a67a5fca751f4bc`.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
