# C1 OP-1 — Proper Launcher

Date: 2026-08-29

## Candidate files

- `tools/release/install_shortcut.ps1`
- `tools/release/test_install_shortcut.ps1`
- `shell/static/sovereign.ico`

The installer creates/replaces `Sovereign Workspace.lnk` on the Desktop and in Start Menu Programs through `WScript.Shell` COM. Each shortcut has:

```text
TargetPath: %SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe
Arguments: -NoProfile -ExecutionPolicy Bypass -File "D:\producttion software 2\release-worktree\Start-Shell.ps1"
WorkingDirectory: D:\producttion software 2\release-worktree
WindowStyle: 1 (normal)
IconLocation: D:\producttion software 2\release-worktree\shell\static\sovereign.ico,0
```

## Isolated verification

The default installer was not run. The test invoked it twice with its target redirected to `D:\producttion software 2\release-worktree\.runtime\shortcut-test`, read both `.lnk` files back through COM, asserted every field above, asserted exactly two links after the second run, and removed the verified worktree-local test directory.

```text
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\release\test_install_shortcut.ps1
install_shortcut: 2 redirected links verified by COM; idempotent; no user folders touched
exit 0
```

ICO verification:

```text
SHA-256 a8df12c0b0f14c91ea981b8f394b77447122b3445c83e8f69a67a5fca751f4bc
embedded sizes 16, 24, 32, 48, 64, 128, 256
format ICO; top-level size 256x256; mode RGBA
```

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
