# C1 OP-3 — SOW Concurrent Terminal Presentation Cap

Date: 2026-08-29

## Fail-before source and enforcement

The candidate did not contain a process/session refusal at five. Its named product limit was the visible-layout cap:

- `modules/sow/apps/desktop/main.js:279` pinned `MAX_VISIBLE = 6`, which yields one pinned conductor plus five ordinary worker panes.
- `modules/sow/terminal/compositor/tiling.js:31` duplicated the default as `DEFAULT_MAX_VISIBLE = 6`.
- `planLayout` enforced the cap by computing a remaining P2 budget and applying `p2.slice(0, budget)` / `p2.slice(budget)`; overflow remains a live session represented by a status card.

## Pass-after behavior

- Both coupled values are 8.
- Eight concurrent session-backed panes are tiled.
- The ninth session is retained in `PaneModel` and its P2 pane is represented as a status card; no process is killed and no supervision rule is widened.
- P0/P1 never-collapse rules are unchanged.
- Recovery pane-id minting resumes above the persisted high-water mark, preventing an eight-pane recovery snapshot from colliding with a new pane id.

The C0 source reconciliation had also introduced three renderer IPC methods without extending the closed U177 runtime sweep. This item restored the invariant needed for the mandated full desktop suite: the empty-pane, execution-selection, and operator-text channels are now safely driven, the empty scratch container is closed and removed from its registry, and the operator-text sweep marker performs no delivery.

## Verification

```text
node --test terminal/test/*.test.js
tests 225; pass 225; fail 0; skipped 0

node --test test/*.test.js  (modules/sow/apps/desktop)
tests 1104; pass 1104; fail 0; skipped 0
duration_ms 99925.3114

node ../../tools/mutation/pane_input_bypass_mutations.js
base main.js SHA-256 A390F892CB9168F8C982AC2C5458F2B5D8DF6BC7EF5F1FDCA941FD41EB0618FE
clean tree: GREEN (expected)
37/37 mutations CAUGHT
restored main.js SHA-256 A390F892CB9168F8C982AC2C5458F2B5D8DF6BC7EF5F1FDCA941FD41EB0618FE — BYTE-IDENTICAL
ALL MUTATIONS CAUGHT

git diff --check: clean
```

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
