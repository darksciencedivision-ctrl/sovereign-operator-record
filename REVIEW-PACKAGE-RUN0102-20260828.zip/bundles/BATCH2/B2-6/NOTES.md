# B2-6 — M-6 README/model-hierarchy reconciliation (MEDIUM) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 2 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `5b29a2ebffb620c168a90c4cb227ef84158ebd46` (parent `9567d48`)
**UTC:** 2026-08-28T03:20–03:27Z

## Defects (mechanically detected)

`SYSTEM_MANIFEST.json` is the declared single source of truth for role→model
assignments. Before the fix:

| Source | Field | Claimed | Manifest truth |
|---|---|---|---|
| README_PRODUCTION.md | Adversarial challenger | `qwen3:32b` | `ornith:9b` |
| README_PRODUCTION.md | Synthesizer | `qwen2.5:14b-instruct` | `qwen3.8:27b` |
| synthesis/model_hierarchy.json | king_synthesizer.model | `qwen3:14b` | `qwen3.8:27b` (MODELS.SYNTHESIZER) |

The hierarchy divergence is not cosmetic: `synth_king.py:1325` resolves
`king_cfg.get("model", args.model_synth)` — the hierarchy value is used FIRST
and the manifest SYNTHESIZER is only the fallback, so the king synthesizer was
silently running on the wrong model relative to the package-level assignment.
(CRITIC↔cross_channel.critique already matched: `qwen3:8b`.)

## Repair

- README: both bullets corrected to manifest values.
- model_hierarchy.json: king_synthesizer.model → `qwen3.8:27b`; `updated_at`
  bumped; `reconciliation_note` added (validator accepts extra keys —
  `validate_role_entry` requires only role/model). All other hierarchy roles
  have no SYSTEM_MANIFEST counterpart and are unchanged.
- Post-edit mechanical proof: `validate_model_hierarchy(load_critical_json(...))`
  and synthesis-contract validation both run clean against the edited file
  (king model reads back `qwen3.8:27b`).

## qwen3.8:27b verification — VERIFIED [B], no E-3 park needed

Queue: verify the tag against local Ollama manifest evidence or flag [U].
Evidence captured 2026-08-28T03:24Z (`ollama-local-evidence.txt`):

- Registry manifest file `C:\Users\Sslaw\.ollama\models\manifests\registry.ollama.ai\library\qwen3.8\27b`
  present — sha256 `22130167c4c20e20c7b71454612966ca8e8171e9b3cc8ab6ce8aa6cbfec79643`, 950 B.
- Live loopback `http://127.0.0.1:11434/api/tags` → HTTP 200, 54 installed tags, includes `qwen3.8:27b`.
- Cross-check: all five manifest assignments (`qwen3:14b`, `ornith:9b`, `qwen3:8b`,
  `qwen3.8:27b`, `nomic-embed-text:latest`) AND both hierarchy-extra tags
  (`qwen2.5:14b-instruct`, `dolphin3:8b`) → installed=True.

## New mechanical gate

`tools/release/check_model_consistency.py` — explicit label→key map for the five
README bullets, king↔SYNTHESIZER and critique↔CRITIC checks; no globs.
`test_check_model_consistency.py` — 5 tests (synthetic pass, README mismatch,
missing bullet, king mismatch, real-worktree consistency).

## Evidence (measured)

- `fail-before-output.txt`: **FAIL exit 1 — exactly the 3 PROBLEMs above** (checker);
  test suite 4/5 (real-worktree consistency test failing).
- `pass-after-output.txt`: **PASS exit 0**.
- `unit-test-output.txt`: **5/5 OK**.
- `ollama-local-evidence.txt`: tag list + cross-check + registry manifest hashes.

## Changed files (commit `5b29a2e`)

`modules/sovereign/README_PRODUCTION.md`, `modules/sovereign/synthesis/model_hierarchy.json`,
`tools/release/check_model_consistency.py` (NEW), `tools/release/test_check_model_consistency.py` (NEW).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
