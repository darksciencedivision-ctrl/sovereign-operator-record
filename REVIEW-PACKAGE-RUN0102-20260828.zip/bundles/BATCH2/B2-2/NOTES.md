# B2-2 — C-3 current provenance + RELEASE-MANIFEST (CRITICAL) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 2 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `66e43b59c50034fce72c48b41d537b25fc880163` (parent `f1d9304`)
**UTC:** 2026-08-28T02:30–02:37Z

## Scope executed

1. **Current INSTALL-PROVENANCE.json generated for debate, sow, distillery** — against the
   candidate's ACTUAL CONTENTS, mechanically, via NEW `tools/release/generate_module_provenance.py`
   (stdlib-only, deterministic, dry-run by default):

   | Module | Content digest (`source_sha256`) | Files | Version |
   |---|---|---|---|
   | debate | `dface6ca252514b1253e059d602a36b4350c1447a45a223210c396007f49c0a5` | 53 | v1.2.1-hardening |
   | sow | `57923d8f29091587f39b70551bcdad42e186b4afc92f055931608453c2fb4abf` | 960 | 0.1.0 (sovereign-desktop) |
   | distillery | `93a0c692340dce46c7ec5f170253b86304896593ba6e984392d0dfc8a8342f6f` | 212 | 1.1.0rc3 |

   Digest method (recorded in every record's `source_sha256_basis`): SHA-256 over the sorted
   `<sha256>  <relpath>` lines of all files under `modules/<m>/` at generation time, excluding
   the module's own INSTALL-PROVENANCE.json. Locks/artifacts re-hashed on the spot (debate lock
   `2ff25bb5…`, sow package-lock `573eba33…`, distillery wheel `15fad107…` / sdist `c9b556ce…`).
   `lineage_history` carries the preserved legacy records' claims marked as history, with [U]
   where unverified (debate release ZIP d03ba417…, sow upstream e6fcb89, distillery commit
   6cd9886); the sow record explicitly flags canonical lineage UNRESOLVED pending OD-20 (H-5) —
   the record describes candidate bytes; it adjudicates nothing.

2. **Legacy supersession files untouched** under their existing names:
   `debate/INSTALL-PROVENANCE.previous.json`, `sow/INSTALL-PROVENANCE.previous.json`,
   `distillery/INSTALL-PROVENANCE.json.previous`, plus distillery's
   `INSTALL-MANIFEST.txt.previous` — all preserved byte-identical, none renamed (R2 §8;
   one-time naming normalization happens only via manifest enumeration, per C-3 design).

3. **`RELEASE-MANIFEST.json` (worktree root)** — enumerates per module: current provenance path
   + record sha256, superseded paths, source identity (kind/digest/lineage), locks, module
   manifests, artifacts; plus candidate baseline identity (ZIP `75e4be07…`, initial commit
   `cf50cde`, generation commit `f1d9304`) and the release-tool set. Every hash measured by the
   builder seat 2026-08-28.

4. **Validation logic reads the manifest, never globs** — NEW `tools/release/release_manifest_check.py`:
   verifies every enumerated path exists and every enumerated hash matches measured bytes;
   record↔manifest source-identity consistency enforced; glob-like enumerated paths rejected by
   test (`test_no_glob_enumeration`).

## Evidence (measured)

- Fail-before state: B2-1's `pass-after-check.txt` shows debate/sow/distillery **PENDING — no
  current record** (the C-3 defect) and distillery's record absent; generator dry-run
  (`dry-run-output.json`) precedes any write.
- `pass-after-manifest-check.txt`: `release_manifest_check` → **PASS, 0 problems** on the real
  manifest.
- `pass-after-cross-check.txt`: `provenance_cross_hash_check` → **PASS**: sovereign/debate/sow/
  distillery OK; tokencenter PENDING by design (copy-based record left byte-identical; no source
  archive digest exists for it).
- `unit-test-output.txt`: **13/13 OK** — 6 manifest-validator tests (real manifest PASS; corrupted
  record-hash detected; corrupted lock-hash detected; missing superseded path detected;
  source-identity inconsistency detected; no-glob enumeration) + 7 cross-hash tests.

## Changed files (commit `66e43b5`)

NEW: `modules/debate/INSTALL-PROVENANCE.json`, `modules/sow/INSTALL-PROVENANCE.json`,
`modules/distillery/INSTALL-PROVENANCE.json`, `RELEASE-MANIFEST.json`,
`tools/release/generate_module_provenance.py`, `tools/release/release_manifest_check.py`,
`tools/release/test_release_manifest_check.py`.
MODIFIED: `tools/release/module_source_registry.json` (content digests registered; distillery
foreign hash retained under `historical_source_hashes`), `tools/release/provenance_cross_hash_check.py`
(historical-hash ownership). 9 files, +747/−16.

## Accepted limitations

- tokencenter stays PENDING in the cross-hash check: its existing record is copy-based and was
  left byte-identical (no rewrite authorized by the queue); the manifest documents its identity.
- Distillery source-archive digest `620e8459…` remains registered from the three-seat-converged
  [B] claim; independent re-hash of that archive is still [U] (archive not located on this disk).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
