#!/usr/bin/env python
"""One-shot ledger builder for B2-4: maps the scanner's exact unjustified keys
(in full-keys.json order) to their byte-verified justifications and merges
them into tools/release/innerhtml_audit.json. Asserts full coverage."""
import json
import sys

KEYS = json.load(open(r"D:\producttion software 2\release-planning\bundles\BATCH2\B2-4\full-keys.json", encoding="utf-8"))

REASONS = [
    ("STATIC", "renderer.js:641 — ternary with string-literal branches only (class-name switch)."),
    ("ESCAPED-BY-CONSTRUCTION", "renderer.js:641 — branches are the literal \"READY\" or esc(n.mcp_state || n.node_state)."),
    ("STATIC", "renderer.js:645 — ternary with string-literal branches only (class-name switch)."),
    ("ESCAPED-BY-CONSTRUCTION", "msgRow builder renderer.js:643-644 wraps every interpolation in esc() (message_kind, sender_node_id, recipient join, body, message_id)."),
    ("ESCAPED-BY-CONSTRUCTION", "debateRow builder renderer.js:645-648 wraps every dynamic field in esc(); the only un-esc'd value is (d.turns || []).length, a language-guaranteed integer."),
    ("STATIC", "renderer.js:656 — ternary branches are a static markup literal and the empty string."),
    ("ESCAPED-BY-CONSTRUCTION", "gateRow builder renderer.js:656-657 esc()s verdict/author/entryStatus; the || fallback is a static literal (renderer.js:664)."),
    ("ESCAPED-BY-CONSTRUCTION", "artRow builder renderer.js:658-659 esc()s kind/status/hash-slice/author; the || fallback is a static literal (renderer.js:665)."),
    ("STATIC", "renderer.js:682 — ternary branches are the empty string and a static markup literal."),
    ("ESCAPED-BY-CONSTRUCTION", "gateRow builder renderer.js:656-657 esc()s every dynamic field (renderer.js:689 call site)."),
    ("ESCAPED-BY-CONSTRUCTION", "artRow builder renderer.js:658-659 esc()s every dynamic field (renderer.js:689 call site)."),
    ("ESCAPED-BY-CONSTRUCTION", "degraded built at renderer.js:628 — either \"\" or a template whose only dynamic value is esc(res.error) with a static fallback."),
    ("ESCAPED-BY-CONSTRUCTION", "nodeRow builder renderer.js:640-642 esc()s role/provider_id/model_id/state/node_id/pane_id/pid/mcp_state; the || fallback is a static literal (renderer.js:674)."),
    ("ESCAPED-BY-CONSTRUCTION", "operationalTask builder renderer.js:649-654 esc()s task_id/status/objective/owners and delegates to msgRow/debateRow (both esc-only); both ternary fallbacks are static literals (renderer.js:675-677)."),
    ("ESCAPED-BY-CONSTRUCTION", "taskCard builder renderer.js:660-665 esc()s taskId/role and (since B2-4) contextRouted.count, and delegates to gateRow/artRow (esc-only); both ternary fallbacks are static literals (renderer.js:684-686)."),
    ("STATIC", "renderer.js:736 — ternary with string-literal branches only (button caption)."),
    ("ESCAPED-BY-CONSTRUCTION", "chips built at renderer.js:819-823 — every interpolation esc()d (state, subscriptionRef/provider, provider label, count label); the || fallback is a static literal (renderer.js:826)."),
    ("STATIC", "warn built at renderer.js:824-825 — either a static markup literal or \"\"."),
    ("STATIC", "renderer.js:875 — ternary with string-literal branches only (class fragment)."),
    ("GUARANTEED-INTEGER", "oidx is the array index from flat.map((o, i) => ...) captured in the idxOf Map (renderer.js:895, 900-901) — always a non-negative integer; rendered into a data- attribute at renderer.js:875."),
    ("ESCAPED-BY-CONSTRUCTION", "slug built at renderer.js:874 — esc(o.model_slug), or the static literal <span class=\"pk-slug\">CLI default</span>, or \"\"."),
    ("ESCAPED-BY-CONSTRUCTION", "residencyChip builder renderer.js:862-865 — esc(o.residency) in both attribute and text position, else \"\"."),
    ("ESCAPED-BY-CONSTRUCTION", "roleSel built at renderer.js:869-870 — esc(r) for every option value and label; data-oidx carries the same integer index as #20; \"\" when greyed/conductorTarget."),
    ("ESCAPED-BY-CONSTRUCTION", "action built at renderer.js:871-873 — esc(o.unavailable_reason) in the title attribute; button captions are static literals; data-oidx is the integer index."),
    ("STATIC", "renderer.js:896 — ternary with string-literal branches only (class-name switch)."),
    ("STATIC", "renderer.js:896 — ternary with string-literal branches only (status text)."),
    ("ESCAPED-BY-CONSTRUCTION", "target built at renderer.js:897 — either the static literal \"target: new pane\" or esc(pickerTarget)."),
]

assert len(KEYS) == len(REASONS), f"key/reason mismatch: {len(KEYS)} vs {len(REASONS)}"

ledger_path = r"D:\producttion software 2\release-worktree\tools\release\innerhtml_audit.json"
ledger = json.load(open(ledger_path, encoding="utf-8"))
just = ledger.setdefault("justifications", {})
for key, (cls, reason) in zip(KEYS, REASONS):
    just[key] = {"class": cls, "reason": reason}
with open(ledger_path, "w", encoding="utf-8", newline="\n") as f:
    json.dump(ledger, f, indent=2, ensure_ascii=False)
    f.write("\n")
print(f"ledger now carries {len(just)} justifications")
