# B2-4 — M-3 renderer.js innerHTML classification + hazard fix (MEDIUM) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 2 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `d7441dd9d746b18a52127c195e3d1d53d85b7cc6` (parent `10679bf`)
**UTC:** 2026-08-28T02:53–03:36Z

## Audit table — all 17 innerHTML sites in `modules/sow/apps/desktop/renderer/renderer.js`

| # | Line | Site | Pre-fix class | Post-fix class |
|---|------|------|---------------|----------------|
| 1 | 40 | `ensurePane` pane chrome | STATIC | STATIC |
| 2 | 456 | `rail.innerHTML` (collapsed-pane cards) | ESCAPED | ESCAPED |
| 3 | 504 | `min.innerHTML` (minimized panes) | ESCAPED | ESCAPED |
| 4 | 506 | comment mentioning innerHTML — not a sink | n/a | n/a |
| 5 | 530 | recovery banner `el.innerHTML = interruptedNotice` | **HAZARD** (builder's `layout.summary.workers` unescaped) | ESCAPED-BY-CONSTRUCTION (builder esc'd + ledger) |
| 6 | 570 | same `interruptedNotice` assignment | **HAZARD** (same builder) | ESCAPED-BY-CONSTRUCTION |
| 7 | 625 | inspector error banner | ESCAPED | ESCAPED |
| 8 | 668 | `renderInspector` main template | **HAZARD** (8 feed counts + nested `t.contextRouted.count` unescaped) | ESCAPED |
| 9 | 696 | "reading MCP state…" | STATIC | STATIC |
| 10 | 726 | approvals error banner | ESCAPED | ESCAPED |
| 11 | 738 | approvals summary; concatenations `approvalOutcomeLine()` + `rows.map(row)` verified esc-only at :759 / :731-737 | ESCAPED | ESCAPED |
| 12 | 786 | "reading approvals…" | STATIC | STATIC |
| 13 | 826 | status bar (`chips` esc-built :819-823, `warn` static :824-825) | ESCAPED | ESCAPED |
| 14 | 856 | "enumerating host models…" | STATIC | STATIC |
| 15 | 882 | picker error banner | ESCAPED | ESCAPED |
| 16 | 907 | picker head row | **HAZARD** (`counts.available` / `counts.total` unescaped) | ESCAPED |
| 17 | 1081 | `return body ? body.innerHTML : null` — a READ, not a sink | n/a | unchanged |

Delegated builder outside this file: `PickerChrome.providerGroupHtml(g, opts, esc)` at :905 —
built in `picker-chrome.js`, receives `esc`; outside this file's audit scope, noted for the
reviewer.

## Hazards fixed (5 edit sites, 12 interpolations esc-wrapped)

1. `layout.summary.workers` (:560) → `esc(layout.summary.workers)`
2. `t.contextRouted.count` (:662, nested template inside taskCard) → `esc(...)`
3. `op.summary.task_count` / `message_count` / `debate_count` (:672) → `esc(...)` ×3
4. `summary.taskCount` / `artifactCount` / `gateCount` / `unattributedCount` / `anomalyCount` (:680-681) → `esc(...)` ×5
5. `counts.available || 0` / `counts.total || 0` (:908) → `esc(...)` ×2

Zero behavior change for honest numeric values (esc of a digit string is the identity).

## Mechanical gate (NEW)

- `tools/release/innerhtml_sink_audit.py` — walks every `.innerHTML =` RHS (through `.map(...)`
  callbacks), plus ledger-enumerated `construction_fragments` and their **scope closure**
  (templates nested inside in-scope templates), string/regex/comment/nesting-aware lexer.
  Classes: ESCAPED (`esc(...)`), GUARANTEED (numeric / `.length`), COMPOSITE (nested-template
  ternaries — leaves scanned separately), MUST-JUSTIFY (needs a ledger entry).
- `tools/release/innerhtml_audit.json` — 13 construction fragments + **27 byte-level
  justifications** for the remaining MUST-JUSTIFY interpolations (static ternaries, esc-only
  row-builder delegations, the integer `oidx` index). No globs — explicit enumeration.
- `tools/release/test_innerhtml_sink_audit.py` — 12 tests (nesting, regex-quote immunity,
  backtick-in-string/comment immunity, classification, ledger clearing, scope-closure proof).

## Evidence (measured)

- `fail-before-scan.txt` — scan vs empty ledger: **FAIL, 39 unjustified** incl. every hazard
  value (and `t.contextRouted.count` caught only via scope closure). An earlier over-inclusive
  pass (scan of ALL templates, 107 unjustified) was discarded in favor of the scoped gate.
- `pass-after-scan.json` — **PASS, 0 unjustified / 112 interpolations** (73 ESCAPED, 3
  GUARANTEED, 9 COMPOSITE, 27 ledger-justified).
- Scanner self-tests: **12/12 OK**.
- Affected suite: `node --test test/*.test.js` in `modules/sow/apps/desktop` →
  **1104/1104 pass** (no node_modules needed — native node:test runner).

## Changed files (commit `d7441dd`)

`modules/sow/apps/desktop/renderer/renderer.js` (5 hazard edits),
`tools/release/innerhtml_sink_audit.py` (NEW), `tools/release/innerhtml_audit.json` (NEW),
`tools/release/test_innerhtml_sink_audit.py` (NEW).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
