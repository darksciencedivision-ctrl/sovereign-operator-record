# B2-8 — M-9 Distillery serve.py host validation + CSP + nosniff + no-referrer (MEDIUM) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 2 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `7b7431f5805f6d131ace55e4fe4e005037a4a2aa` (parent `5b29a2e`)
**UTC:** 2026-08-28T03:50–04:07Z

## Defect

`modules/distillery/serve.py` (health-only console, bound 127.0.0.1:5184):
no Host-header validation (DNS-rebinding class), no security headers on any
response, and the console HTML carried an inline `<style>` block that would
have blocked a strict CSP.

## Repair (minimal, mirrors the B2-3 piggybank pattern)

- Host validation: `do_GET` refuses (HTTP 403 via `send_error`) any request
  whose Host header is not exactly `127.0.0.1:<bound port>` — foreign hosts,
  `localhost` names, port mismatches, prefix-confusion hosts, and missing
  Host headers are all rejected.
- Security headers on EVERY response (200/403/404, `send_error` included, via
  a `send_response` override): strict
  `Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'`,
  `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`,
  `Referrer-Policy: no-referrer`. No `unsafe-inline` anywhere.
- Inline `<style>` extracted to a new `/console.css` route (text/css) linked
  from the console head — strict CSP with zero inline surface.
- Health-only contract preserved (module docstring): idle, no compute,
  "runtime only; pipeline not invoked".

## Tests — `modules/distillery/tests/test_m9_serve_hardening.py` (12 tests)

- Host validation (6): bound-loopback passes; default-port-on-other-port,
  `127.0.0.1.evil.example`, `evil.example`, `localhost:<port>` refused; raw
  socket request with no Host header → 403.
- Security headers (4): /health, /console (plus no-`<style>` + `/console.css`
  link assertions), /console.css (text/css), and 404 responses.
- Console contract (2): health reports `compute: false` / `idle`; console
  states "runtime only; pipeline not invoked".

## Evidence (measured)

- `fail-before-output.txt`: shipped serve.py vs new suite → **9/12 FAIL**
  (only the two health-contract tests and bound-host pass pre-fix).
- `pass-after-output.txt`: **12/12 OK**; `python -m py_compile serve.py` exit 0.
- Package gate re-check: `package_boundary_gate: PASS (files scanned: 3590,
  violations: 0, credential hits: 0, quarantined-historical: 2059)`.

## State restoration (recorded; no baseline bytes touched)

Mid-item the package gate reported 102 violations: 34 untracked git-ignored
`__pycache__` dirs (101 `.pyc` — 97 cpython-312, 4 cpython-314) plus one
untracked runtime `modules/tokencenter/data/piggybank.sqlite`. Verified
in-memory that the frozen SYSTEM ZIP contains ZERO pyc entries, and file-count
arithmetic (B1-1 scan 3568 files vs now) shows these appeared after the B1-1
PASS scan. All deleted (untracked cache/runtime state only; git check-ignore
confirmed ignored). Gate back to PASS.

**Anomaly for T-2 [B]:** the `.pyc` caches were created 2026-08-28T03:12–03:35Z
(local 22:12–22:35) — inside this session's B2-6/B2-7 window — yet this seat's
commands ran only C:\Python314 (cpython-314 tags would be expected) with
`PYTHONDONTWRITEBYTECODE=1` set, and never imported the sow modules that carry
the 97 cpython-312 caches. A Python 3.12 interpreter EXISTS on this host
(`C:\Users\Sslaw\AppData\Local\Programs\Python\Python312\python.exe`). An
unattributed process on this machine imported the worktree's sow modules under
Python 3.12 (and sovereign/distillery under 3.14) during that window. No
baseline bytes were affected; the tree has been restored, but the operator may
wish to identify the process (candidate: another agent harness's venv python —
`C:\Users\Sslaw\AppData\Local\hermes\hermes-agent\venv` is on PATH).

## Changed files (commit `7b7431f`)

`modules/distillery/serve.py`, `modules/distillery/tests/test_m9_serve_hardening.py` (NEW).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
