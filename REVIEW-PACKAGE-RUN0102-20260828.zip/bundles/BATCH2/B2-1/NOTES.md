# B2-1 — C-2 SOVEREIGN provenance foreign hash (CRITICAL) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 2 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `f1d9304d64221403333df5e1318617b2ea1922d3` (parent `3ad0720`)
**UTC:** 2026-08-28T02:23–02:29Z

## Defect (pre-flight byte-verified)

`modules/sovereign/INSTALL-PROVENANCE.json` carried `source_sha256
620e8459c74fb5fe9d2dfe0c4693cea02b8346292804d2d2a01fb71cb615be96` — the **Distillery** source
digest — against the SOVEREIGN archive, with `operator_authorized: null` and a self-attested
`integrity_verified: true` on that foreign digest.

## Repair

1. **Wrong record preserved byte-identical** as `modules/sovereign/INSTALL-PROVENANCE.previous.json`
   (sha256 `ea96af3fe4d7dc6ad8b63ce5a04082707ee110b99aaccde9f5b790ccd41b04f9`; copy hash equals
   original). Classified historical defective record per R2 §8 — not renamed, not rewritten.
2. **New current record** with `source_sha256
   150e518e6d0b15b524ff61cda8fe8eb29aec6bbfb30196f9931908d12ff7ec51`, **independently re-hashed
   this session** (Get-FileHash SHA256 over
   `D:\Product Software\SOVEREIGN_ENTERPRISE_PRODUCTION_20260813_142520.zip`, 453,948 B, on the
   operator's disk) — the punch-list's "real" hash, now measured, not merely cited. The record's
   other claims were re-verified mechanically: `PACKAGE_MANIFEST.txt` → `d2fa7633…` MATCH,
   `WORKSPACE-RESOLVED-LOCK.txt` → `1a850957…` MATCH. `operator_authorized` stays `null`
   (no operator authorization artifact exists — honesty preserved); `integrity_verified: true`
   now carries a `verification_basis` string naming the measurement.
3. **Mechanical cross-module-hash rejection** (new tooling):
   - `tools/release/module_source_registry.json` — explicit per-module enumeration
     (module → exact provenance path + registered source hash; debate/sow/distillery/tokencenter
     `pending` until B2-2).
   - `tools/release/provenance_cross_hash_check.py` — verdicts OK / CROSS / UNKNOWN / MISSING /
     PENDING; exit 0/1/2; no filename globbing anywhere (enumeration authority = registry, later
     RELEASE-MANIFEST.json per the C-3 design).

## Evidence (measured)

- `fail-before-check.txt`: checker on the pre-repair tree → **exit 1, sovereign CROSS
  ("source_sha256 belongs to module(s): distillery")**, distillery MISSING (C-3's job), others
  PENDING.
- `pass-after-check.txt`: post-repair → **exit 0 PASS, sovereign OK**; debate/sow/distillery
  PENDING (records generated in B2-2); tokencenter PENDING (identity registration in B2-2).
- `unit-test-output.txt`: `test_provenance_cross_hash_check.py` → **7/7 OK** (cross rejection,
  own-hash pass, unknown rejection, missing rejection, pending handling, glob-path config error,
  real-worktree sovereign OK). Fail-before: 6/7 + the worktree test failing on CROSS.

## Changed files (commit `f1d9304`)

`modules/sovereign/INSTALL-PROVENANCE.json` (rewritten),
`modules/sovereign/INSTALL-PROVENANCE.previous.json` (preserved defective record, NEW path),
`tools/release/module_source_registry.json` (NEW),
`tools/release/provenance_cross_hash_check.py` (NEW, 154 lines),
`tools/release/test_provenance_cross_hash_check.py` (NEW, 7 tests).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
