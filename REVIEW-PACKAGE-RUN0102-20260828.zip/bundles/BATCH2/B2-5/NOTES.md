# B2-5 — M-5 governance JSON BOM strip (MEDIUM) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 2 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `9567d48177f08ef3a381372a037f63de88bc0ea1` (parent `d7441dd`)
**UTC:** 2026-08-28T03:06–03:20Z

## Defect

All six ACTIVE governance JSONs under `modules/sovereign/` carried a UTF-8 BOM
(EF BB BF). Strict-utf-8 JSON parsers — Python's own `json.loads(text.read_text(encoding='utf-8'))`,
`json.load` on a utf-8 stream, and most non-Python tooling — reject them with
`JSONDecodeError: Unexpected UTF-8 BOM (decode using utf-8-sig)`. Only the
codebase's `utf-8-sig` readers survived; any future strict reader (or external
validator) fails closed on governance data.

## Repair (byte-exact)

| File | Before → after (bytes) | New sha256 |
|---|---|---|
| SYSTEM_MANIFEST.json | 536 → 533 | `daa3c55a34a15faefef60767cf66a0069583ada58769261b0c54c8641bd2af4b` |
| constitution/constitutional_rules.json | 1014 → 1011 | `c8ec752145c439532d95632a16b9651d7af57b9094948314eca4cd3b2a0cc3ae` |
| constitution/promotion_policy.json | 821 → 818 | `142ac767fea03aab0d25fc8f4e2f97e0d786ef1e434c8f32179d9e731a646a2c` |
| constitution/risk_policy.json | 644 → 641 | `72df27aafb6fbb5cac4e70b74d4ba84a923682f2a6bf288877dd12d86bfcdab1` |
| library/config/clu_runtime_policy.json | 340 → 337 | `d18b18e4ec6a9f04787e492dbf29a2a5836d97a3fc996814d83b15fec3326ac6` |
| synthesis/synthesis_contract.json | 1124 → 1121 | `d8452345bcc9aa129270405528caf370b2847212e82f495a560ab2991ec8c2f5` |

Exactly the 3-byte BOM prefix removed from each; no other byte touched.

**Re-BOM writer fixed:** `sovereign_product/server.py::_write_manifest` wrote
SYSTEM_MANIFEST.json with `encoding="utf-8-sig"`, re-adding the BOM on every
manifest update. Now plain `utf-8` — the strip sticks.

## Consumer verification (byte-level, no trust)

- `system_manifest.py:185` — reads `utf-8-sig` → accepts BOM-less content ✓
- `sovereign_product/server.py:398` — reads `utf-8-sig` ✓; `:652` writer fixed
- `synthesis/synth_king.py:55` `load_critical_json` — `utf-8-sig` ✓ (synthesis_contract.json)
- `cycle_runner_v3.py:124/133` and `knowledge_base/common.py:63` — `utf-8-sig` ✓ (clu_runtime_policy.json)
- constitution/promotion/risk policy JSONs: no Python reader references them by name — they are
  governance documents consumed by inspection; BOM strip removes the hazard for any strict tool.
- `server.py` compiles (`py_compile` exit 0).

## Evidence (measured)

- `fail-before-output.txt`: all six → **strict utf-8 parse FAILS** (`JSONDecodeError: Unexpected
  UTF-8 BOM`), utf-8-sig parse OK.
- `pass-after-output.txt`: all six → **strict utf-8 OK AND utf-8-sig OK** (no reader regression).
- `check_governance_bom.py --root .` → **PASS** exit 0.
- `unit-test-output.txt`: **5/5 OK** (BOM detection, missing-file detection, clean pass; plus
  real-worktree: zero BOMs and strict-utf-8 parse of all six).

## Prospective convention (documented per M-5)

**Active governance/config JSONs in the release worktree are BOM-less UTF-8, LF.**
Evidence captures and quarantined historical lanes keep their original bytes untouched
(the envelope convention: evidence envelopes preserve producer bytes; active-tree files
obey the release encoding contract). `utf-8-sig` readers remain permitted as transitional
tolerance, but writers MUST emit BOM-less UTF-8. Enforcement: `tools/release/check_governance_bom.py`
(explicit enumeration of the six paths; extend the tuple when new governance JSONs land).
B3-6 applies the same BOM policy to active `.py` files per OD-21.

## Changed files (commit `9567d48`)

The six governance JSONs (BOM stripped), `modules/sovereign/sovereign_product/server.py`
(writer), `tools/release/check_governance_bom.py` (NEW), `tools/release/test_check_governance_bom.py`
(NEW, 5 tests).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
