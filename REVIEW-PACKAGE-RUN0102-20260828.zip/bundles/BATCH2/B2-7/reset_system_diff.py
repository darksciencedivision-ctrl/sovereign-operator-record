#!/usr/bin/env python
"""RESET-vs-SYSTEM baseline diff — SWS-REM-DIR-20260828 R2 B2-7 (OD-20).

Reads both frozen baseline ZIPs IN MEMORY (no extraction to disk), verifies
their sha256, hashes every file entry, normalizes paths relative to each
archive's 'Production Workspace/' lane, and classifies:

  SYSTEM_ONLY   file exists only in the SYSTEM baseline (the candidate tree)
  RESET_ONLY    file exists only in the RESET baseline
  SAME          present in both, byte-identical
  DIFFERENT     present in both, bytes differ (both hashes recorded)

Also enumerates the RESET archive's baseline-metadata files (outside the
Production Workspace lane). Output: JSON report. Stdlib-only, offline.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from datetime import datetime, timezone

SYSTEM_ZIP = r"D:\producttion software 2\SOVEREIGN_SYSTEM_BASELINE_20260827.zip"
SYSTEM_SHA = "75e4be075dcb5629c3175850f5aa3f342c7c693f2967c3620d6cd4914ac27138"
SYSTEM_PREFIX = "SOVEREIGN_SYSTEM_BASELINE_20260827/Production Workspace/"

RESET_ZIP = r"D:\producttion software 2\SOVEREIGN_RESET_BASELINE_20260827T193540Z.zip"
RESET_SHA = "00ae9eefc7dada37943bb08a305020c73e2c029a6398858e8bba27078c349a7c"
RESET_PREFIX = "SOVEREIGN_RESET_BASELINE_20260827T193540Z/Production Workspace/"


def sha256_zip(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def inventory(zip_path: str, prefix: str) -> tuple:
    """Return ({relpath: sha256}, [metadata entries outside the lane])."""
    files = {}
    meta = []
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            name = info.filename.replace("\\", "/")
            with zf.open(info) as fh:
                h = hashlib.sha256()
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            digest = h.hexdigest()
            if name.startswith(prefix):
                files[name[len(prefix):]] = digest
            else:
                meta.append({"path": name, "sha256": digest,
                             "size": info.file_size})
    return files, meta


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    for path, want in ((SYSTEM_ZIP, SYSTEM_SHA), (RESET_ZIP, RESET_SHA)):
        got = sha256_zip(path)
        if got != want:
            print(f"FATAL: {path} hash mismatch: {got}", file=sys.stderr)
            return 2

    print("hashing SYSTEM entries...", file=sys.stderr)
    system, system_meta = inventory(SYSTEM_ZIP, SYSTEM_PREFIX)
    print(f"  {len(system)} files", file=sys.stderr)
    print("hashing RESET entries...", file=sys.stderr)
    reset, reset_meta = inventory(RESET_ZIP, RESET_PREFIX)
    print(f"  {len(reset)} files", file=sys.stderr)

    skeys, rkeys = set(system), set(reset)
    same, different = [], []
    for p in sorted(skeys & rkeys):
        if system[p] == reset[p]:
            same.append(p)
        else:
            different.append({"path": p, "system_sha256": system[p],
                              "reset_sha256": reset[p]})
    report = {
        "directive": "SWS-REM-DIR-20260828 R2 / B2-7 (OD-20 dossier)",
        "utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "archives": {
            "system": {"path": SYSTEM_ZIP, "sha256": SYSTEM_SHA,
                       "production_workspace_files": len(system),
                       "outside_lane_entries": len(system_meta)},
            "reset": {"path": RESET_ZIP, "sha256": RESET_SHA,
                      "production_workspace_files": len(reset),
                      "outside_lane_entries": len(reset_meta)},
        },
        "counts": {"same": len(same), "different": len(different),
                   "system_only": len(skeys - rkeys),
                   "reset_only": len(rkeys - skeys)},
        "same_paths": same,
        "different": different,
        "system_only": sorted(skeys - rkeys),
        "reset_only": sorted(rkeys - skeys),
        "reset_metadata_outside_lane": reset_meta,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1)
    print(json.dumps(report["counts"], indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
