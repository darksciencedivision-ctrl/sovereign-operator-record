# BATCH 2 REPORT — SWS-REM-DIR-20260828 R2
## builder qwen3.8-max · 2026-08-28T01:45–04:10Z · seat: BUILDER (CANDIDATE only)

**Queue segment:** BATCH 2 (B2-1 … B2-8), executed to exhaustion with no stops,
no operator questions, no PASS claims. Reviewer seat (chatgpt) absent → every
item stays **CANDIDATE**.

---

## Item outcomes

| Item | Finding | Subject | Commit | Verdict |
|---|---|---|---|---|
| B2-1 | C-2 | sovereign INSTALL-PROVENANCE wrong source hash; wrong record preserved byte-identical as `.previous.json`; cross-module-hash rejection added to the registry gate | `f1d9304` | CANDIDATE |
| B2-2 | C-3 | current INSTALL-PROVENANCE records for debate/sow/distillery via deterministic content-digest generator; RELEASE-MANIFEST.json + validator | `66e43b5` | CANDIDATE |
| B2-3 | M-1 full | tokencenter exact-Origin parse, bodyless mutation guard (incl. chunked raw-socket refusal), security headers on every response | `10679bf` | CANDIDATE |
| B2-4 | M-3 | renderer.js innerHTML: 17-site ledger, 12 hazard interpolations esc-wrapped, scope-closing scanner + byte-justified audit gate | `d7441dd` | CANDIDATE |
| B2-5 | M-5 | six active governance JSONs de-BOM'd (3 bytes each); re-BOM writer fixed (`utf-8-sig`→`utf-8`); BOM regression guard | `9567d48` | CANDIDATE |
| B2-6 | M-6 | README_PRODUCTION.md + model_hierarchy.json reconciled to SYSTEM_MANIFEST.json; qwen3.8:27b VERIFIED [B] on local Ollama; consistency gate | `5b29a2e` | CANDIDATE |
| B2-7 | OD-20 dossier | RESET-vs-SYSTEM full in-memory diff + lineage dossier + per-file dispositions (NO code changes) | bundle only | CANDIDATE |
| B2-8 | M-9 | distillery serve.py Host validation + strict CSP (external /console.css) + nosniff/DENY/no-referrer | `7b7431f` | CANDIDATE |

**Parked items in BATCH 2: none.** No E-1..E-6 exceptions triggered (B2-6's
qwen3.8:27b was verified against live local Ollama evidence, so no [U] flag
and no E-3 park was needed).

## Measured test/evidence totals (all executed by this seat)

- B2-1: registry tests 7/7 OK; sovereign record sha `3c0c98e4…`; wrong record preserved at sha `ea96af3f…`.
- B2-2: generator/checker tests 13/13 OK; RELEASE-MANIFEST validator PASS, 0 problems; current records debate `74391d8c…` / sow `1183f3cd…` / distillery `e9e555d9…`.
- B2-3: new hardening suite 20/20 + existing contract suite 6/6 = 26/26; full tokencenter 31/31 OK.
- B2-4: scanner/ledger tests 12/12 OK; sow desktop suite 1104/1104 OK; audit PASS — 0 unjustified / 112 interpolations.
- B2-5: BOM guard tests 5/5 OK; six files each lost exactly 3 bytes; `server.py` compiles.
- B2-6: consistency gate fail-before (3 PROBLEMs) → pass-after PASS; 5/5 tests OK; `validate_model_hierarchy` + contract validation re-run clean; Ollama evidence file (tag list, cross-check, registry-manifest sha256 `22130167…`).
- B2-7: RESET ZIP hash re-verified (`00ae9eef…`); 1,511 same / 167 different / 1,902 SYSTEM-only / 234 RESET-only; 6 measured SYSTEM test errors attributed byte-precisely to the 3 RESET-only files.
- B2-8: fail-before 9/12 FAIL → pass-after 12/12 OK; package gate restored to PASS (3,590 files, 0 violations).

## Batch-end gate re-verification (all re-run at batch close)

- `check_governance_bom.py` PASS · `check_model_consistency.py` PASS ·
  `release_manifest_check.py` PASS (0 problems) · `provenance_cross_hash_check.py`
  PASS (sovereign/debate/sow/distillery OK; tokencenter PENDING by design —
  copy-based record carries no source digest) · `innerhtml_sink_audit.py` PASS
  (0 unjustified) · `package_boundary_gate.py` PASS (0 violations, 0 credential hits).

## Worktree state

Branch `main`, clean working tree. Commit chain:
`cf50cde`(P0-2) → `cbaabe7`(B1-1) → `29f4dc9`(B1-2) → `3ad0720`(B1-3) →
`f1d9304` → `66e43b5` → `10679bf` → `d7441dd` → `9567d48` → `5b29a2e` → `7b7431f` (BATCH 2 head).
One commit per item; scoped `git add` only; deterministic author/committer dates.

## Recorded observations for T-2

1. **B2-8 anomaly [B]** — 101 untracked `.pyc` caches (97 cpython-312 + 4
   cpython-314) appeared in the tree at 2026-08-28T03:12–03:35Z although this
   seat ran only Python 3.14 with `PYTHONDONTWRITEBYTECODE=1` and never
   imported the affected sow modules; a Python 3.12 interpreter exists on this
   host. Caches deleted (not baseline bytes — the frozen SYSTEM ZIP contains
   zero pyc entries; B1-1 PASS pre-dates them). See B2-8 NOTES §"Anomaly".
2. **B2-7 [U] trail** — why SYSTEM dropped the three RESET-only files while
   keeping their consumers; G64's before-b hash FALSE; upstream `e6fcb89`
   unverifiable from this disk. All inside `OD-20-LINEAGE-DOSSIER.md` §6.
3. **RESET SOURCE_SELECTION.json** independently corroborates the Distillery
   ENTERPRISE digest `620e8459c7…` (sidecar_match true) — second-source [B]
   for the B2-1 registry note.
4. Debate's RESET-side INSTALL-PROVENANCE (`02599703…`) DIFFERS from SYSTEM's
   preserved previous record (`cb31f238…`) — both kept; flagged for the
   adjudicator (dossier §4).

## Bundles

`bundles\BATCH2\B2-1 … B2-8\` (NOTES.md + fail-before/pass-after evidence per
item) and `bundles\BATCH2\OD-20-LINEAGE-DOSSIER.md` + `bundles\BATCH2\B2-7\`
(diff generator + full diff JSON + RESET file analysis + failure-mode capture).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
