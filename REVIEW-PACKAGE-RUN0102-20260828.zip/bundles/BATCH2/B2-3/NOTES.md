# B2-3 — M-1 full Token Center hardening (MEDIUM) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 2 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `10679bff816e2f052c38313acea83aba4cebcb0d` (parent `66e43b5`)
**UTC:** 2026-08-28T02:37–02:53Z

## Defects closed (M-1 remainder after B1-2)

1. **Prefix-Origin flaw** — `origin.startswith("http://127.0.0.1")` accepted
   `http://127.0.0.1.evil.example`, wrong-port origins, and trailing-garbage
   (`…@evil.example`). Replaced with EXACT equality against the serving origin
   `http://127.0.0.1:<bound port>` (`_expected_origin()`).
2. **No mutation input guard** — the bodiless refresh endpoint accepted bodies and
   form encodings. Now: `Transfer-Encoding` refused; `Content-Length` must parse and
   equal 0 (malformed refused); `application/x-www-form-urlencoded` and `multipart/*`
   Content-Types refused even when empty — every classic HTML-form CSRF carrier dies
   at the gate.
3. **No response headers** — every Token Center response now carries, via a
   `send_response` override (so `send_error` 403/404 paths included):
   - `Content-Security-Policy`: `default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; object-src 'none'; base-uri 'none'`
     (strict 'self' verified safe: `static/index.html` carries ONLY external `/app.js`
     and `/styles.css`; no inline script/style/handlers),
   - `X-Content-Type-Options: nosniff`,
   - `X-Frame-Options: DENY` (belt-and-braces with `frame-ancestors 'none'`),
   - `Referrer-Policy: no-referrer`.

## New suite: `tests/test_m1_hardening.py` (20 tests)

| Group | Tests | Proves |
|---|---|---|
| ExactOriginTests | 6 | same-origin passes; prefix-confusion / foreign / wrong-port / https / trailing-garbage all 403 with a VALID token |
| MutationGuardTests | 5 | zero-body passes; nonzero body, form ctype (empty), multipart ctype, chunked (raw-socket request so urllib can't normalize it away) all 403 |
| SecurityHeaderTests | 7 | all four headers present on index, app.js, summary, token endpoint, successful refresh, 403 error, 404 error |
| TokenLifecycleTests | 2 | token stable within a process; differs across independently constructed servers |

## Test-fidelity fix (disclosed)

`tests/test_csrf_contract.py` (B1-2) POST helper changed `data=b""` → `data=None`:
the old form made urllib auto-add `Content-Type: application/x-www-form-urlencoded`,
which a browser's bodiless `fetch()` never sends and which the new guard rightly
refuses. Same contract, faithful simulation.

## Evidence (measured)

- `fail-before-output.txt`: hardening suite against the B1-2 state → **Ran 20, FAILED
  (failures=14)** — every failure on the hardening surface (4 origin, 4 body/ctype,
  6 header; exact-origin/zero-body/https/foreign/lifecycle already held).
- `pass-after-output.txt`: **Ran 26, OK** (20 hardening + 6 B1-2 contract).
- Full module discovery: **Ran 31, OK**; evidence lane diff = 0 lines.

## Changed files (commit `10679bf`)

`modules/tokencenter/piggybank.py` (CSP const, send_response override,
_expected_origin, hardened do_POST), `modules/tokencenter/tests/test_m1_hardening.py`
(NEW, 20 tests), `modules/tokencenter/tests/test_csrf_contract.py` (helper fidelity).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
