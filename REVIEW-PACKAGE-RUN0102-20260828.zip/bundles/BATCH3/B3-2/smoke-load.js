"use strict";
// B3-2 ABI smoke: load node-pty under the real Electron main process (ABI 148)
// and record the outcome to a file (no window, no renderer, immediate quit).
const fs = require("node:fs");
const OUT = "D:\\producttion software 2\\release-planning\\bundles\\BATCH3\\B3-2\\electron-load-smoke.txt";
let line;
try {
  const pty = require("D:\\producttion software 2\\release-worktree\\modules\\sow\\apps\\desktop\\node_modules\\node-pty");
  line = `LOADED under electron ABI ${process.versions.modules}; spawn=${typeof pty.spawn}`;
  if (typeof pty.spawn === "function") {
    try {
      const p = pty.spawn(process.platform === "win32" ? "cmd.exe" : "/bin/sh", [], { cols: 10, rows: 2 });
      line += `; spawned pid=${p.pid}`;
      try { p.kill(); } catch { /* already gone */ }
    } catch (spawnError) {
      line += `; SPAWN FAIL: ${spawnError && spawnError.message ? spawnError.message.split("\n")[0] : spawnError}`;
    }
  }
} catch (e) {
  line = `LOAD FAIL: ${e && e.message ? e.message.split("\n")[0] : e}`;
}
fs.writeFileSync(OUT, line + "\n");
process.exit(0);
