import json
import subprocess

out = subprocess.run(
    ["git", "show", "HEAD:modules/sow/apps/desktop/package-lock.json"],
    capture_output=True, text=True, check=True,
    cwd=r"D:\producttion software 2\release-worktree")
old = json.loads(out.stdout)
new = json.load(open(
    r"D:\producttion software 2\release-worktree\modules\sow\apps\desktop\package-lock.json",
    encoding="utf-8"))

old_pkgs = {k: v.get("version", "") for k, v in old["packages"].items() if k}
new_pkgs = {k: v.get("version", "") for k, v in new["packages"].items() if k}

print("OLD entries:", len(old_pkgs), "| NEW entries:", len(new_pkgs))
print()
print("--- dropped (in old, not in new) ---")
for k in sorted(set(old_pkgs) - set(new_pkgs)):
    print(" ", k, old_pkgs[k])
print()
print("--- added (in new, not in old) ---")
for k in sorted(set(new_pkgs) - set(old_pkgs)):
    print(" ", k, new_pkgs[k])
print()
print("--- version changes ---")
for k in sorted(set(old_pkgs) & set(new_pkgs)):
    if old_pkgs[k] != new_pkgs[k]:
        print(" ", k, old_pkgs[k], "->", new_pkgs[k])
