# B3-2 — H-2 Electron ^31.0.0 (EOL) upgrade unit (HIGH) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `274bb2fff2cc88543efdce2e2df6eb154991a8bb` (parent `bf855e7`)
**UTC:** 2026-08-28T05:00–05:50Z · network: AVAILABLE (registry probe HTTP 200)

## Change

- `package.json`: devDependency `electron ^31.0.0` → `^43.4.1`.
  Target rationale: 43.4.1 is the latest mature patch of a supported major
  (supported window at capture: 42/43/44). 44.0.0 (registry `latest`) was
  skipped as a day-zero `.0`.
- `package-lock.json` regenerated (npm 11.17.0, lockfileVersion 3):
  electron 31.7.7 → 43.4.1; `@electron/get` 2.0.3 → 5.1.0 (its 57-package
  got/cacheable download stack dropped; replaced by
  `@electron-internal/extract-zip` 1.0.5 + `undici` 7.29.0); `@types/node`,
  `env-paths`, `semver`, `undici-types` bumped as transitive consequences.
  **Runtime deps carried unchanged:** node-pty 1.1.0, @xterm/xterm,
  @xterm/addon-fit, ws. Diff machinery: `diff_lock.py` (bundle).
- Committed surface is exactly those two files; node_modules is git-ignored
  (verified `git check-ignore`).

## node-pty ABI leg — CLOSED empirically (no rebuild needed)

- node-pty 1.1.0 ships an **N-API** win32-x64 prebuild (`prebuilds/win32-x64/conpty.node`),
  ABI-stable across runtimes:
  - plain node v24.16.0 (ABI 137): **LOADED**;
  - Electron 43.4.1 main process (ABI 148): **LOADED** and a live ConPTY
    `pty.spawn("cmd.exe")` succeeded — `smoke-load.js` →
    `LOADED under electron ABI 148; spawn=function; spawned pid=40116`.
- `@electron/rebuild` was attempted and failed: node-gyp 13.0.2 cannot find
  this host's **VS 18 BuildTools** ("Could not find any Visual Studio
  installation to use"; vswhere sees it at 18.7.11911.148 with the
  VC.Tools.x86.x64 component — a node-gyp version-recognition gap, recorded in
  `electron-rebuild-output.txt` / `node-gyp-verbose.txt`). Moot given the
  N-API prebuild loads.
- npm 11 `allow-scripts` blocked node-pty/electron lifecycle scripts on first
  install; approved via `npm approve-scripts electron node-pty`, then
  `node node_modules/electron/install.js` (binary download) and
  `node node_modules/node-pty/scripts/prebuild.js` ran clean. Recorded in
  `npm-install-output.txt`, `npm-rebuild-output.txt`.

## Regression band (measured)

- **Headless legs — 1104/1104 OK** on the upgraded tree (`band-headless-suite.txt`):
  IPC, recovery machine, supervision/admission, terminal session-manager,
  worker spawn/process, lifecycle, self-check parse+load legs.
- Electron headless probes: `--version` → v43.4.1, `--abi` → 148.
- **GUI legs DEFERRED to operator (T-3 live):** sandbox / context-isolation /
  navigation (`will-navigate`, `setWindowOpenHandler`) / window-rendering
  behavior under a live BrowserWindow need the operator's display; the guards'
  SOURCE is exercised by the headless suite (renderer-spec-allowlist,
  U186 falsification pins), but the live-window confirmation is a physical leg.

## Evidence artifacts (bundle)

npm-install-output.txt, npm-install-2-output.txt, npm-rebuild-output.txt,
electron-rebuild-output.txt, node-gyp-verbose.txt, electron-load-smoke.txt,
smoke-load.js, lock-diff.txt, diff_lock.py, list_lock.py,
band-headless-suite.txt.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
