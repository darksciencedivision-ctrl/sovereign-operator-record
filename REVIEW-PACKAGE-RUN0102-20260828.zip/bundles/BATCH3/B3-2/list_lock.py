import json

lock = json.load(open(
    r"D:\producttion software 2\release-worktree\modules\sow\apps\desktop\package-lock.json",
    encoding="utf-8"))
for k, v in sorted(lock["packages"].items()):
    name = k if k else "(root)"
    print(name, "->", v.get("version", ""))
