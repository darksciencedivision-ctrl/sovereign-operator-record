# B3-1 — H-1 session-manager admission-before-spawn (HIGH) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `bf855e7e12e91bfbe384252f4b654bac28821240` (parent `7b7431f`)
**UTC:** 2026-08-28T04:15–04:55Z

## Defect

`terminal/conpty/session-manager.js` created the OS process first
(`ptyFactory` at :69) and only asked the supervisor afterwards (admit at :103).
A renderer/governance-chosen executable was launched FIRST and judged SECOND;
a denial could only try to kill something already running (kill is intent, not
proof). The W-29 renderer allow-list in `main.js` masked the executable-choice
vector, but the admission-order defect itself stood.

## Repair (two-phase verdict)

- **Pre-spawn verdict:** `spawn()` calls `supervisor.admit({id, nodeId})`
  BEFORE the factory. Refusal (or a throwing supervisor) → `SupervisionDenied`
  with `preSpawnRefusal: true`; NO process, NO registry record, nothing to
  kill; the id is immediately reusable. A `refused` event is still emitted
  (`preSpawn: true`, `pid: null`) so view sinks can surface it (main.js's
  event consumer persists eventLog/pushState only — tolerant by inspection).
- **Post-spawn verdict:** the existing `admit({id, nodeId, pid})` is retained
  as the pid-binding verdict (the pid only exists after spawn; production
  hands it to the Node Runtime Job Object). It re-verifies the channel; a drop
  between verdicts follows the unchanged fail-closed path (REFUSED + kill,
  exit-callback-gated handle retention).
- Contract unchanged: supervisors still implement only `admit()`/`notify()`.
  `IpcSupervisor.admit` reads the latched `admissionOpen` (pid rides in the
  reason string), so both verdicts are meaningful for it.
- Comments updated: manager doc block (1/1b), `main.js` RENDERER_SPEC_ALLOWED_KEYS
  note (comment-only; U186 re-pin below), renderer-spec-allowlist.test.js
  history note.

## Tests (terminal/test/session-manager.test.js)

Two denial tests rewritten for the new contract; three regression tests added:
1. pre-spawn denial starts NO process (factory calls = 0, no record, refused
   event shape, id reusable);
2. verdict ORDER is `admit:pre → spawn → admit:post`;
3. post-spawn verdict receives the real pid (pre-spawn verdict carries none);
4. channel drop BETWEEN verdicts kills the just-started PTY → REFUSED;
5. throwing supervisor = denial at the pre-spawn verdict, nothing starts.

## Evidence (measured)

- `fail-before-output.txt`: original session-manager.js byte-restored via
  `git show` (sha `4d58204e…` verified) → new suite **18/23; the 5 H-1 tests
  FAIL** (factory spawned despite refusal: `1 !== 0`).
- `pass-after-output.txt`: **23/23 OK**.
- `full-suite-final.txt`: sow desktop suite **1104/1104 OK**.
- **U186 falsification re-pin** (`falsify-run.txt`): main.js's only change is
  the comment note; all 37 `pane_input_bypass_mutations` re-read against the
  new bytes (every anchor re-counted unique), harness re-run:
  **ALL MUTATIONS CAUGHT (37/37), main.js restored BYTE-IDENTICAL**
  (`E334706C543D7B7C1BC9B88443D87FA218EDC7DBB5FBE1702517E9382AA30BA7`),
  zero CR bytes (U274). PINNED_BASELINE updated with a trail entry per the
  established re-pin protocol. The U186 suite test caught the stale pin first
  — recorded as the guard doing its job.

## Changed files (commit `bf855e7`)

`modules/sow/terminal/conpty/session-manager.js`,
`modules/sow/terminal/test/session-manager.test.js`,
`modules/sow/apps/desktop/main.js` (comment),
`modules/sow/apps/desktop/test/renderer-spec-allowlist.test.js` (comment),
`modules/sow/tools/mutation/pane_input_bypass_mutations.js` (re-pin).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
