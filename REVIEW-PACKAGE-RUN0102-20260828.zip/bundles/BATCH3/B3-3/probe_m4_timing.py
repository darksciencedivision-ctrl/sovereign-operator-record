"""M-4 timing probe — measures one managed run's teardown tax.

Usage: python probe_m4_timing.py  (from bundles/BATCH3/B3-3)
Runs a single trivial run_managed_process() call and prints the elapsed time.
Pre-fix expectation: ~15 s (WaitForSingleObject runs to the full ceiling even
on an already-empty job). Post-fix: well under a second.
"""
import os
import subprocess
import sys
import time

SOW = r"D:\producttion software 2\release-worktree\modules\sow"
sys.path.insert(0, SOW)
os.chdir(SOW)

from adapters.frontier.process_tree import run_managed_process  # noqa: E402

start = time.monotonic()
result = run_managed_process(
    [sys.executable, "-c", "print('ok')"],
    timeout=30.0, env=dict(os.environ), stdin=subprocess.DEVNULL)
elapsed = time.monotonic() - start
print(f"returncode={result.returncode} stdout={result.stdout.strip()!r}")
print(f"ELAPSED {elapsed:.3f} s")
