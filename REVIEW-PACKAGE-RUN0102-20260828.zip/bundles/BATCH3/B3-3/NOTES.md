# B3-3 — M-4 bounded process polling (MEDIUM) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `ef47226a94d849ca6027af591fac0eadfa55d462` (parent `274bb2f`)
**UTC:** 2026-08-28T05:55–06:20Z

## Defect

`adapters/frontier/process_tree.py:128` — `terminate_and_wait` waited on the
Job Object handle with `WaitForSingleObject(handle, 15000)`. A job handle is
signaled only on an end-of-job TIME LIMIT, never on member exit, so every
managed run — clean exits included — paid the full 15 s ceiling in the
`finally`. Independently measured before the fix (this seat, `probe_m4_timing.py`):
**15.122 s** for `python -c "print('ok')"`; matches review F-3's 15.150 s and
`INDEPENDENT_REVIEW_WINDOWS_HOST_20260816.md:126` root cause.

## Repair (the review's own fix shape)

`terminate_and_wait` now polls `pids()` with a 50 ms sleep, bounded by
`timeout_s`: returns `()` the moment the job is empty, or the surviving pids at
the deadline. `TerminateJobObject` invocation and the `(remaining)` return
contract unchanged; the wait's semantics (`()` on empty, survivors on timeout)
preserved.

## Evidence (measured)

- `fail-before-timing.txt`: **ELAPSED 15.122 s** (one trivial managed run).
- `fail-before-pytest.txt`: single-call integration test **15.14 s call**, passed.
- `pass-after-timing.txt`: **ELAPSED 0.120 s** (126× reduction).
- `pass-after-pytest.txt`: `test_frontier_process_tree.py` **6/6 PASS in 10.12 s**
  — the 10-run descendant-reap test now 7.51 s (was 150 s-class); single-call
  test 0.14 s.
- `parity-unit.txt`: `test_provider_decoding_parity.py` **7/7 OK** (0.69 s).
- Environmental note: `test_cross_entry_point_control_state.py` and
  `test_no_live_provider_calls_in_suite.py` fail COLLECTION with
  `ModuleNotFoundError: jsonschema` — pre-existing host dependency gap (the sow
  venv is excluded from every baseline; installing into host site-packages is
  outside the builder write boundary). Unrelated to this change [B].

## Changed files (commit `ef47226`)

`modules/sow/adapters/frontier/process_tree.py`.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
