# B3-4 — M-7 receipts reader fail-on-undeclared + machine-tag falsification receipts (MEDIUM) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `6c7ec996a809b63907afc1c5c31e18ec59130cbd` (parent `ef47226`)
**UTC:** 2026-08-28T06:25–06:55Z

## Defect (M-7)

"5.6 receipts [R]: machinery exists; the required fail-on-undeclared-`ok:false`
behavior unproven; deliberate-falsification receipts untagged." The W-19 gate
(`tests/unit/test_evidence_receipts.py`) read all receipts and held a pinned
waiver table, but (a) its failure decision was inline prose-level logic with no
negative end-to-end proof that an undeclared `ok:false` fails it, and (b) the
deliberate-falsification receipts among the waivers were only described in
prose — code could not tell them apart.

## Repair (receipts untouched — docs/evidence is append-only)

- `undeclared_failures(verdicts, waived)` — the gate decision extracted as a
  pure function; the real gate now runs it. A waiver is effective ONLY while
  its pinned verdict matches the receipt's actual verdict, so a drifted waiver
  fails the gate itself (defense in depth with the waiver-rot test).
- `WAIVER_KINDS` + `KINDS` — every one of the 18 waivers machine-tagged from a
  fixed vocabulary: `superseded`, `live_blocked`, `no_verdict_schema`,
  `deliberate_falsification`, `historical_scope_mismatch`.
  `waiver_kind_problems()` checks coverage both directions, known kinds only,
  and kind⇔verdict agreement.
- Deliberate-falsification class pinned by test: PHASE17C_DISARM_FALSIFICATION,
  the 19.3 leg-B falsification receipt, the 19.4 `ab-pre-repair` and `diag`
  records — each carries `ok:false` and is now identifiable by code.

## New/changed tests (4 new, 8 total)

1. `test_the_gate_fails_end_to_end_on_an_undeclared_ok_false_receipt` —
   NEGATIVE end-to-end: unwaived `ok:false` flagged; correct waiver clears;
   wrongly-pinned waiver still fails.
2. `test_every_waiver_carries_a_machine_kind` — tag integrity.
3. `test_the_deliberate_falsification_receipts_are_machine_tagged` — class pin.
4. `test_a_waiver_with_an_unknown_or_missing_kind_is_rejected` — NEGATIVE rot.

## Evidence (measured)

- `baseline-tests.txt`: pre-change 4/4 OK. `fail-before-capability-probe.txt`:
  `WAIVER_KINDS/undeclared_failures/KINDS` all absent.
- `pass-after-tests.txt`: **8/8 PASSED**.
- `phase19-receipt-step.txt`: `tools/run_phase19_gate.receipt_debt_report()`
  re-run against the unchanged 2-tuple WAIVED shape → superseded-historical
  PASS, current-unresolved KNOWN_OPEN_DEBT (debt reported, never PASS),
  unregistered-failure PASS. Consumer untouched.

## Changed files (commit `6c7ec99`)

`modules/sow/tests/unit/test_evidence_receipts.py`.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
