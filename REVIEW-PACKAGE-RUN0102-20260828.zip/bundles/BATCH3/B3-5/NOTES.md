# B3-5 — M-8 / T2 harness-config-injection adversarial tests — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder grok-4.6 (opencode harness)

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `e7bd97e9d105b6bdacf79740dc2069a3b95522b3` (parent `73862d0`)
**UTC:** 2026-08-28T05:02Z

## Fail-before

Punch M-8: threat-model disclosure repaired; `tests/security/` absent.
`git ls-tree -r HEAD -- modules/sow/tests/security` empty. T2/TB-4 status
named the adversarial tests **NOT IMPLEMENTED** / ABSENT.

Untracked file from run-01 (`test_t2_harness_config_injection.py`, 5321 B)
parsed clean. First host-python run: **3 passed, 1 failed**
(`ModuleNotFoundError: jsonschema` in Leg C via `node_runtime.context.loaders`).
No pip-install (write boundary).

## Repair

- `pytest.importorskip("jsonschema")` on the one jsonschema-gated leg
  (`test_a_planted_or_unknown_deployment_profile_fails_closed`) so the leg
  skips cleanly offline instead of erroring.
- `modules/sow/docs/THREAT_MODEL.md` T2 and TB-4 status cells only — rows
  whose claimed adversarial-test mitigation now exists, moved to
  **IMPLEMENTED** with the test path named. Nothing else reworded.

## Pass-after (measured)

- Host `python` 3.14.6 (no jsonschema): **3 passed, 1 skipped**, exit 0.
  Skip reason: `could not import 'jsonschema'`.
- `py -3.12` (jsonschema 4.26.0, recorded SOW interpreter): **4 passed**, exit 0.

## Changed files

- `modules/sow/tests/security/test_t2_harness_config_injection.py` (NEW)
- `modules/sow/docs/THREAT_MODEL.md` (T2 + TB-4 status cells)

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
