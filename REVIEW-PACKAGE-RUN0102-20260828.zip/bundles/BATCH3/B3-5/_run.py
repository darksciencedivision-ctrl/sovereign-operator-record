from pathlib import Path
import subprocess
import sys

sow = Path(r"D:\producttion software 2\release-worktree\modules\sow")
bundle = Path(r"D:\producttion software 2\release-planning\bundles\BATCH3\B3-5")
cmd_host = [sys.executable, "-m", "pytest", "tests/security/", "-v", "--tb=short"]
cmd_312 = ["py", "-3.12", "-m", "pytest", "tests/security/", "-v", "--tb=short"]

for name, cmd in (("pass-after-pytest-host.txt", cmd_host), ("pass-after-pytest-py312.txt", cmd_312)):
    print("RUNNING", name, flush=True)
    r = subprocess.run(cmd, cwd=str(sow), capture_output=True)
    body = []
    body.append("CMD: %s" % " ".join(cmd))
    body.append("exit: %d" % r.returncode)
    body.append("stdout:")
    body.append(r.stdout.decode("utf-8", "replace"))
    body.append("stderr:")
    body.append(r.stderr.decode("utf-8", "replace"))
    (bundle / name).write_bytes(("\n".join(body) + "\n").encode("utf-8"))
    print("DONE", name, "exit", r.returncode, flush=True)
