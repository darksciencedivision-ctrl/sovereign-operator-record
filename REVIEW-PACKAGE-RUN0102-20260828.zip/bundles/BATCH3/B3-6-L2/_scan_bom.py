from pathlib import Path

roots = [
    Path(r"D:\producttion software 2\release-worktree\modules\sovereign"),
    Path(r"D:\producttion software 2\release-worktree\modules\debate"),
    Path(r"D:\producttion software 2\release-worktree\dev"),
]
hits = []
for root in roots:
    if not root.exists():
        continue
    for p in root.rglob("*.py"):
        try:
            b = p.read_bytes()
        except OSError:
            continue
        if b.startswith(b"\xef\xbb\xbf"):
            rel = p
            hits.append((str(p), len(b)))
print("BOM_COUNT", len(hits))
for h in hits:
    print(h[0])
