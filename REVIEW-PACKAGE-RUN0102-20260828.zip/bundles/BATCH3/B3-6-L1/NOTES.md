# B3-6 L-1 — .cmd-shim metacharacter validation — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder grok-4.6 (opencode harness)

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `5a52946` (parent `22f8328`)
**UTC:** 2026-08-28T05:16Z

## Fail-before

`modules/sow/adapters/cmd_shim.py` absent from HEAD. N-03: a `.cmd` shim
invoked with `--cwd C:\x\R&echo INJECTED` executes through cmd.exe even when
Python quotes the argument. Punch L-1 latent.

## Repair

- New `adapters/cmd_shim.py`: refuse `& | ^ < > %` on any argv element when
  argv[0] ends with `.cmd`.
- Construction sites: `FrontierProviderCliBackend._guard`,
  `codex._assert_no_forbidden`, `claude_code._assert_no_forbidden`,
  `opencode._opencode_run_argv`, grok/antigravity interactive builders.
- Spawn boundary: `process_tree.run_managed_process` (full argv, before Popen).
- Non-`.cmd` executables are out of this guard (list argv is not cmd.exe).

## Pass-after

`tests/unit/test_cmd_shim_metacharacters.py`: **17/17 passed** on host python
3.14 and `py -3.12`. Hostile payloads `& | ^ < > %` refused; clean `.cmd`
allowed; `.exe` not this guard; `run_managed_process` raises before spawn.

## Changed files

- `modules/sow/adapters/cmd_shim.py` (NEW)
- `modules/sow/adapters/frontier/provider_cli_common.py`
- `modules/sow/adapters/frontier/process_tree.py`
- `modules/sow/adapters/frontier/codex.py`
- `modules/sow/adapters/frontier/claude_code.py`
- `modules/sow/adapters/frontier/grok_build.py`
- `modules/sow/adapters/frontier/antigravity.py`
- `modules/sow/adapters/coding/opencode/harness.py`
- `modules/sow/tests/unit/test_cmd_shim_metacharacters.py` (NEW)

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
