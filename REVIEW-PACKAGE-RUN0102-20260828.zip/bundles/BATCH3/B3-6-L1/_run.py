from pathlib import Path
import subprocess
import sys

sow = Path(r"D:\producttion software 2\release-worktree\modules\sow")
bundle = Path(r"D:\producttion software 2\release-planning\bundles\BATCH3\B3-6-L1")
bundle.mkdir(parents=True, exist_ok=True)
cmds = [
    ("pass-after-pytest-host.txt", [sys.executable, "-m", "pytest", "tests/unit/test_cmd_shim_metacharacters.py", "-v", "--tb=short"]),
    ("pass-after-pytest-py312.txt", ["py", "-3.12", "-m", "pytest", "tests/unit/test_cmd_shim_metacharacters.py", "-v", "--tb=short"]),
]
for name, cmd in cmds:
    print("RUNNING", name, flush=True)
    r = subprocess.run(cmd, cwd=str(sow), capture_output=True)
    body = ["CMD: %s" % " ".join(cmd), "exit: %d" % r.returncode, "stdout:", r.stdout.decode("utf-8", "replace"), "stderr:", r.stderr.decode("utf-8", "replace")]
    (bundle / name).write_bytes(("\n".join(body) + "\n").encode("utf-8"))
    print("DONE", name, "exit", r.returncode, flush=True)
