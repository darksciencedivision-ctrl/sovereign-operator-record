# B3-6 L-3 — worktree README Debate version from RELEASE-MANIFEST — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder grok-4.6 (opencode harness)

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `1c023c9` (parent `613811d`)
**UTC:** 2026-08-28T05:09Z

## Fail-before

Worktree `README.md` Modules table: `Debate Table v1.2 P1`.
`RELEASE-MANIFEST.json` `modules.debate.version` = `v1.2.1-hardening`.
No `shell/` docs cite `v1.2 P1` (grep empty). Custody files untouched.

## Repair

One table cell: `Debate Table v1.2 P1` → `Debate Table v1.2.1-hardening`.
Historical Phase-1 discovery (`docs/DISCOVERY.md`, `docs/ADR-003.md`) and
`BUILD-DIRECTIVE-SWS-UI-001.md` source-ZIP rows left as historical records.

## Pass-after

`README.md` Modules table names `v1.2.1-hardening`. `v1.2 P1` absent from
that table. Custody hashes unchanged (no custody writes).

## Changed files

- `README.md`

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
