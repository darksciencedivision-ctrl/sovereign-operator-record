# R-1 — AUD-1 repair: shell/src/server.py UTF-16 LE → UTF-8 no BOM — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 resume · builder grok-4.6 (opencode harness)

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `73862d035aa9ecbbd6d176cd3cb3fb43720c9567` (parent `6c7ec99`)
**UTC:** 2026-08-28T04:59Z

## Defect (AUD-1, validator-audited)

`shell/src/server.py` was committed as UTF-16 LE at `3ad0720` (PowerShell 5.1
redirection during B1-3). HEAD blob first two bytes `FF FE`; 18,781 NUL bytes;
CPython cannot parse UTF-16 source. Content intact when decoded as utf-16,
including the H-4 `FAILED` import.

## Fail-before (measured)

- `fail-before-encoding.txt`: size 37566; first2 `fffe`; `is_utf16_le_bom: True`;
  `nul_count: 18781`.
- `python -c "import ast; ast.parse(open('shell/src/server.py','rb').read())"` →
  `SyntaxError: source code string cannot contain null bytes`.
- `python -m unittest shell.tests.test_start_worker_failure -v` → load-time
  `SyntaxError: source code string cannot contain null bytes` (exit 1).

## Repair

Python only (`open(...,'wb')`; no PowerShell redirection / Set-Content):
read bytes, `decode('utf-16')`, `encode('utf-8')` (no BOM), write bytes.
Decoded CRLF preserved (496 `\r\n`).

## Pass-after (measured)

- `pass-after-encoding.txt`: size 18785; first2 `2222` (`"` `"` of the module
  docstring); not `FF FE`; not UTF-8 BOM; `nul_count: 0`; `ast.parse: SUCCEEDED`.
- H-4 regression `shell.tests.test_start_worker_failure`: **3/3 OK, exit 0**.
- `shell.tests.test_states`: 16 tests, **1 FAIL**
  (`test_distillery_is_not_started`: `STOPPED != NOT_STARTED`) — pre-existing
  per B1-3 NOTES; not an import error.
- B1-3 comparison subset (10 modules): **Ran 79 tests in 24.513s — 13 F + 6 E**.
  Zero `null bytes` / server.py `SyntaxError`. `test_shell.TestServerEndpoints`
  setUpClass now loads (B1-3 PREFIX had `ERROR: setUpClass` on that class;
  those cases now execute, which is why the subset count is 79 vs B1-3's 55).
  Remaining F/E are the B1-3 pre-existing classes: `control_plane.canonical_registry`
  (OD-20), SOW desktop JS pin drift, Distillery `200 != 400`.

## Changed files

- `shell/src/server.py` (encoding only; logic unchanged)

Evidence lane (`evidence/hardening/h13–h16`) was rewritten by the subset run
and restored to HEAD before commit.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
