from pathlib import Path
import subprocess
import sys
import ast

wt = Path(r"D:\producttion software 2\release-worktree")
bundle = Path(r"D:\producttion software 2\release-planning\bundles\BATCH3\R-1-AUD-1")
p = wt / "shell" / "src" / "server.py"
raw = p.read_bytes()

enc_lines = []
enc_lines.append("R-1 AUD-1 pass-after encoding")
enc_lines.append("size_bytes: %d" % len(raw))
enc_lines.append("first2_hex: %s" % raw[:2].hex())
enc_lines.append("is_utf16_le_bom: %s" % (raw[:2] == b"\xff\xfe"))
enc_lines.append("is_utf8_bom: %s" % (raw[:3] == b"\xef\xbb\xbf"))
enc_lines.append("nul_count: %d" % raw.count(0))
enc_lines.append("crlf_count: %d" % raw.count(b"\r\n"))
try:
    ast.parse(raw)
    enc_lines.append("ast.parse: SUCCEEDED")
except Exception as e:
    enc_lines.append("ast.parse: FAILED %s: %s" % (type(e).__name__, e))
(bundle / "pass-after-encoding.txt").write_bytes(("\n".join(enc_lines) + "\n").encode("utf-8"))

cmds = [
    (
        "pass-after-h4.txt",
        [sys.executable, "-m", "unittest", "shell.tests.test_start_worker_failure", "-v"],
    ),
    (
        "pass-after-test-states.txt",
        [sys.executable, "-m", "unittest", "shell.tests.test_states", "-v"],
    ),
    (
        "pass-after-b13-subset.txt",
        [
            sys.executable,
            "-m",
            "unittest",
            "shell.tests.test_failure_classes",
            "shell.tests.test_governed_replacement",
            "shell.tests.test_incompatible_selection_refused",
            "shell.tests.test_promotion_axis_orthogonal",
            "shell.tests.test_router_no_unrequested_transition",
            "shell.tests.test_conductor_surface",
            "shell.tests.test_render",
            "shell.tests.test_shell",
            "shell.tests.test_new_session_spawns_no_process",
            "shell.tests.test_registry_fields_projected",
            "-v",
        ],
    ),
]

summary = []
for name, cmd in cmds:
    print("RUNNING", name, flush=True)
    r = subprocess.run(cmd, cwd=str(wt), capture_output=True)
    body = []
    body.append("CMD: %s" % " ".join(cmd[1:]))
    body.append("exit: %d" % r.returncode)
    body.append("stdout:")
    body.append(r.stdout.decode("utf-8", "replace"))
    body.append("stderr:")
    body.append(r.stderr.decode("utf-8", "replace"))
    (bundle / name).write_bytes(("\n".join(body) + "\n").encode("utf-8"))
    tail = (r.stderr or r.stdout).decode("utf-8", "replace").strip().splitlines()[-8:]
    summary.append("%s exit=%d tail=%s" % (name, r.returncode, " | ".join(tail)))
    print("DONE", name, "exit", r.returncode, flush=True)

(bundle / "pass-after-summary.txt").write_bytes(("\n".join(summary) + "\n").encode("utf-8"))
print("ALL DONE")
for line in summary:
    print(line)
