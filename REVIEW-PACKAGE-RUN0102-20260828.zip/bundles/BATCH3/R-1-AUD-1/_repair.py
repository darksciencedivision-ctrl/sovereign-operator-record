from pathlib import Path
import subprocess
import sys
import ast

wt = Path(r"D:\producttion software 2\release-worktree")
bundle = Path(r"D:\producttion software 2\release-planning\bundles\BATCH3\R-1-AUD-1")
p = wt / "shell" / "src" / "server.py"

r1 = subprocess.run(
    [sys.executable, "-c", "import ast; ast.parse(open('shell/src/server.py','rb').read())"],
    cwd=str(wt),
    capture_output=True,
)
r2 = subprocess.run(
    [sys.executable, "-m", "unittest", "shell.tests.test_start_worker_failure", "-v"],
    cwd=str(wt),
    capture_output=True,
)
out = []
out.append('=== python -c "import ast; ast.parse(open(\'shell/src/server.py\',\'rb\').read())" ===')
out.append("exit: %d" % r1.returncode)
out.append("stdout:")
out.append(r1.stdout.decode("utf-8", "replace"))
out.append("stderr:")
out.append(r1.stderr.decode("utf-8", "replace"))
out.append("")
out.append("=== python -m unittest shell.tests.test_start_worker_failure -v ===")
out.append("exit: %d" % r2.returncode)
out.append("stdout:")
out.append(r2.stdout.decode("utf-8", "replace"))
out.append("stderr:")
out.append(r2.stderr.decode("utf-8", "replace"))
(bundle / "fail-before-output.txt").write_bytes(("\n".join(out) + "\n").encode("utf-8"))
print("fail-before-output written, exits", r1.returncode, r2.returncode)

raw = p.read_bytes()
assert raw[:2] == b"\xff\xfe", raw[:2]
decoded = raw.decode("utf-16")
encoded = decoded.encode("utf-8")
assert not encoded.startswith(b"\xef\xbb\xbf")
assert encoded[:2] != b"\xff\xfe"
p.write_bytes(encoded)
after = p.read_bytes()
assert after[:2] != b"\xff\xfe"
assert after[:3] != b"\xef\xbb\xbf"
ast.parse(after)
print("REPAIR OK")
print("after_size", len(after))
print("after_first2", after[:2].hex())
print("after_nul", after.count(0))
print("after_crlf", after.count(b"\r\n"))
print("after_lf", after.count(b"\n"))
print("ast.parse: SUCCEEDED")
print("FAILED_import_line", any(b"FAILED" in line for line in after.splitlines()[:40]))
