from __future__ import annotations

import ast
import importlib
import sys
from pathlib import Path

WT = Path(r"D:\producttion software 2\release-worktree")
BUNDLE = Path(r"D:\producttion software 2\release-planning\bundles\BATCH3\B3-6-L6")
BUNDLE.mkdir(parents=True, exist_ok=True)
BOM = b"\xef\xbb\xbf"

FILES = [
    WT / "modules/sovereign/cycle_runner_v3.py",
    WT / "modules/sovereign/document_assembler.py",
    WT / "modules/sovereign/embedding_client.py",
    WT / "modules/sovereign/publication_gate.py",
    WT / "modules/sovereign/quality_gate.py",
    WT / "modules/sovereign/semantic_claim_matching.py",
    WT / "modules/sovereign/system_manifest.py",
    WT / "modules/sovereign/clu/clu_loop.py",
    WT / "modules/sovereign/evaluation/contract.py",
    WT / "modules/sovereign/evaluation/contract_trace.py",
    WT / "modules/sovereign/evaluation/integrity.py",
    WT / "modules/sovereign/synthesis/praxis_report.py",
    WT / "modules/sovereign/synthesis/sovereign_voice.py",
    WT / "modules/sovereign/synthesis/synth_king.py",
    WT / "modules/debate/tests/test_v1_2_1_config_integrity.py",
]


def rel(p: Path) -> str:
    return p.relative_to(WT).as_posix()


def parse_ok(data: bytes) -> str:
    try:
        ast.parse(data.decode("utf-8-sig"))
        return "PARSE_OK"
    except Exception as e:
        return "PARSE_FAIL %s: %s" % (type(e).__name__, e)


fail_lines = ["L-6 fail-before"]
for p in FILES:
    raw = p.read_bytes()
    fail_lines.append(
        "%s size=%d bom=%s first3=%s %s"
        % (rel(p), len(raw), raw.startswith(BOM), raw[:3].hex(), parse_ok(raw))
    )
(BUNDLE / "fail-before-bom.txt").write_bytes(("\n".join(fail_lines) + "\n").encode("utf-8"))

stripped = []
for p in FILES:
    raw = p.read_bytes()
    if not raw.startswith(BOM):
        raise SystemExit("expected BOM: %s" % p)
    new = raw[len(BOM) :]
    assert not new.startswith(BOM)
    p.write_bytes(new)
    stripped.append(p)

pass_lines = ["L-6 pass-after"]
for p in FILES:
    raw = p.read_bytes()
    assert not raw.startswith(BOM), p
    ast.parse(raw)
    pass_lines.append("%s size=%d bom=False first3=%s PARSE_OK" % (rel(p), len(raw), raw[:3].hex()))

# consumers: compile each file; import system_manifest (imported by many of the others)
sov = WT / "modules" / "sovereign"
sys.path.insert(0, str(sov))
import_results = []
for name in (
    "system_manifest",
    "quality_gate",
    "publication_gate",
    "semantic_claim_matching",
    "embedding_client",
    "document_assembler",
):
    try:
        importlib.import_module(name)
        import_results.append("%s: IMPORT_OK" % name)
    except Exception as e:
        import_results.append("%s: IMPORT_FAIL %s: %s" % (name, type(e).__name__, e))

pass_lines.append("")
pass_lines.append("consumer imports:")
pass_lines.extend(import_results)
(BUNDLE / "pass-after-bom.txt").write_bytes(("\n".join(pass_lines) + "\n").encode("utf-8"))
print("stripped", len(stripped))
for line in import_results:
    print(line)
