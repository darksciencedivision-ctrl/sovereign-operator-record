# B3-6 L-6 — strip UTF-8 BOMs from 15 active .py files — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 3 · builder grok-4.6 (opencode harness)

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `22f8328` (parent `1c023c9`)
**UTC:** 2026-08-28T05:11Z

## Fail-before

15 active files started with UTF-8 BOM `EF BB BF` (14 SOVEREIGN + 1 Debate
test). Each parsed as Python via `utf-8-sig`. Frozen Debate ZIP not opened.

## Repair

Python `open(...,'wb')`: drop the three BOM bytes, remainder unchanged.
OD-21 prospective; this is the authorized worktree re-cut. Frozen Debate
release ZIP not re-cut. Staging duplicate under
`dev/v1.2.1-hardening/release/staging/` left untouched (not one of the 15).

## Pass-after

All 15: no BOM, `ast.parse` OK. Consumer imports: `system_manifest`,
`quality_gate`, `publication_gate`, `semantic_claim_matching`,
`embedding_client`, `document_assembler`, `clu.clu_loop`,
`evaluation.contract`, `evaluation.contract_trace`, `evaluation.integrity`,
`synthesis.praxis_report`, `synthesis.sovereign_voice`,
`synthesis.synth_king` → IMPORT_OK. `cycle_runner_v3` still
`ModuleNotFoundError: research` (pre-existing missing package, not BOM).
Debate test `compile()` OK.

## Changed files

14 under `modules/sovereign/` + `modules/debate/tests/test_v1_2_1_config_integrity.py`

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
