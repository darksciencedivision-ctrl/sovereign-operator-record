# PHASE 0 — WORKTREE CONSTRUCTION RECIPE
## SWS-REM-DIR-20260828 R2 · P0-2 · builder seat: qwen3.8-max (deepseek harness)

Status: **CANDIDATE** (builder-authored; no reviewer PASS asserted)

Directive reference: SWS-REM-DIR-20260828-CANDIDATE-R2.md §2 (authority chain and controlled
worktree), authorized by OPERATOR-INSTRUCTIONS.log ENTRY 001 (UTC 2026-08-28T01:36:53Z,
log sha256 `bf1bc1d338f429fc8993692fce9944f8e42bd7e0ff2946af253a659e7b3c4b45`).

---

## 1. Immutable source

| Field | Value |
|---|---|
| Source archive | `D:\producttion software 2\SOVEREIGN_SYSTEM_BASELINE_20260827.zip` |
| Source ZIP SHA-256 | `75e4be075dcb5629c3175850f5aa3f342c7c693f2967c3620d6cd4914ac27138` |
| Sidecar (P0-1) | `D:\producttion software 2\SOVEREIGN_SYSTEM_BASELINE_20260827.zip.sha256` |
| ZIP entry prefix extracted | `SOVEREIGN_SYSTEM_BASELINE_20260827/Production Workspace/` |
| Entries under prefix | 3,580 files, 0 explicit directory entries |
| Total uncompressed bytes | 98,278,856 |
| ZIP hash verified this session (Get-FileHash SHA256) | MATCH |

The ZIP is the byte authority. Everything below is derived identity.

## 2. Environment / tool versions (measured)

| Tool | Version |
|---|---|
| OS | Microsoft Windows NT 10.0.26200.0 |
| Shell | Windows PowerShell Desktop 5.1.26100.9168 (CLR 4.0.30319.42000) |
| Extraction API | `System.IO.Compression.ZipFile` via `Add-Type -AssemblyName System.IO.Compression.FileSystem` |
| git | 2.46.0.windows.1 |
| Python (present, unused by P0) | 3.14.6 |
| Host | `D:\producttion software 2\release-worktree\` (created by this recipe; OD-16a) |
| Executing seat | builder qwen3.8-max (deepseek harness), local disk access |

## 3. Extraction command (verbatim, as executed)

UTC window: start 2026-08-28T01:47:20Z, end 2026-08-28T01:47:24Z.

```powershell
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$root = 'D:\producttion software 2\release-worktree'
$zipPath = 'D:\producttion software 2\SOVEREIGN_SYSTEM_BASELINE_20260827.zip'
$prefix = 'SOVEREIGN_SYSTEM_BASELINE_20260827/Production Workspace/'
if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root | Out-Null }
$zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
$files = 0; $dirs = 0; $bytes = [long]0
foreach ($e in $zip.Entries) {
  if (-not $e.FullName.StartsWith($prefix)) { continue }
  $rel = $e.FullName.Substring($prefix.Length)
  if ($rel -eq '') { continue }
  $target = Join-Path $root ($rel -replace '/', '\')
  if ($e.FullName.EndsWith('/')) {
    if (-not (Test-Path -LiteralPath $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }
    $dirs++
    continue
  }
  $parent = [System.IO.Path]::GetDirectoryName($target)
  if ($parent -and -not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
  $src = $e.Open()
  $dst = [System.IO.File]::Create($target)
  $src.CopyTo($dst)
  $dst.Close(); $src.Dispose()
  $files++; $bytes += $e.Length
}
$zip.Dispose()
```

Result: 3,580 files written, 98,278,856 bytes. No staging directory was used; entries were
streamed directly to their final paths, so no deletion of pre-existing material occurred.

### Extraction integrity verification (measured)

- Disk census after extraction: 3,580 files / 98,278,856 bytes — exact match to ZIP statistics.
- Spot-hash comparison (SHA-256 of ZIP entry stream vs extracted file), 5 samples — all MATCH:
  - `modules/sovereign/runtime/sovereign.db` → `778f2a8fff94108d67f62034d0d3973da9a1d7ebebfdb8f72e5719059899d8d6`
  - `evidence/GATE-LEDGER.json` → `e81a95e66cf3c0a207a7450641fe7ae270d974e3ac0e242f2aa27268fad5c7bf`
  - `AGENTS.md` → `80c0d4a18cc1fa0c6c3fbab4feab80c6a86b756755d22096ad30ae38ed2c8fc5`
  - `shell/src/server.py` → `743ecd47027ba88a95d03f6e9dd2b420fae620a8ad25f50e9a8068529aea7deb`
  - `modules/distillery/pyproject.toml` → `da91123ae4c290a45d5e8fb075fcb5bab4dc8bf76d155b5d27ebe74e3cbbbd10`
- Longest extracted absolute path ≈ 209 chars (under the 260-char MAX_PATH); no path failed.

## 4. `.gitignore` — the bytes, not a description

File: `release-worktree\.gitignore` · 1,401 bytes · SHA-256
`35e7bc95411a5e463c87920ea60f3a066aade5c473631783deb21caab81f8e2c` (LF line endings, UTF-8, no BOM).

```
# SWS-REM-DIR-20260828 R2 — release-worktree .gitignore
# Directive §2 construction recipe: excludes environments, models, logs,
# databases, caches, evidence scratch, node_modules, venvs, build output.
#
# DECLARED EFFECT: files matching these classes that exist inside the frozen
# SYSTEM ZIP are extracted to disk but NOT tracked by git. The SYSTEM ZIP
# (SHA-256 75e4be075dcb5629c3175850f5aa3f342c7c693f2967c3620d6cd4914ac27138)
# remains the byte authority; git commits are DERIVED identities only
# (see bundles\PHASE0\WORKTREE-RECIPE.md for the exclusion census).

# --- environments / virtualenvs ---
.venv/
venv/
env/
.eggs/

# --- env files (C-1c class) ---
.env
.env.*

# --- node ---
node_modules/

# --- python bytecode / caches ---
__pycache__/
*.py[cod]
.pytest_cache/
.cache/

# --- Windows junk / caches ---
Thumbs.db
desktop.ini

# --- databases (C-1a class) ---
# Frozen evidence captures (evidence/cp01, evidence/cpm1, ...) that contain
# .db files remain on disk as quarantined-historical evidence; they are simply
# not git-tracked.
*.db
*.db-shm
*.db-wal
*.sqlite
*.sqlite3

# --- logs (C-1b class; evidence-capture logs likewise untracked) ---
*.log

# --- models / weights (never tracked) ---
*.gguf
*.safetensors
models/

# --- build output ---
build/
dist/
*.egg-info/
*.whl
*.tar.gz

# --- evidence scratch (loop-generated transient evidence only) ---
evidence/scratch/
```

### Declared exclusion census (measured via `git ls-files -io --exclude-standard`: 81 files)

ZIP content matching these classes is extracted to disk but NOT in the initial commit.
Attribution per `git check-ignore -v`:

| Rule source | Count | Classes |
|---|---|---|
| root `.gitignore` (above) | 34 | 26 `*.log` evidence/historical logs (incl. `evidence/OPERATOR-INSTRUCTIONS.log`), 7 `*.db` (6 frozen-capture Windows-cache DBs under `evidence/cp01` + `evidence/cpm1/before-a`, 1 active `modules/sovereign/runtime/sovereign.db`), 1 `.env.local` (`modules/sovereign/ui/ui_shell/.env.local`) |
| `modules/sow/.gitignore` (ZIP-shipped) | 8 | `.approvals/`, `.recovery/` session state, `config/live_operation.json`, `.claude/settings.local.json` |
| `modules/distillery/.gitignore` (ZIP-shipped) | 9 | `dist/` wheel+sdist, `runs/G0-live/*.jsonl`, `*.egg-info/` |
| `modules/sovereign/ui/ui_shell/.gitignore` (ZIP-shipped) | 5 | built `dist/` SPA assets + `.env.local` overlap |
| `modules/sow/tools/spike_compositor/.gitignore` (ZIP-shipped) | 12 | `results/SPIKE_REPORT_*` |
| `evidence/cpm1/before-b/.../spike_compositor/.gitignore` (ZIP-shipped, frozen capture) | 12 | captured `SPIKE_REPORT_*` |
| `dev/v1.2.1-hardening/worktree/.gitignore` (ZIP-shipped) | 1 | `logs/debate.log` |

`git status --porcelain` after the initial commit: empty (0 untracked, 0 modified). Every ZIP file
is either tracked or declared-ignored; nothing is silently lost. The ZIP remains the byte authority
for all ignored content.

## 5. git construction commands (verbatim, as executed)

```powershell
Set-Location 'D:\producttion software 2\release-worktree'
git init -b main
git config core.autocrlf false
git config user.name "builder qwen3.8-max (SWS-REM-DIR-20260828)"
git config user.email "builder.qwen@sws-rem-dir-20260828.local"
git add -A
$ts = '2026-08-28T01:49:10+00:00'   # measured UTC at commit time
$env:GIT_AUTHOR_DATE = $ts; $env:GIT_COMMITTER_DATE = $ts
git commit -q -m "P0-2 initial worktree from SOVEREIGN_SYSTEM_BASELINE_20260827.zip (Production Workspace)" `
  -m "Source ZIP SHA-256: 75e4be075dcb5629c3175850f5aa3f342c7c693f2967c3620d6cd4914ac27138 (immutable authority)." `
  -m "Derived identity per SWS-REM-DIR-20260828 R2 section 2. Seat: builder qwen3.8-max (deepseek harness). UTC: $ts"
```

| Field | Value |
|---|---|
| Initial branch | `main` |
| Initial commit SHA | `cf50cde2f64b9db1a5021db80da8d9843a657926` |
| Commit UTC | 2026-08-28T01:49:10+00:00 |
| Tracked files in commit | 3,500 (3,499 ZIP files + `.gitignore`) |
| Author/committer | `builder qwen3.8-max (SWS-REM-DIR-20260828) <builder.qwen@sws-rem-dir-20260828.local>` |
| `core.autocrlf` | `false` (local) |

## 6. DECLARED reproducibility dependencies (per directive §2 — declared, not assumed)

1. **Timestamps.** The commit SHA depends on `GIT_AUTHOR_DATE`/`GIT_COMMITTER_DATE`. This recipe
   fixes both to `2026-08-28T01:49:10+00:00`; re-executing with these recorded values reproduces
   the same SHA (given identical tree and identity).
2. **Author identity.** The commit SHA depends on the recorded author/committer name and email above.
3. **Line endings.** `core.autocrlf=false` disables global normalization, BUT the ZIP ships nested
   `.gitattributes` (at minimum `modules/sow/.gitattributes` and `modules/distillery/.gitattributes`)
   mandating `eol=lf` for tracked text; git emitted CRLF→LF normalization warnings at `git add` for
   affected files. Tracked text bytes in the commit are therefore LF-normalized where those
   attributes apply; the ZIP remains the byte authority for the original CRLF bytes.
4. **Exclusion classes.** The 81 declared-ignored files (§4 census) are on disk but not in the
   commit. A recipe re-run must use the identical `.gitignore` bytes (§4) and the ZIP-shipped nested
   `.gitignore` files to derive an equivalent commit.
5. **Derived identity only.** Two independent executions derive equivalent source content; neither
   substitutes for the ZIP SHA-256 as authority. The earlier sandbox commit `d746010b…` remains void.

## 7. §10 custody-log mirror (executed as part of P0-2, recorded here)

Directive §10: "When the §2 worktree exists, the log is mirrored into the worktree's
`evidence/OPERATOR-INSTRUCTIONS.log`; the custody copy remains the original."

- Previous ZIP-derived mirror preserved as `evidence/OPERATOR-INSTRUCTIONS.baseline-20260827.log`
  (sha256 `1e99e3237d4a437599d943e42f74191615e8703ee6877b206906c8dabbcfd2a2`; historical bytes kept).
- Current custody log copied to `evidence/OPERATOR-INSTRUCTIONS.log`
  (sha256 `bf1bc1d338f429fc8993692fce9944f8e42bd7e0ff2946af253a659e7b3c4b45` — byte-identical to
  custody original `D:\producttion software 2\release-planning\OPERATOR-INSTRUCTIONS.log`).
- Both files match `*.log` and are deliberately untracked (on-disk evidence; `git status` clean).

## 8. Write-boundary compliance

Writes occurred ONLY to: `D:\producttion software 2\release-worktree\` (this recipe's target).
Sidecar writes (P0-1) are separately authorized. No frozen ZIP, custody file, `D:\Product Software\`
path, or other disk location was written. No file outside this recipe's own freshly-created tree was
deleted; no staging deletion occurred (direct streaming extraction).

---

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
