# PHASE 0 — PREFLIGHT VERIFICATION OF [B] FINDINGS IN THE WORKTREE
## SWS-REM-DIR-20260828 R2 · P0-3 · builder seat: qwen3.8-max (deepseek harness)

Status: **CANDIDATE** (builder-authored; no reviewer PASS asserted)

Scope: re-verify inside `D:\producttion software 2\release-worktree\` (initial commit
`cf50cde2f64b9db1a5021db80da8d9843a657926`, derived from SYSTEM ZIP
`75e4be07…ac27138`) the byte-verified [B] findings that BATCH 1–3 items will fix.
Expected values taken from PUNCH-LIST-V2.1-20260828.md and ADJUDICATION-RECORD-R2-20260828.md.
Verification UTC: 2026-08-28T01:52–01:55Z.

**Result: every checked finding matches the recorded [B] claim exactly. No unexpected product-byte
difference was found → no E-3 park; the queue proceeds.**

---

## C-1a — user/runtime state packaged (CRITICAL) — VERIFIED

- `modules/sovereign/runtime/sovereign.db` exists, **90,112 bytes** (recorded: 90,112 B ✓).
- SQLite census measured via `python sqlite3` (tables/rows):
  `sessions: 1`, `messages: 4`, `jobs: 2`, `event_log: 17` (recorded: 1/4/2/17 ✓);
  additional tables `meta: 0`, `research_checkpoints: 0`, `self_snapshots: 0`, `sqlite_sequence: 1`
  (matches R2 adjudication §1 ✓). No `-wal`/`-shm` sidecars (matches A′ correction ✓).
- `runtime/evidence/quick/session_9798418e1c6e491e922852946a983dac/quick-20260825T045352131422Z-b6c52f66/`
  contains actual session material: `prompt.txt` (2,407 B), `raw_generation.json` (116,584 B),
  `accepted.txt` (857 B), `evidence.json` (4,566 B), `result.json` (3,097 B);
  plus `runtime/evidence/status/session_…/job_e81d….json` (20,655 B) ✓.

## C-1b — active SOW loop log packaged (MEDIUM) — VERIFIED

- `modules/sow/apps/desktop/docs/loop/logs/phase17c_iter90_main.log` exists in the ACTIVE module
  tree, 4,063 bytes ✓ (the frozen copies under `evidence/cp01|cpm1` are separate, historical, and
  remain quarantined-as-evidence per A′).

## C-1c — `.env.local` packaged (LOW) — VERIFIED

- `modules/sovereign/ui/ui_shell/.env.local` exists; content exactly
  `VITE_SOVEREIGN_BACKEND_URL=http://127.0.0.1:5175` ✓ (no secret; boundary violation stands).

## H-3 — Token Center refresh functionally broken (HIGH) — VERIFIED (both files)

`modules/tokencenter/piggybank.py` (36,059 B):
- `:820` `def do_POST(...)`; `:823` `nonce = self.headers.get("X-CSRF-Nonce", "")`
- `:827` origin gate uses **`origin.startswith("http://127.0.0.1")`** (the M-1 prefix flaw)
- `:830–831` rejects only an EMPTY nonce → 403 `"X-CSRF-Nonce required"`
- `X-CSRF` occurs at exactly lines 823 and 831 — the nonce is read and non-emptiness-checked, but
  **never generated and never compared** against a server-known value ✓ (matches M-1 [B]).

`modules/tokencenter/static/app.js` (11,637 B):
- `:264` `const response = await fetch("/api/refresh", { method: "POST" });` — bare POST, no header ✓
- occurrences of `CSRF` (any casing) in app.js: **0** ✓

Consequence confirmed: the UI's own Refresh button cannot succeed (server demands header the client
never sends).

## H-4 — shell `FAILED` NameError (HIGH) — VERIFIED

`shell/src/server.py` (18,281 B):
- `:26` `from shell.src.states import ModuleRunner, EXTERNAL, READY, DEGRADED, STARTING` — **no FAILED** ✓
- `:329` `runner._set(FAILED, f"PROCESS_START_FAILED: {e}")` inside the `except` path of runner start ✓

Consequence confirmed: a failing `runner.start()` raises a secondary `NameError` instead of recording
`PROCESS_START_FAILED`.

## C-2 — SOVEREIGN provenance carries the Distillery hash (CRITICAL) — VERIFIED

`modules/sovereign/INSTALL-PROVENANCE.json` (current):
- `source_sha256: 620e8459c74fb5fe9d2dfe0c4693cea02b8346292804d2d2a01fb71cb615be96` — the foreign
  (Distillery) digest ✓; the correct SOVEREIGN source hash is
  `150e518e6d0b15b524ff61cda8fe8eb29aec6bbfb30196f9931908d12ff7ec51` (per punch list C-2).
- `operator_authorized: null` ✓ and self-attested `integrity_verified: true` on the foreign digest ✓.

## C-3 — missing current provenance + inconsistent supersession naming — VERIFIED

| Module | current `INSTALL-PROVENANCE.json` | `.previous.json` | `.json.previous` |
|---|---|---|---|
| debate | ABSENT | present | — |
| distillery | ABSENT | — | present |
| sovereign | present (wrong hash — C-2) | — | — |
| sow | ABSENT | present | — |
| tokencenter | present | — | — |

Both supersession spellings coexist exactly as recorded ✓; no current provenance for
debate/sow/distillery ✓.

## Pre-existing guards noted (context for B1/B2 implementations)

- Token Center `do_POST` already enforces a Host allowlist (`127.0.0.1:8765` / actual bind port) and
  requires an Origin header — the B1-2 fix must keep these intact.
- Seven nested `.gitignore` files ship inside the ZIP (declared in WORKTREE-RECIPE.md §4); the root
  worktree `.gitignore` adds the release-boundary classes.

---

No item in this preflight deviates from the recorded [B] claims; BATCH 1 may proceed against these
exact bytes.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
