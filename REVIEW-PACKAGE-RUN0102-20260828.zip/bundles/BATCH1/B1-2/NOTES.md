# B1-2 — H-3 Token Center refresh contract (M-1 Option A minimal) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 1 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `29f4dc9130b42750cc53be2ed2cf6864f91be80c` (parent `cbaabe7`)
**UTC:** 2026-08-28T02:12–02:14Z

## Defect (pre-flight byte-verified)

`piggybank.py:823–831` demanded an `X-CSRF-Nonce` header but only checked it for non-emptiness
(no generation, no comparison); `static/app.js:264` posted bare with no header; the string `CSRF`
appeared 0 times in app.js. The UI's own Refresh therefore always 403'd (H-3), and any caller
sending any nonce value passed (M-1 core).

## Minimal change applied (decision-block M-1 Option A — real compared token)

Server (`modules/tokencenter/piggybank.py`):
- `secrets.token_urlsafe(32)` generated once per process at start; `main()` passes it explicitly
  to `make_handler(state, csrf_token)` (the factory also self-generates when called bare, as the
  tests do).
- New `GET /api/csrf-token` returns `{"token": …}` — guarded by the loopback-Host allow-list,
  same-origin only (no CORS headers are emitted anywhere, so cross-origin script reads are
  browser-blocked).
- `do_POST` now requires `hmac.compare_digest(nonce, token)` (constant-time); message changed
  `X-CSRF-Nonce required` → `X-CSRF-Nonce invalid`. Host check factored to `_loopback_host()`.
- Header name `X-CSRF-Nonce` and the existing Host/Origin guards retained — **exact-origin parse,
  content-type + body-size guard, and security headers are deliberately deferred to B2-3 (M-1 full)**
  per the queue's minimal-diff instruction.

Client (`modules/tokencenter/static/app.js`):
- `refreshLedgers()` fetches `/api/csrf-token`, then POSTs `/api/refresh` with
  `X-CSRF-Nonce: <token>`. No other behavior changed; `node --check` exit 0 (node v24.16.0).

## Fail-before evidence (measured) — `fail-before-output.txt`

`python -m unittest tests.test_csrf_contract -v` against the UNFIXED server:
**6 tests, 3 FAILED (exit 1)**:
- `test_ui_refresh_pattern_succeeds` — FAIL: `GET /api/csrf-token` did not exist (404 ≠ 200)
  → the UI pattern could never succeed;
- `test_wrong_token_rejected` — FAIL: a wrong nonce returned **200** ≠ 403 → nonce was never
  compared (the M-1 core defect);
- `test_token_endpoint_rejects_foreign_host` — FAIL: route absent (404 ≠ 403);
- bare POST / absent token / cross-origin guardrail tests passed pre-fix (existing guards held).

## Pass-after evidence (measured)

- `pass-after-output.txt`: `tests.test_csrf_contract` → **6/6 OK, exit 0**:
  bare POST 403 · UI pattern (fetch token → POST with header) **200, ok:true** · wrong token 403 ·
  absent token 403 · cross-origin (http://example.com) with valid token 403 · foreign Host on the
  token endpoint 403.
- `affected-suite-output.txt`: existing `tests.test_piggybank` → **5/5 OK, exit 0** (no regression).
- `diff.txt`: full diff (3 files, +180/−7).

## Changed files

- `modules/tokencenter/piggybank.py` (imports hmac/secrets; token factory param; `_loopback_host`;
  GET /api/csrf-token; constant-time compare in do_POST; main passes explicit token)
- `modules/tokencenter/static/app.js` (refreshLedgers fetches and sends the token)
- `modules/tokencenter/tests/test_csrf_contract.py` (NEW — 6 contract tests; stdlib-only, offline:
  spins a real ThreadingHTTPServer on an ephemeral loopback port with a temp State home)

## Accepted limitations (carried to B2-3)

Origin check is still `startswith("http://127.0.0.1")` (prefix flaw, e.g. `http://127.0.0.1.evil`
would pass) — B2-3 lands exact-origin parsing, content-type/body-size in the mutation guard, and
standard security headers, with the extended HTTP/CSRF/lifecycle suite. No security property was
weakened by this change: every previously-rejected request is still rejected, and the nonce is now
additionally value-compared.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
