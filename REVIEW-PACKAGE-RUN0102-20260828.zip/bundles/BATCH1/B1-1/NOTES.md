# B1-1 — C-1 packaging gate (CRITICAL closure) — ITEM REPORT
## SWS-REM-DIR-20260828 R2 · BATCH 1 · builder qwen3.8-max

**Status: CANDIDATE** — no reviewer PASS asserted.
**Commit:** `cbaabe796a9b75f7397a586106bf4fe0e7603e8c` (parent `cf50cde`)
**UTC:** 2026-08-28T02:05–02:12Z

## Scope executed

1. Removed packaged user/runtime state from the WORKTREE ONLY (frozen SYSTEM ZIP preserves all
   originals; the ZIP was never written):

   Named by the queue (C-1a/b/c):
   - `modules/sovereign/runtime/sovereign.db` (90,112 B; sessions 1 / messages 4 / jobs 2 / event_log 17)
   - `modules/sovereign/runtime/evidence/quick/session_9798…/quick-2026…/` — `prompt.txt`,
     `raw_generation.json`, `accepted.txt`, `evidence.json`, `result.json`
   - `modules/sovereign/ui/ui_shell/.env.local`
   - `modules/sow/apps/desktop/docs/loop/logs/phase17c_iter90_main.log`

   Same defect class, surfaced by the gate's own output (active-tree runtime/session state;
   closure set defined mechanically by the gate, per the C-1 fix definition "allow-list packaging
   + release gate rejecting runtime/session/log/cache classes unless declared fixtures"):
   - `modules/sovereign/runtime/evidence/status/session_…/job_e81d….json`
   - `modules/sow/apps/desktop/.approvals/session-events.jsonl` (+ `selfcheck/` copy; both 0-byte)
   - `modules/sow/apps/desktop/.recovery/{layout.json, session-log.json, selfcheck/*}` (4 files)
   - `modules/sow/config/live_operation.json` (live operation/spend-envelope state)
   - `modules/sow/.claude/settings.local.json` (local tool settings)

   Every removed file's SHA-256 was recorded BEFORE deletion → `pre-deletion-hashes.txt`.
   Only provably-empty directories were pruned afterwards (13).

2. Implemented `tools/release/package_boundary_gate.py` — allow-list-oriented scan:
   - FAILS on: `*.db`/`*.sqlite*` (+wal/shm), `.env*` family + key material (`.pem/.key/.p12/.pfx/.keystore`),
     `*.log`, runtime/session-state path components (`node_modules`, venvs, `__pycache__`,
     `.approvals`, `.recovery`, `runs`, …), the sovereign `modules/sovereign/runtime/` lane by
     definition, cache/junk basenames (`Thumbs.db`, `desktop.ini`, `.DS_Store`, `*.cache`),
     `live_operation.json` / `settings.local.json` state names, and high-confidence credential
     content patterns (AKIA…, PRIVATE KEY blocks, `gh[pousr]_…`, `xox[baprs]-…`, `sk-…`).
   - QUARANTINED-HISTORICAL lanes (listed and counted, never scan-failed — the evidence lane rule
     required by the queue): `evidence/` (frozen captures), `dev/` (director-accepted v1.2.1
     staging history), `modules/distillery/runs/` (SD-RBR run/gate evidence under OD-2 —
     quarantined, NOT deleted).
   - Declared-fixture allow-list is VALUE-BASED: exact relative path AND exact SHA-256; glob
     characters in entry paths are rejected with configuration error (exit 2); hash mismatch on a
     declared fixture is a violation.
   - The gate's own allow-list configuration is exempt from content scanning (its reason strings
     quote synthetic fixture values by design); exempted by resolved path, not by pattern.
   - Exit codes: 0 pass / 1 violations / 2 configuration error. Human + `--json` reports.

3. Declared fixtures (`tools/release/fixture_allowlist.json`, 5 entries, all hash-pinned):
   four Distillery files carrying the synthetic value `sk-synthetic000000000000000000`
   (`SYNTHETIC_API_KEY` / `ALLOWED_FIXTURE_VALUE` / `DECLARED_FIXTURE_SECRETS` in the codebase's
   own words) and the gate's own regression test (embeds an AKIA example + PRIVATE KEY block).

## Fail-before / pass-after evidence (measured)

| Stage | File | Verdict | Counts |
|---|---|---|---|
| fail-before #1 (uncleaned tree, no lanes fix) | `fail-before-scan.json` | FAIL (exit 1) | 99 violations + 6 credential hits; 3,585 files; 1,977 quarantined |
| fail-before #2 (runs-lane quarantine + 5 fixtures declared) | `fail-before-scan-2.json` | FAIL (exit 1) | 17 violations + 1 hit (allow-list config self-scan, fixed next) |
| fail-before #3 (final gate, pre-deletion) | `fail-before-scan-3.json` | FAIL (exit 1) | 18 = the 17 active-tree state files + 1 deliberate allow-list sha-mismatch on this suite's own test file after edit (value-based mechanism demonstrated) |
| pass-after (cleaned tree) | `pass-after-scan.json`, `pass-after-scan-final.txt` | PASS (exit 0) | 0 violations, 0 credential hits, 3,568 files, 2,059 quarantined-historical, 5 allowlisted |

## Tests (measured)

`python tools/release/test_package_boundary_gate.py -v` → **29 tests, OK, exit 0**
(`unit-test-output.txt`). Stdlib-only (unittest) → runs offline with zero provisioning.
Coverage: each rejected class; credential patterns; value-based fixture pass + tamper-fail;
glob allow-list config-error; quarantine lanes incl. active-tree still failing; cleaned-worktree
pass-after. Two bootstrap iterations were required (rule-order fix for `Thumbs.db`; the test's own
bytecode byproduct; re-declared hash after final edit) — all recorded in the evidence files.

## Changed files (commit `cbaabe7`)

- Deleted (17 worktree files; 6 of them git-tracked → visible in diff): see `commit-stat.txt`
- Added: `tools/release/package_boundary_gate.py` (360 lines),
  `tools/release/test_package_boundary_gate.py` (249 lines),
  `tools/release/fixture_allowlist.json` (5 entries)
- Diffstat: 9 files changed, 641 insertions(+), 4,499 deletions(-)

## Notes / accepted limitations

- Distillery `runs/` lane quarantined rather than cleaned: it is the historical run/gate evidence
  of the SD-RBR release process (OD-2 scope), not C-1-class user state; deleting release evidence
  would be an E-2-class act. The frozen ZIP is the byte authority for all removed/quarantined bytes.
- The adjudication record A′ stated `.approvals/.recovery` material existed only in frozen
  captures; the SYSTEM ZIP in fact also carries it under the active `modules/sow/apps/desktop/`
  tree. The gate treated the bytes as found: cleaned as active-tree runtime state. Recorded as a
  [B]-level observation for the reviewer; no queue impact.
- Build-output artifacts (`modules/distillery/dist/*.whl|tar.gz`, `ui_shell/dist/`,
  `*.egg-info`) are deliberately NOT gate-fail classes here; they belong to the later
  supply-chain / final package-boundary gate, and Distillery's dist artifacts are OD-2 inputs.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
