# BATCH 1 — BATCH REPORT
## SWS-REM-DIR-20260828 R2 · builder qwen3.8-max · UTC 2026-08-28T02:22Z

Scope per queue: C-1 packaging gate (B1-1), H-3 Token Center refresh contract (B1-2),
H-4 shell FAILED import (B1-3). All work in `D:\producttion software 2\release-worktree\`;
frozen ZIPs and custody untouched; every gate status is CANDIDATE.

| Item | Punch item | Status | Commit | Headline evidence |
|---|---|---|---|---|
| B1-1 | C-1 (a/b/c) | **CANDIDATE** | `cbaabe7` | gate fail-before FAIL 99+6 → pass-after PASS 0/0; 17 state files removed (pre-deletion hashes recorded); 29/29 gate tests OK |
| B1-2 | H-3 (+M-1 Option A minimal) | **CANDIDATE** | `29f4dc9` | fail-before 3 failures (404 endpoint; wrong nonce → 200) → pass-after 6/6 OK + existing 5/5 OK + `node --check` 0 |
| B1-3 | H-4 | **CANDIDATE** | `3ad0720` (repaired from `7de04af`) | fail-before 1F+2E incl. `NameError: name 'FAILED' is not defined` → pass-after 3/3 OK; shell suite 163 tests, 134 pass, 29 pre-existing (proved identical pre/post fix) |

## Worktree commit chain

```
cf50cde  P0-2 initial worktree (SYSTEM ZIP 75e4be07…)
cbaabe7  B1-1 (C-1 closure): remove packaged runtime state; add allow-list package boundary gate
29f4dc9  B1-2 (H-3, M-1 Option A minimal): real per-process CSRF token
3ad0720  B1-3 (H-4): import FAILED; start-worker failure regression
```

## Measured test counts (this batch only)

- package_boundary_gate suite: **29/29 OK**
- tokencenter `tests.test_csrf_contract`: **6/6 OK** (fail-before: 3 failures)
- tokencenter `tests.test_piggybank` (affected suite): **5/5 OK**
- shell `tests.test_start_worker_failure`: **3/3 OK** (fail-before: 1F+2E)
- shell full suite (affected, host-coupled): 163 tests — 134 pass; 14F+15E **pre-existing**,
  proven byte-for-byte independent of the B1-3 change by identical pre-fix/post-fix subset runs.
  Dominant pre-existing cause: `ModuleNotFoundError: control_plane.canonical_registry` (the H-5
  lineage gap held for OD-20) plus SYSTEM-vs-RESET JS/content drift in SOW desktop pins.

## Parked

None. No E-class exception fired in BATCH 1.

## Carry-forwards

- M-1 full hardening (exact-origin parse, content-type/body-size guard, security headers,
  extended lifecycle suite) → B2-3, as queued.
- Pre-existing shell-suite failures classified in B1-3 NOTES §"Classification" — reviewer context,
  not batch scope; the control_plane subset waits on OD-20.
- Suite side effects (evidence/hardening timestamp rewrites; BUILD-MANIFEST regeneration) declared
  in B1-3 NOTES §6; evidence lane restored to baseline after runs.

Per-item bundles: `bundles\BATCH1\B1-1\`, `bundles\BATCH1\B1-2\`, `bundles\BATCH1\B1-3\`
(NOTES.md + fail-before/pass-after evidence + diffs + test outputs).

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
