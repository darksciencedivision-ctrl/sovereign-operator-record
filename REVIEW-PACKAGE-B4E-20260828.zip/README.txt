B4E review addendum: 9 patches + per-item NOTES + batch report + custody.
Full raw evidence: release-planning\bundles\BATCH4\ on the operator disk.
Large tree archives reproducible: git archive a945d99.
