# utc: 2026-08-28T17:09:00Z
# producer: codex B4E P-D3
# P-D3 — terminal provenance and release-manifest regeneration

Status: CANDIDATE.

Commit: `a945d99`.

The three module provenance records were regenerated from git-tracked archive bytes, excluding ignored host state so their content identities are reproducible from the release archive. Existing `.previous` supersession records remain byte-identical. The registry source hashes/counts and every RELEASE-MANIFEST digest were measured fresh; `batch_files` explicitly covers every Batch 4-E product file except the manifest itself and the three provenance records already pinned by `provenance_record_sha256`.

All required final invocations are green: clean staged-tree package boundary 0 violations; provenance cross-hash 0 failures; release manifest 0 problems; governance BOM 0 problems; SOVEREIGN model consistency 0 problems; innerHTML audit 0 unjustified; release-tool aggregate 68/68.

R-4 couplings: module source registry re-pinned for all three regenerated content identities; fixture allow-list re-pinned for the archive-policy self-test; release-manifest checker and its regression test now enforce the new explicit `batch_files` hashes. The initial aggregate/archive correction cycle is fully disclosed in `correction-cycle.txt`.

No product byte was changed after commit `a945d99`.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
