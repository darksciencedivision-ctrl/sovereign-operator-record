# utc: 2026-08-28T16:29:54.9121819Z
# producer: codex B4E N-15
# N-15 — shell pre-flight npm detection

Status: PARKED with candidate implementation. The npm-specific functional criteria are green, but the directive's whole-containing-file criterion is not: `shell/tests/test_shell.py` measures 54/56 because of two pre-existing, unrelated Distillery “no runtime” expectations. Repairing those tests or the runnable Distillery adapter is outside N-15 scope.

Commit: `ae6e1c1`.

The fix resolves npm with `shutil.which`. A resolved `.cmd`/`.bat` is validated as `[resolved, "--version"]` by the existing SOW L-1 guard, then invoked as `cmd.exe /d /c resolved --version`, with `shell=False`, captured output, and the existing 10-second timeout. No other tool probe changed.

R-3 correction: the existing guard is `assert_cmd_shim_argv_safe(argv)` and only inspects arguments when argv[0] ends in `.cmd`; therefore validation occurs on the shim argv before wrapping it with `cmd.exe`.

R-4 coupling: `shell/BUILD-MANIFEST.txt` was re-pinned only for `src/probe.py` in this commit. P-D4 remains responsible for regenerating and checking every manifest line.

R-5: both shell-test invocations were followed by Git-status and evidence-lane checks; neither changed `BUILD-MANIFEST.txt` nor `evidence/hardening/h13..h16`.

No network, package install, GPU, service, model, or external-tree access occurred.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
