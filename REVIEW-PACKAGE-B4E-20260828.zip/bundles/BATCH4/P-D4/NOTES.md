# utc: 2026-08-28T16:36:09.6558444Z
# producer: codex B4E P-D4
# P-D4 — shell BUILD-MANIFEST refresh

Status: CANDIDATE.

Commit: `0f48721`.

The exact suite-native generator `TestBuildManifest.test_generate_build_manifest` regenerated the manifest. The independent bundle verifier checks every recorded digest and full tree completeness, not only the known server entry.

Two defects were corrected: `src/server.py` authenticated the corrupted pre-R-1 blob, and the N-15 commit's new `tests/test_probe.py` had not been added to the manifest. The latter is an acknowledged incomplete R-4 coupling in the preceding N-15 commit; P-D4 corrects it in the immediately following queue item.

R-5: the minimal shell-suite invocation changed only the intended BUILD-MANIFEST. The four hardening evidence files remained byte-identical to HEAD.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
