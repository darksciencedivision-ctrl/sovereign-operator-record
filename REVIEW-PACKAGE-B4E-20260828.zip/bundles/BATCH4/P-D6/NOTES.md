# utc: 2026-08-28T16:47:00Z
# producer: codex B4E P-D6
# P-D6 — package-boundary workflow and authorized cleanup

Status: CANDIDATE.

Commit: `8370b42`.

The policy now distinguishes the authoritative clean-archive gate from a live-tree operational-hygiene scan. The clean archive of predecessor commit `f3d14f2` passed with 0 violations; the cleaned live tree failed with 1,002 violations, of which 1,001 are the deliberately retained offline `node_modules` tree and one is an ignored Debate log outside the authorized deletion classes.

Authorized cleanup removed 48 cache directories and `modules/tokencenter/data/piggybank.sqlite`; none were tracked, and no qualifying cache/database candidate remains. The failed first clean-archive invocation and its corrected explicit allow-list invocation are recorded in `invocation-correction.txt`.

R-4 coupling: none. The new policy document is not pinned by a local component manifest; final module provenance and RELEASE-MANIFEST regeneration remains P-D3.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
