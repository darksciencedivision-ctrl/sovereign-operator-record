# utc: 2026-08-28T16:33:37.2668221Z
# producer: codex B4E N-11
# N-11 — Debate default-seat VRAM fit

Status: CANDIDATE.

Commit: `70c0ed9`.

Only the active Neo default seat changed, from `phi4:14b` to `qwen3:8b`. All remaining `phi4` references are preserved historical, snapshot-restoration, or qualification records and are classified in `phi4-inventory.md`.

R-4 coupling: `MANIFEST-SHA256.json` pins `config.json`, so its size/hash entry was regenerated. Its verifier also exposed the pre-existing stale entry for `tests/test_v1_2_1_config_integrity.py` left by the earlier L-6 BOM strip; that entry was re-pinned to restore the manifest's documented 51-file/zero-mismatch contract. No test source changed in this item.

Release notes: default seats sized for full residency on 8 GB cards; final ruling folds into OD-9.

The actual `qwen3:8b` live-load/residency check is QUEUED-T2. No model was loaded and no Ollama endpoint was contacted.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
