# utc: 2026-08-28T17:09:00Z
# producer: codex BATCH 4-E
# BATCH 4-EXTENDED R2 — builder report

| ID | Commit | Status | Measured counts |
|---|---|---|---|
| P-D2 | `deee50c` | CANDIDATE | managed clean rc 0; timing 0.157 s; integration 1/1 on each Python; cmd-shim 17/17 on each Python; hostile argv refused |
| N-15 | `ae6e1c1` | PARKED | new probe 2/2; endpoint 2/2; targeted shell file 54 passed / 2 unrelated failed |
| N-11 | `70c0ed9` | CANDIDATE | corrected module run 11/11; manifest 51/51; 14 pre-change phi4 inventory hits classified |
| P-D4 | `0f48721` | CANDIDATE | generator 1/1; manifest 64 actual / 64 declared / 64 recorded; 0 mismatches / omissions |
| P-D5 | `f3d14f2` | CANDIDATE | one exact table-row replacement; two exact annotations; predecessor bodies byte-identical after prefix removal |
| P-D6 | `8370b42` | CANDIDATE | 48 cache dirs + 1 database removed; clean archive 3,524 files / 0 violations; live tree 1,002 operational-hygiene violations |
| N-13 | `6bb25f3` | PARKED | tool tests 3/3; 12-field dry-run; atomic refusal on 3 absent llama.cpp targets; manifest 65/65 |
| N-14 | `c287dab` | PARKED | focused 9 passed / 1 stale Distillery assertion failed; full shell 134 passed / 31 failed / 4 subtests; 0 external asset refs; manifest 67/67 |
| P-D3 | `a945d99` | CANDIDATE | clean final archive 3,530 files / 0 violations; 6/6 gates green; release-tool aggregate 68/68 |

## Commit chain from `5a52946`

1. `deee50c` B4E P-D2: repair process_tree direct-exec import
2. `ae6e1c1` B4E N-15: detect npm command shims in pre-flight
3. `70c0ed9` B4E N-11: size Debate default seat for 8 GB VRAM
4. `0f48721` B4E P-D4: refresh shell build manifest
5. `f3d14f2` B4E P-D5: annotate superseded Debate version claims
6. `8370b42` B4E P-D6: document archive-bound release gate policy
7. `6bb25f3` B4E N-13: add guarded adapter path rebase
8. `c287dab` B4E N-14: align shell presentation with visual baseline
9. `a945d99` B4E P-D3: regenerate final provenance and release manifest

## T-2 additions

- N-14 screenshot parity adjudication against the operator target remains queued.
- N-13 worktree module venv provisioning remains required; llama.cpp runtime targets must also exist before the guarded adapter rebase can execute.
- N-11 requires a live-load/residency check on an 8 GB card; no model was loaded in this hermetic batch.

Any batch that changes module bytes ends with provenance/manifest regeneration and a full gate re-run; a manifest generated before the last byte change is stale by definition.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
