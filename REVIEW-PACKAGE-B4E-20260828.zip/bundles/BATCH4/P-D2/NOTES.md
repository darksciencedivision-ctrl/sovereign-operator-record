# utc: 2026-08-28T16:26:10.7495040Z
# producer: codex B4E P-D2
# P-D2 — process_tree direct-exec import

Status: CANDIDATE.

Commit: `deee50c`.

The prescribed guarded import was added to `process_tree.py`; `cmd_shim.py` is unchanged. Direct job-member execution can now load the guard without the package root on `sys.path`. A new integration test pins clean success, output, descendant cleanup, and hostile `.cmd` refusal on the managed path.

R-4 coupling: the integration test is the only coupled file. No manifest in the current tree pins either changed file; terminal provenance regeneration is P-D3.

One initial run of the new test reached all product assertions but its diagnostic-string assertion compared the raw payload with the exception's `repr` rendering. That test-only assertion was corrected to compare `repr(hostile)`; the subsequent host and Python 3.12 runs are green. No product failure was hidden.

No network, package install, GPU, service, model, or external-tree access occurred.

BUILDER CLAIM: no gate submitted for reviewer evaluation; no PASS asserted.
